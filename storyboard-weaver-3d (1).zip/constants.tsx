
import React from 'react';
import { CameraConfig, CameraPreset, LightConfig, LightType } from './types';

export const APP_TITLE = "Storyboard Weaver 3D";

export const DEFAULT_CAMERA_CONFIG: CameraConfig = {
  position: { x: 0, y: 1.6, z: 6 },
  rotation: { x: -10, y: 0, z: 0 },
  fov: 55,
  zoom: 1,
};

export const DEFAULT_AMBIENT_LIGHT_CONFIG: LightConfig = {
  id: 'default-ambient-' + Date.now(),
  name: 'Ambient Light',
  type: 'Ambient',
  color: '#555555',
  intensity: 1.0,
  position: { x: 0, y: 0, z: 0 },
  target: { x: 0, y: 0, z: 0 },
  castShadow: false,
};

export const DEFAULT_DIRECTIONAL_LIGHT_CONFIG: LightConfig = {
  id: 'default-directional-' + Date.now(),
  name: 'Directional Light',
  type: 'Directional',
  color: '#FFFFFF',
  intensity: 1.8,
  position: { x: 5, y: 10, z: 7 },
  target: { x: 0, y: 0, z: 0 },
  castShadow: true,
};

export const AVAILABLE_COLORS: string[] = [
  '#FF6B6B', '#4ECDC4', '#45B7D1', '#FED766', '#2AB7CA',
  '#F0F2A6', '#C1E7E3', '#FFD1AA', '#A050E4', '#E8A0BF', // Corrected from #A0S0E4
  '#F94144', '#F3722C', '#F8961E', '#F9C74F', '#90BE6D',
  '#43AA8B', '#577590'
];

export const BACKGROUND_COLORS: string[] = [
  '#2D3748', '#1A202C', '#4A5568', '#718096', '#A0AEC0',
  '#CBD5E0', '#E2E8F0', '#EDF2F7', '#F7FAFC', '#000000',
  '#FFFFFF', '#172142',
];

export const CAMERA_PRESETS: CameraPreset[] = [
  { name: 'Default View', config: DEFAULT_CAMERA_CONFIG },
  // Fix: Completed position and rotation objects for 'Close-Up' preset
  { name: 'Close-Up', config: { position: { x: DEFAULT_CAMERA_CONFIG.position.x, y: 1, z: 2 }, rotation: {x: -5, y: DEFAULT_CAMERA_CONFIG.rotation.y, z: DEFAULT_CAMERA_CONFIG.rotation.z}, fov: 30, zoom: 1.2 } },
  // Fix: Completed position and rotation objects for 'Medium Shot' preset
  { name: 'Medium Shot', config: { position: { x: DEFAULT_CAMERA_CONFIG.position.x, y: 1.5, z: 4 }, rotation: {x: -8, y: DEFAULT_CAMERA_CONFIG.rotation.y, z: DEFAULT_CAMERA_CONFIG.rotation.z}, fov: 45, zoom: 1 } },
  // Fix: Completed position and rotation objects for 'Long Shot (Wide)' preset
  { name: 'Long Shot (Wide)', config: { position: { x: DEFAULT_CAMERA_CONFIG.position.x, y: 2, z: 10 }, rotation: {x: -15, y: DEFAULT_CAMERA_CONFIG.rotation.y, z: DEFAULT_CAMERA_CONFIG.rotation.z}, fov: 60, zoom: 1 } },
  // Fix: Completed position and rotation objects for 'High Angle' preset
  { name: 'High Angle', config: { position: { x: DEFAULT_CAMERA_CONFIG.position.x, y: 5, z: 5 }, rotation: { x: -30, y: DEFAULT_CAMERA_CONFIG.rotation.y, z: DEFAULT_CAMERA_CONFIG.rotation.z }, fov: 50 } },
  // Fix: Completed position and rotation objects for 'Low Angle' preset
  { name: 'Low Angle', config: { position: { x: DEFAULT_CAMERA_CONFIG.position.x, y: 0.5, z: 3 }, rotation: { x: 15, y: DEFAULT_CAMERA_CONFIG.rotation.y, z: DEFAULT_CAMERA_CONFIG.rotation.z }, fov: 50 } },
  // Fix: Completed rotation object for 'Dutch Angle (Left)' preset
  { name: 'Dutch Angle (Left)', config: { rotation: { x: DEFAULT_CAMERA_CONFIG.rotation.x, y: DEFAULT_CAMERA_CONFIG.rotation.y, z: 15 } } },
  // Fix: Completed position object for 'Top Down View' preset
  { name: 'Top Down View', config: { position: { x: DEFAULT_CAMERA_CONFIG.position.x, y: 10, z: 0.1 }, rotation: {x: -89.9, y: 0, z: 0}, fov: 70 } },
  // Fix: Completed rotation object for 'Over-the-Shoulder' preset
  { name: 'Over-the-Shoulder', config: { position: {x: -0.8, y: 1.7, z: 2.5}, rotation: {x: -10, y: -20, z: DEFAULT_CAMERA_CONFIG.rotation.z}, fov: 40}}
];

export const LIGHT_TYPES: { value: LightType; label: string }[] = [
  { value: 'Ambient', label: 'Ambient Light' },
  { value: 'Directional', label: 'Directional Light' },
  { value: 'Point', label: 'Point Light' },
  { value: 'Spot', label: 'Spot Light' },
];

const createIcon = (path: string | JSX.Element | JSX.Element[]) =>
  React.forwardRef<SVGSVGElement, React.SVGProps<SVGSVGElement>>(({ className = "w-5 h-5", ...props }, ref) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className} ref={ref} {...props}>
    {typeof path === 'string' ? <path strokeLinecap="round" strokeLinejoin="round" d={path} /> : path}
  </svg>
));

export const PlusIcon = createIcon("M12 4.5v15m7.5-7.5h-15");
export const UserGroupIcon = createIcon("M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m.94 3.198l.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0112 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 016 18.719m12 0a5.971 5.971 0 00-3.741-.477m3.741.477A5.965 5.965 0 0121 13.481V12c0-3.314-2.015-6.048-4.741-6.988V3.548S16.5 2 14.5 2 13 3.548 13 3.548v1.464C10.285 6.014 9 7.854 9 9.865v3.616m9 0H9v-3.616c0-1.01.324-1.94.877-2.719M12 9.865v1.745M15 9.865v2.517M15 12.382a2.5 2.5 0 01-2.5-2.5V3.548S12.5 2 10.5 2 9 3.548 9 3.548v4.818a2.5 2.5 0 01-2.5 2.5v3.616c0 .92.232 1.79.637 2.53M12 14.735A3.75 3.75 0 006.265 18.72m11.47 0a3.75 3.75 0 01-5.735-2.255M12 21a3.75 3.75 0 01-5.963-1.584m5.963 1.584A3.75 3.75 0 0018 18.72m-6-2.985A3.75 3.75 0 009 18.72m3-2.985V21m-3-5.265A3.75 3.75 0 016.265 18.72M9 15.735V21M6.265 18.72A3.75 3.75 0 003 15.735V12c0-1.59.513-3.048 1.363-4.217M4.363 7.783A3.75 3.75 0 019 3.548v1.464M4.363 7.783C5.213 6.614 6.513 6 8 6c1.487 0 2.787.614 3.637 1.783m0 0A3.75 3.75 0 0115 3.548v1.464m-3.637 2.771A3.75 3.75 0 0015 9.865v1.745m-6.762-3.832C8.787 7.168 9.513 6 10.5 6c.987 0 1.713.168 2.262.832M10.5 6V3.548");
export const CubeIcon = createIcon("M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9");
export const CameraIcon = createIcon("M10.5 6h3m-6.75 6.75v3.75m0 0a3.75 3.75 0 01-7.5 0V12.75A3.75 3.75 0 018.25 9H12.75a3.75 3.75 0 013.75 3.75v3.75a3.75 3.75 0 01-3.75 3.75H8.25a3.75 3.75 0 01-3.75-3.75zM18 9.75v1.5m0 0v1.5m0-1.5H15m3 0h3");
export const SparklesIcon = createIcon("M9.53 2.47a.75.75 0 010 1.06L4.81 8.25H15a6.75 6.75 0 010 13.5H5.25a2.25 2.25 0 01-2.25-2.25V6.75a2.25 2.25 0 012.25-2.25h4.017l4.72-4.72a.75.75 0 011.06 0zm-3 5.28L4.75 9.535V6.75a.75.75 0 01.75-.75h.035l1.965 1.965zM8.25 15h6.75a5.25 5.25 0 000-10.5H6.75a.75.75 0 00-.75.75v10.5c0 .414.336.75.75.75H8.25z");
export const CogIcon = createIcon("M9.594 3.94c.09-.542.56-1.007 1.116-1.212l.097-.035c.23-.082.48-.122.732-.122s.503.04.732.122l.097.035c.556.205 1.026.67 1.116 1.212l.03.176c.075.44.193.863.346 1.257l.042.108c.127.324.309.625.53.893l.09.109c.33.405.724.734 1.168.983l.14.078c.402.22.82.386 1.246.502l.17.047c.542.09.94.552.94 1.093v.03c0 .26-.04.51-.122.748l-.034.099c-.205.555-.67 1.025-1.212 1.115l-.176.03c-.44.075-.863.193-1.257.346l-.108.042c-.324.127-.625.309-.893.53l-.109.09c-.405.33-.734.724-.983 1.168l-.078.14c-.22.402-.386.82-.502 1.246l-.047.17c-.09.542-.552.94-1.093.94h-.03c-.26 0-.51-.04-.748-.122l-.099-.034c-.555-.205-1.025-.67-1.115-1.212l-.03-.176c-.075-.44-.193-.863-.346-1.257l-.042-.108c-.127-.324-.309-.625-.53-.893l-.09-.109c-.33-.405-.724-.734-1.168-.983l-.14-.078c-.402-.22-.82-.386-1.246.502l-.17-.047c-.542-.09-.94-.552-.94-1.093v-.03c0-.26.04-.51.122-.748l.034-.099c.205-.555.67-1.025 1.212-1.115l.176-.03c.44-.075.863.193 1.257.346l.108.042c.324.127.625.309.893.53l.109.09c.405-.33.734-.724.983-1.168l.078-.14c.22.402.386.82.502 1.246l.047-.17zM12 15.75a3.75 3.75 0 100-7.5 3.75 3.75 0 000 7.5z");
export const BookOpenIcon = createIcon("M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25");
export const LightBulbIcon = createIcon("M12 3.75c-3.446 0-6.25 2.804-6.25 6.25 0 1.994.93 3.756 2.344 4.946l.003.002.01.007c.32.225.66.423 1.018.596a.75.75 0 01.343.94l-.406 1.016a.75.75 0 00.37.964l.005.002s4.119 1.999 4.119 1.999a.75.75 0 00.964-.371l1.016-.406a.75.75 0 01.94-.343c.37-.18.717-.383 1.042-.618a6.226 6.226 0 002.432-5.136c0-3.446-2.804-6.25-6.25-6.25zM12 12.75a2.25 2.25 0 110-4.5 2.25 2.25 0 010 4.5zM13.5 8.25a.75.75 0 00-1.5 0v.062c0 .414.336.75.75.75s.75-.336.75-.75V8.25z");
export const DocumentDuplicateIcon = createIcon("M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75c-.621 0-1.125-.504-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75m9 9.375c.621 0 1.125-.504 1.125-1.125v-9.75c0-.621-.504-1.125-1.125-1.125h-9.75c-.621 0-1.125.504-1.125-1.125V17.25m9-9.375h-9.75M15 3.75H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h11.25c.621 0 1.125-.504 1.125-1.125V4.875c0-.621-.504-1.125-1.125-1.125z");
export const TrashIcon = createIcon("M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12.56 0c.342.052.682.107 1.022.166m0 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166M6.838 7.282c.24-.037.487-.066.738-.088m8.848 0c.25.022.498.05.738.088m-9.586 0H18.5M4.5 5.654L5.818 20.25a2.25 2.25 0 002.244 2.077H15.938a2.25 2.25 0 002.244-2.077L19.5 5.654M9 5.25v.003l.001.002A17.612 17.612 0 0112 5.25c1.007 0 1.98.083 2.914.236l.02.003a1.03 1.03 0 01.812 1.007v1.062a1.03 1.03 0 01-.812 1.007 17.612 17.612 0 01-5.848 0A1.03 1.03 0 016 7.562V6.5c0-.515.373-.942.857-1.01M12 10.5v6.75m-2.25-6.75v6.75m4.5-6.75v6.75M5.25 5.25h13.5");
export const ChevronLeftIcon = createIcon("M15.75 19.5L8.25 12l7.5-7.5");
export const ChevronRightIcon = createIcon("M8.25 4.5l7.5 7.5-7.5 7.5");
export const PanelRightOpenIcon = createIcon("M11.25 4.5l7.5 7.5-7.5 7.5m-6-15l7.5 7.5-7.5 7.5");
export const PanelRightCloseIcon = createIcon("M12.75 4.5l-7.5 7.5 7.5 7.5m6-15L11.25 12l7.5 7.5");
export const PlayIcon = createIcon("M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.348a1.125 1.125 0 010 1.972l-11.54 6.347a1.125 1.125 0 01-1.667-.986V5.653z");
export const PauseIcon = createIcon("M15.75 5.25v13.5m-6-13.5v13.5");
export const ArrowDownTrayIcon = createIcon("M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3");
export const MinusIcon = createIcon("M19.5 12h-15");

// Updated ResetIcon (Heroicons: ArrowUturnLeftIcon)
export const ResetIcon = createIcon("M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3");

// Updated Camera Control Icons
export const FovIcon = createIcon("M15.75 10.5l4.72-4.72a.75.75 0 011.06 0l.06.06a.75.75 0 010 1.06l-4.72 4.72M4.5 19.5l4.72-4.72a.75.75 0 011.06 0l.06.06a.75.75 0 010 1.06L5.58 19.5M15 9.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z");
export const ZoomIcon = createIcon("M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607zM10.5 7.5v6m3-3h-6");

// New Position icons using Heroicons
// PositionXAxisIcon (Heroicons: ArrowsRightLeftIcon) - Suggests lateral movement
export const PositionXAxisIcon = createIcon("M7.5 21L3 16.5m0 0L7.5 12M3 16.5h18m-7.5-4.5L21 7.5m0 0L16.5 3M21 7.5H3");
// PositionYAxisIcon (Updated) - Suggests vertical movement with clearer up/down arrows on a single stem.
export const PositionYAxisIcon = createIcon("M12 4.5v15m0-15L8.25 8.25M12 4.5l3.75 3.75m-3.75 11.25L8.25 15.75M12 19.5l3.75-3.75");
// PositionZAxisIcon (Updated) - Suggests depth movement (towards/away) with clearer perspective arrows.
export const PositionZAxisIcon = createIcon("M12 6v12m-3-3l3 3 3-3M10 7l2-2 2 2M10 17l2 2 2-2");


// RotationPitchIcon (Heroicons: ChevronUpDownIcon) - Suggests vertical tilt/pitch
export const RotationPitchIcon = createIcon("M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9");
// RotationYawIcon (Heroicons: ChevronLeftRightIcon) - Suggests horizontal turn/yaw
export const RotationYawIcon = createIcon("M15 8.25L18.75 12 15 15.75m-6-7.5L5.25 12 9 15.75");
// RotationRollIcon (Heroicons: ArrowPathIcon - was ResetIcon) - Suggests roll/spin
export const RotationRollIcon = createIcon("M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99");

// New Icons for Asset Library Panel
export const MagnifyingGlassIcon = createIcon("M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z");
export const FunnelIcon = createIcon("M3 4.5h14.25M3 9h9.75M3 13.5h5.25m5.25-.75L17.25 9m0 0L21 12.75M17.25 9v12");
export const ViewColumnsIcon = createIcon("M3.75 5.25h16.5m-16.5 4.5h16.5m-16.5 4.5h16.5m-16.5 4.5h16.5"); // Can represent grid
export const ListBulletIcon = createIcon("M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5");
export const StarIcon = createIcon("M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.82.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.82-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.204-3.602a.563.563 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z");
export const TagIcon = createIcon("M12.586 2.586a2 2 0 00-2.828 0L2.172 10.172a2 2 0 000 2.828l7.071 7.071a2 2 0 002.828 0l7.586-7.586a2 2 0 000-2.828L12.586 2.586zM9 13a1 1 0 11-2 0 1 1 0 012 0z");
export const ClockIcon = createIcon("M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"); // For "Recent"
export const EyeIcon = createIcon("M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178zM15 12a3 3 0 11-6 0 3 3 0 016 0z");
export const HeartIcon = createIcon("M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z");
export const ArrowPathIcon = createIcon("M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99"); // Currently used for RotationRoll, also for "Recent" badge in new panel. Keeping as is.

// Removed: export { React };