
import React, { useState, useCallback, useEffect, useRef } from 'react';
// Fix: Import THREE for WebGLRenderer type
// Corrected import statement for THREE.js
import *                           as THREE                                                                                                  from 'three';
import { AssetLibraryItem, CameraConfig, Frame, LightConfig, LightType, SidebarPanelType, StoryCharacter, StoryObject, CameraPreset } from './types';
import { createNewFrameUtil }      from './frameUtils'; // Updated import
import {
    APP_TITLE, AVAILABLE_COLORS, BACKGROUND_COLORS, CAMERA_PRESETS, CogIcon, CubeIcon, DEFAULT_AMBIENT_LIGHT_CONFIG,
    DEFAULT_CAMERA_CONFIG, DEFAULT_DIRECTIONAL_LIGHT_CONFIG, DocumentDuplicateIcon, LightBulbIcon, PanelRightCloseIcon,
    PanelRightOpenIcon, PlusIcon, SparklesIcon as AIPromptIcon, SparklesIcon as EffectsIcon, BookOpenIcon,
    CameraIcon as SidebarCameraIcon, TrashIcon
}                                  from './constants';
import Header                      from './components/layout/Header';
import Sidebar                     from './components/layout/Sidebar';
import MainViewer                  from './components/layout/MainViewer';
import Timeline                    from './components/layout/Timeline';
import ControlsPanel               from './components/layout/ControlsPanel';
// Forms and specific panels are now mostly managed by ElementsPanel
import CameraControlsTab           from './components/storyboard/CameraControlsTab';
import LightingPanel               from './components/storyboard/LightingPanel';
import PromptGenerator             from './components/storyboard/PromptGenerator';
import ElementsPanel               from './components/storyboard/ElementsPanel'; // New consolidated panel
import Panel                       from './components/ui/Panel';
import IconButton                  from './components/ui/IconButton';
import Button                      from './components/ui/Button';
import { CameraSyncManager }       from './utils/cameraSyncManager';


const App: React.FC = () => {
  const frameNumberCounter = useRef<number>(1);
  const [frames, setFrames] = useState<Frame[]>([]); 
  const [currentFrameIndex, setCurrentFrameIndex] = useState<number>(-1); 
  const [activeSidebarPanel, setActiveSidebarPanel] = useState<SidebarPanelType | null>(null);
  const [isTimelineSidebarOpen, setIsTimelineSidebarOpen] = useState<boolean>(true);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const playbackIntervalId = useRef<number | null>(null);
  
  const [selectedAssetForForm, setSelectedAssetForForm] = useState<AssetLibraryItem | null>(null);
  const appRendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const syncManager = CameraSyncManager.getInstance();

  const [editingCharacterId, setEditingCharacterId] = useState<string | null>(null);
  const [editingObjectId, setEditingObjectId] = useState<string | null>(null);
  
  // Viewer Settings
  const [isCameraDampingEnabled, setIsCameraDampingEnabled] = useState<boolean>(false);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [showGroundPlane, setShowGroundPlane] = useState<boolean>(true);
  const [showOrientationGizmo, setShowOrientationGizmo] = useState<boolean>(true);
  const [timelinePlaybackSpeedMs, setTimelinePlaybackSpeedMs] = useState<number>(2000);

  // Asset Library Enhancements State
  const [favoriteAssetIds, setFavoriteAssetIds] = useState<string[]>([]);
  const [recentlyUsedAssetIds, setRecentlyUsedAssetIds] = useState<string[]>([]);
  const MAX_RECENT_ASSETS = 10;


  const currentFrame = currentFrameIndex !== -1 && frames[currentFrameIndex] ? frames[currentFrameIndex] : undefined;

  useEffect(() => {
    if (frames.length > 0) {
        let maxNum = 0;
        frames.forEach(f => {
            const match = f.name.match(/^Frame (\d+)/);
            if (match && parseInt(match[1]) > maxNum) {
                maxNum = parseInt(match[1]);
            }
        });
        if (maxNum >= frameNumberCounter.current) {
             frameNumberCounter.current = maxNum + 1;
        }
    } else {
        frameNumberCounter.current = 1;
    }
  }, [frames]);


  const updateCurrentFrame = useCallback((updatedProps: Partial<Frame>) => {
    if (currentFrameIndex === -1) return;

    setFrames(prevFrames =>
      prevFrames.map((frame, index) => {
        if (index === currentFrameIndex) {
          let newFrameData = { ...frame, ...updatedProps };

          if (updatedProps.camera) {
            const incomingCamera = updatedProps.camera;
            // Use shouldUpdateCamera to check for significance before updating
            if (syncManager.shouldUpdateCamera(frame.camera, incomingCamera)) {
              newFrameData.camera = {
                ...frame.camera, // existing camera data
                ...incomingCamera, // new partial or full camera data
                source: incomingCamera.source || 'appInternal',
                timestamp: incomingCamera.timestamp || Date.now(),
                updateId: incomingCamera.updateId || syncManager.generateUpdateId(),
              };
            } else {
              // If not significant, keep the old camera data to prevent re-render,
              // but ensure the ID is from the incoming if it's a non-significant echo.
              // This is tricky; for now, if not significant, we just don't update the camera object.
              newFrameData.camera = frame.camera; 
            }
          }
          return newFrameData;
        }
        return frame;
      })
    );
  }, [currentFrameIndex, syncManager]);

  const handleCameraUpdateFromViewer = useCallback((cameraConfig: CameraConfig) => {
    if (!currentFrame) return;
    // cameraConfig from MainViewer should already have source, timestamp, updateId
    // The significance check will happen inside updateCurrentFrame
    updateCurrentFrame({ camera: cameraConfig });
  }, [currentFrame, updateCurrentFrame]);


  const addFrame = useCallback(() => {
    const newFrameName = `Frame ${frameNumberCounter.current}`;
    frameNumberCounter.current++;
    const newFrame = createNewFrameUtil(newFrameName, null);

    setFrames(prevFrames => {
      const updatedFrames = [...prevFrames, newFrame];
      setCurrentFrameIndex(updatedFrames.length - 1);
      return updatedFrames;
    });
  }, []);

  const duplicateCurrentFrame = useCallback(() => {
    if (!currentFrame) return;

    let baseName = currentFrame.name;
    const copyMatch = currentFrame.name.match(/^(.*) - Copy (\d+)$/);
    let nextCopyNum = 1;

    if (copyMatch) {
        baseName = copyMatch[1];
        nextCopyNum = parseInt(copyMatch[2]) + 1;
    }

    let newFrameName = `${baseName} - Copy ${nextCopyNum}`;
    let maxExistingCopyNum = 0;
    frames.forEach(f => {
        const existingCopyMatch = f.name.match(new RegExp(`^${escapeRegExp(baseName)} - Copy (\\d+)$`));
        if (existingCopyMatch) {
            maxExistingCopyNum = Math.max(maxExistingCopyNum, parseInt(existingCopyMatch[1]));
        }
    });
    if (maxExistingCopyNum >= nextCopyNum) {
        nextCopyNum = maxExistingCopyNum + 1;
        newFrameName = `${baseName} - Copy ${nextCopyNum}`;
    } else if (!copyMatch && frames.some(f => f.name === `${baseName} - Copy 1`)) {
      nextCopyNum = maxExistingCopyNum +1;
      newFrameName = `${baseName} - Copy ${nextCopyNum}`;
    }

    const duplicatedFrame: Frame = createNewFrameUtil(newFrameName, currentFrame);

    setFrames(prevFrames => {
        const newFramesArray = [...prevFrames];
        newFramesArray.splice(currentFrameIndex + 1, 0, duplicatedFrame);
        return newFramesArray;
    });
    setCurrentFrameIndex(prevIndex => prevIndex + 1);
  }, [currentFrame, currentFrameIndex, frames]);

  const escapeRegExp = (string: string) => {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  const deleteCurrentFrame = useCallback(() => {
    if (currentFrameIndex === -1 || frames.length === 0) return;
    const newFrames = frames.filter((_, index) => index !== currentFrameIndex);
    setFrames(newFrames);

    if (newFrames.length === 0) {
      setCurrentFrameIndex(-1);
    } else {
      setCurrentFrameIndex(prevIdx => Math.min(Math.max(0, prevIdx -1 ), newFrames.length - 1));
    }
  }, [currentFrameIndex, frames]);

  const selectFrame = useCallback((index: number) => {
    if (index >= 0 && index < frames.length) {
      setCurrentFrameIndex(index);
      setEditingCharacterId(null);
      setEditingObjectId(null);
      setSelectedAssetForForm(null);
    } else if (frames.length === 0) {
      setCurrentFrameIndex(-1);
    }
  }, [frames.length]);

  useEffect(() => {
    if (isPlaying && frames.length > 1) {
      playbackIntervalId.current = window.setInterval(() => {
        setCurrentFrameIndex(prevIndex => {
          const nextIndex = prevIndex + 1;
          return nextIndex >= frames.length ? 0 : nextIndex;
        });
      }, timelinePlaybackSpeedMs); // Use state for playback speed
    } else {
      if (playbackIntervalId.current) {
        clearInterval(playbackIntervalId.current);
        playbackIntervalId.current = null;
      }
       if (isPlaying && frames.length <=1) setIsPlaying(false);
    }
    return () => {
      if (playbackIntervalId.current) clearInterval(playbackIntervalId.current);
    };
  }, [isPlaying, frames.length, timelinePlaybackSpeedMs]);

  const togglePlay = useCallback(() => {
    if (frames.length > 1) {
        setIsPlaying(prev => !prev);
    } else {
        setIsPlaying(false);
    }
  }, [frames.length]);

  const handleAssetUsed = useCallback((assetId: string) => {
    setRecentlyUsedAssetIds(prev => {
      const newRecent = [assetId, ...prev.filter(id => id !== assetId)];
      return newRecent.slice(0, MAX_RECENT_ASSETS);
    });
  }, []);

  const addCharacter = useCallback((character: Omit<StoryCharacter, 'id' | 'threeUUID'> & {assetId?: string}) => {
    if (!currentFrame) return;
    if (character.assetId) handleAssetUsed(character.assetId);
    const defaultYPosition = character.yOffset ?? (character.modelUrl ? 0 : 0.85);
    const newCharacter: StoryCharacter = {
      ...character,
      id: Date.now().toString() + Math.random().toString(16).slice(2),
      position: character.position || { x: Math.random() * 4 - 2, y: defaultYPosition, z: Math.random() * 4 - 2 },
      rotation: character.rotation || { x: 0, y: 0, z: 0 },
      scale: character.scale || { x: 1, y: 1, z: 1 },
    };
    updateCurrentFrame({ characters: [...currentFrame.characters, newCharacter] });
  }, [currentFrame, updateCurrentFrame, handleAssetUsed]);

  const updateCharacter = useCallback((updatedCharacter: StoryCharacter) => {
    if (!currentFrame) return;
    updateCurrentFrame({
      characters: currentFrame.characters.map(c => c.id === updatedCharacter.id ? updatedCharacter : c)
    });
    setEditingCharacterId(null); 
  }, [currentFrame, updateCurrentFrame]);

  const removeCharacter = useCallback((characterId: string) => {
    if (!currentFrame) return;
    updateCurrentFrame({
      characters: currentFrame.characters.filter(c => c.id !== characterId)
    });
    if (editingCharacterId === characterId) setEditingCharacterId(null);
  }, [currentFrame, updateCurrentFrame, editingCharacterId]);

 const addObject = useCallback((obj: Omit<StoryObject, 'id' | 'threeUUID'> & { position?: {x: number, y: number, z: number}, assetId?: string}) => {
    if (!currentFrame) return;
    if (obj.assetId) handleAssetUsed(obj.assetId);

    let defaultY: number;
    if (obj.modelUrl) {
        defaultY = obj.yOffset || 0;
    } else {
        defaultY = (obj.size * 0.2) / 2 + 0.01;
    }

    const newObject: StoryObject = {
        ...obj,
        id: Date.now().toString() + Math.random().toString(16).slice(2),
        position: obj.position || { x: Math.random() * 2 - 1, y: defaultY, z: Math.random() * 2 - 1 },
        rotation: obj.rotation || { x: 0, y: 0, z: 0 },
        scale: obj.scale || { x: 1, y: 1, z: 1 },
    };
    updateCurrentFrame({ objects: [...currentFrame.objects, newObject] });
  }, [currentFrame, updateCurrentFrame, handleAssetUsed]);

  const updateObject = useCallback((updatedObject: StoryObject) => {
     if (!currentFrame) return;
    updateCurrentFrame({
      objects: currentFrame.objects.map(o => o.id === updatedObject.id ? updatedObject : o)
    });
    setEditingObjectId(null); 
  }, [currentFrame, updateCurrentFrame]);

  const removeObject = useCallback((objectId: string) => {
    if (!currentFrame) return;
    updateCurrentFrame({
      objects: currentFrame.objects.filter(o => o.id !== objectId)
    });
    if (editingObjectId === objectId) setEditingObjectId(null);
  }, [currentFrame, updateCurrentFrame, editingObjectId]);

  const addLight = useCallback((lightProps: Omit<LightConfig, 'id' | 'threeUUID'>) => {
    if (!currentFrame) return;
    let baseName: string;
    switch(lightProps.type) {
        case 'Ambient': baseName = 'Ambient Light'; break;
        case 'Directional': baseName = 'Directional Light'; break;
        case 'Point': baseName = 'Point Light'; break;
        case 'Spot': baseName = 'Spot Light'; break;
        default: baseName = 'New Light';
    }

    let lightName = baseName;
    let counter = 1;
    while (currentFrame.lights.some(l => l.name === lightName)) {
        lightName = `${baseName} ${counter}`;
        counter++;
    }

    const newLight: LightConfig = {
      ...DEFAULT_AMBIENT_LIGHT_CONFIG, 
      id: Date.now().toString() + Math.random().toString(16).slice(2),
      name: lightName,
      ...lightProps, 
      position: lightProps.position || (lightProps.type === 'Ambient' ? {x:0,y:0,z:0} : { x: 0, y: 2, z: 2 }),
      target: lightProps.target || { x: 0, y: 0, z: 0 },
      castShadow: lightProps.castShadow !== undefined ? lightProps.castShadow : (lightProps.type === 'Directional' || lightProps.type === 'Spot'),
    };
    updateCurrentFrame({ lights: [...currentFrame.lights, newLight] });
  }, [currentFrame, updateCurrentFrame]);

  const updateLight = useCallback((updatedLight: LightConfig) => {
    if (!currentFrame) return;
    updateCurrentFrame({
      lights: currentFrame.lights.map(l => l.id === updatedLight.id ? updatedLight : l)
    });
  }, [currentFrame, updateCurrentFrame]);

  const removeLight = useCallback((lightId: string) => {
    if (!currentFrame) return;
    updateCurrentFrame({
      lights: currentFrame.lights.filter(l => l.id !== lightId)
    });
  }, [currentFrame, updateCurrentFrame]);


  const updateCameraFromControls = useCallback((cameraConfig: CameraConfig) => {
    if (!currentFrame) return;
    // The significance check will happen inside updateCurrentFrame
    updateCurrentFrame({ camera: cameraConfig });
  }, [currentFrame, updateCurrentFrame]);

  const applyCameraPreset = useCallback((preset: CameraPreset) => {
    if (!currentFrame) return;
    const newCameraConfig = { ...currentFrame.camera, ...preset.config };
    if (preset.config.position) newCameraConfig.position = {...currentFrame.camera.position, ...preset.config.position};
    if (preset.config.rotation) newCameraConfig.rotation = {...currentFrame.camera.rotation, ...preset.config.rotation};
    
    if (preset.config.zoom === undefined) newCameraConfig.zoom = currentFrame.camera.zoom;
    if (preset.config.fov === undefined) newCameraConfig.fov = currentFrame.camera.fov;

    updateCurrentFrame({ 
        camera: { 
            ...newCameraConfig, 
            source: 'preset', 
            timestamp: Date.now(),
            updateId: syncManager.generateUpdateId()
        } 
    });
  }, [currentFrame, updateCurrentFrame, syncManager]);

  const parseTransformString = (str: string | undefined, defaultValue: number[]): { x: number; y: number; z: number } => {
    if (!str) return { x: defaultValue[0], y: defaultValue[1], z: defaultValue[2] };
    const parts = str.split(',').map(s => parseFloat(s.trim()));
    return {
        x: isNaN(parts[0]) ? defaultValue[0] : parts[0],
        y: isNaN(parts[1]) ? defaultValue[1] : parts[1],
        z: isNaN(parts[2]) ? defaultValue[2] : parts[2],
    };
  };

  const handleScenePromptApplied = useCallback((sceneBundleText: string) => {
    const baseFrameForCopy = null;
    const sceneBlocks = sceneBundleText.trim().split(/\n---\n/).map(s => s.trim()).filter(s => s.length > 0);

    if (sceneBlocks.length === 0) {
        alert("No valid scene data found in AI response.");
        return;
    }

    let initialFrameIndexForNewBlock = frames.length;

    const newFramesToAdd: Frame[] = sceneBlocks.map((block, index) => {
        const sceneTitleMatch = block.match(/^Scene\s*\d*:\s*(.*?)(?=\nDescription:|\nCamera Suggestions:|\nExternal Image Prompt:|\nObject Suggestions:|$)/i);
        let frameNameSuffix = sceneTitleMatch && sceneTitleMatch[1] ? sceneTitleMatch[1].substring(0, 20).trim() : `AI Part ${index + 1}`;
        if (frameNameSuffix.length === 20) frameNameSuffix += "...";

        const newFrameName = `Frame ${frameNumberCounter.current}`;
        frameNumberCounter.current++;

        const newFrameInstance = createNewFrameUtil(newFrameName, baseFrameForCopy);
        newFrameInstance.name = `${newFrameInstance.name} (${frameNameSuffix})`;

        const descriptionMatch = block.match(/Description:\s*([\s\S]*?)(?=\nCamera Suggestions:|\nExternal Image Prompt:|\nObject Suggestions:|$)/i);
        const cameraSuggestionsMatch = block.match(/Camera Suggestions:\s*([\s\S]*?)(?=\nExternal Image Prompt:|\nObject Suggestions:|$)/i);
        const externalPromptMatch = block.match(/External Image Prompt:\s*([\s\S]*?)(?=\nObject Suggestions:|$)/i);
        const objectSuggestionsBlockMatch = block.match(/Object Suggestions:\s*([\s\S]*?$)/i);


        newFrameInstance.description = descriptionMatch ? descriptionMatch[1].trim() : block;
        newFrameInstance.externalAIPrompt = externalPromptMatch ? externalPromptMatch[1].trim() : "";

        const camSuggestionsText = cameraSuggestionsMatch ? cameraSuggestionsMatch[1].trim().toLowerCase() : "";
        let tempCamera = { ...newFrameInstance.camera }; 

        if (camSuggestionsText.includes("close-up") || camSuggestionsText.includes("closeup")) {
            const closeUpPreset = CAMERA_PRESETS.find(p => p.name === "Close-Up");
            if (closeUpPreset) tempCamera = {...tempCamera, ...closeUpPreset.config};
        } else if (camSuggestionsText.includes("wide shot") || camSuggestionsText.includes("wide-shot") || camSuggestionsText.includes("long shot")) {
            const widePreset = CAMERA_PRESETS.find(p => p.name === "Long Shot (Wide)");
             if (widePreset) tempCamera = {...tempCamera, ...widePreset.config};
        }
        if (camSuggestionsText.includes("low angle")) {
           const lowAnglePreset = CAMERA_PRESETS.find(p => p.name === "Low Angle");
            if (lowAnglePreset) tempCamera = {...tempCamera, ...lowAnglePreset.config};
        }
        if (camSuggestionsText.includes("high angle")) {
            const highAnglePreset = CAMERA_PRESETS.find(p => p.name === "High Angle");
            if (highAnglePreset) tempCamera = {...tempCamera, ...highAnglePreset.config};
        }
        
        newFrameInstance.camera = {
            position: tempCamera.position || DEFAULT_CAMERA_CONFIG.position,
            rotation: tempCamera.rotation || DEFAULT_CAMERA_CONFIG.rotation,
            fov: tempCamera.fov || DEFAULT_CAMERA_CONFIG.fov,
            zoom: tempCamera.zoom || DEFAULT_CAMERA_CONFIG.zoom,
            source: 'ai', 
            timestamp: Date.now(), 
            updateId: syncManager.generateUpdateId(), 
        };


        if (objectSuggestionsBlockMatch && objectSuggestionsBlockMatch[1]) {
            const objectLines = objectSuggestionsBlockMatch[1].trim().split('\n').map(l => l.trim()).filter(l => l);
            objectLines.forEach(line => {
                const parts = line.split(';').map(p => p.trim());
                const typeNameMatch = parts[0]?.match(/(\w+)\s+named\s+(.+)/i);
                if (!typeNameMatch) return;

                const type = typeNameMatch[1].trim();
                const name = typeNameMatch[2].trim();
                const validTypes = ['cube', 'sphere', 'cylinder', 'plane'];
                const objectType = validTypes.includes(type.toLowerCase()) ? type.toLowerCase() : 'cube';

                let position, rotation, scale;
                parts.slice(1).forEach(part => {
                    const [key, value] = part.split(':').map(s => s.trim());
                    if (key === 'position') position = parseTransformString(value, [0,0.1,0]);
                    else if (key === 'rotation') rotation = parseTransformString(value, [0,0,0]);
                    else if (key === 'scale') scale = parseTransformString(value, [1,1,1]);
                });

                const defaultSize = 5;
                const objectSize = scale ? Math.max(scale.x, scale.y, scale.z) * defaultSize : defaultSize;
                const defaultY = (objectSize * 0.2) / 2 + 0.01;

                const newAIObject: StoryObject = {
                    id: Date.now().toString() + Math.random().toString(16).slice(2),
                    name: name,
                    type: objectType.charAt(0).toUpperCase() + objectType.slice(1),
                    color: AVAILABLE_COLORS[Math.floor(Math.random() * AVAILABLE_COLORS.length)],
                    size: objectSize,
                    position: position || { x: Math.random() * 2 - 1, y: defaultY, z: Math.random() * 2 - 1 },
                    rotation: rotation || { x: 0, y: 0, z: 0 },
                    scale: scale || { x: 1, y: 1, z: 1 },
                };
                newFrameInstance.objects.push(newAIObject);
            });
        }
        return newFrameInstance;
    });

    if (newFramesToAdd.length > 0) {
        setFrames(prevFrames => {
            const updatedFrames = [...prevFrames, ...newFramesToAdd];
            setCurrentFrameIndex(initialFrameIndexForNewBlock);
            return updatedFrames;
        });
        alert(`AI scene ideas applied. ${newFramesToAdd.length} new frame(s) created with AI suggestions!`);
    } else {
        const fallbackFrameName = `Frame ${frameNumberCounter.current}`;
        frameNumberCounter.current++;
        const newFrame = createNewFrameUtil(fallbackFrameName, baseFrameForCopy);
        newFrame.description = (frames[currentFrameIndex]?.description || '') + '\n\nAI Generated Idea:\n' + sceneBundleText;
        newFrame.camera.source = 'ai';
        newFrame.camera.timestamp = Date.now();
        newFrame.camera.updateId = syncManager.generateUpdateId();
        setFrames(prev => [...prev, newFrame]);
        setCurrentFrameIndex(frames.length);
        alert("AI idea applied to a new frame as description.");
    }
    setActiveSidebarPanel(null);
  }, [currentFrameIndex, frames, setActiveSidebarPanel, syncManager]);


  const handleDownload = async (format: 'png' | 'jpeg') => {
    const rendererInstance = appRendererRef.current;
    if (!rendererInstance?.domElement) {
     alert('3D renderer canvas is not available for export.');
     return;
    }

    if (currentFrame) {
      setIsExporting(true);
      await new Promise(resolve => setTimeout(resolve, 150));
      try {
        const image = rendererInstance.domElement.toDataURL(`image/${format}`, format === 'jpeg' ? 0.9 : 1.0);

        const link = document.createElement('a');
        link.download = `${currentFrame.name || 'storyboard-frame'}.${format}`;
        link.href = image;
        link.click();
      } catch (error) {
        console.error('Error exporting image:', error);
        alert('Failed to export image. See console for details.');
      } finally {
        setIsExporting(false);
      }
    } else {
      alert('Current frame not found for export.');
    }
  };

  const handlePrepareAssetForForm = (asset: AssetLibraryItem) => {
    setSelectedAssetForForm(asset);
    setEditingCharacterId(null); 
    setEditingObjectId(null);
  };

  const handleClearSelectedAssetForForm = () => {
    setSelectedAssetForForm(null);
  };

  const handleSetEditingCharacter = (characterId: string | null) => {
    setEditingCharacterId(characterId);
    setSelectedAssetForForm(null); 
    setEditingObjectId(null);
  };

  const handleSetEditingObject = (objectId: string | null) => {
    setEditingObjectId(objectId);
    setSelectedAssetForForm(null); 
    setEditingCharacterId(null);
  };


  const handleZoom = useCallback((direction: 'in' | 'out') => {
    if (!currentFrame) return;
    const zoomStepPercentage = 0.15; 
    let newZoom = currentFrame.camera.zoom;
    if (direction === 'in') {
      newZoom *= (1 + zoomStepPercentage);
    } else {
      newZoom *= (1 - zoomStepPercentage);
    }
    newZoom = Math.max(0.1, Math.min(20, newZoom)); 
    updateCurrentFrame({ 
        camera: { 
            ...currentFrame.camera, 
            zoom: newZoom, 
            source: 'ui', 
            timestamp: Date.now(),
            updateId: syncManager.generateUpdateId()
        } 
    });
  }, [currentFrame, updateCurrentFrame, syncManager]);

  const toggleCameraDamping = useCallback(() => setIsCameraDampingEnabled(prev => !prev), []);
  const toggleShowGrid = useCallback(() => setShowGrid(prev => !prev), []);
  const toggleShowGroundPlane = useCallback(() => setShowGroundPlane(prev => !prev), []);
  const toggleShowOrientationGizmo = useCallback(() => setShowOrientationGizmo(prev => !prev), []);
  const handleTimelinePlaybackSpeedChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const speed = parseInt(e.target.value, 10);
    if (!isNaN(speed) && speed > 0) {
      setTimelinePlaybackSpeedMs(speed);
    } else if (e.target.value === '') {
         setTimelinePlaybackSpeedMs(2000); // Default if cleared
    }
  }, []);

  const handleToggleFavoriteAsset = useCallback((assetId: string) => {
    setFavoriteAssetIds(prev => 
      prev.includes(assetId) ? prev.filter(id => id !== assetId) : [...prev, assetId]
    );
  }, []);

  const handleAssetPreview = useCallback((asset: AssetLibraryItem) => {
    // For now, just log. Later, this could open a modal with a larger preview.
    console.log("Previewing asset:", asset);
    alert(`Previewing: ${asset.name}\nModel: ${asset.modelUrl}\n(Implement actual preview modal later)`);
  }, []);


  const sidebarItems = [
    { id: SidebarPanelType.AI_PROMPT, label: 'AI Gen', icon: AIPromptIcon },
    { id: SidebarPanelType.ELEMENTS, label: 'Elements', icon: CubeIcon }, 
    { id: SidebarPanelType.CAMERA, label: 'Camera', icon: SidebarCameraIcon },
    { id: SidebarPanelType.LIGHTING, label: 'Lighting', icon: LightBulbIcon },
    { id: SidebarPanelType.EFFECTS, label: 'Effects', icon: EffectsIcon },
    { id: SidebarPanelType.FRAME_SETTINGS, label: 'Frame Config', icon: BookOpenIcon },
    { id: SidebarPanelType.VIEWER_SETTINGS, label: 'Viewer Settings', icon: CogIcon },
  ];

  const renderSidebarPanelContent = () => {
    if (!currentFrame &&
        activeSidebarPanel !== null && // Ensure activeSidebarPanel is not null for the checks
        activeSidebarPanel !== SidebarPanelType.AI_PROMPT &&
        activeSidebarPanel !== SidebarPanelType.ELEMENTS && 
        activeSidebarPanel !== SidebarPanelType.EFFECTS &&
        activeSidebarPanel !== SidebarPanelType.VIEWER_SETTINGS 
    ) {
        // Given the above conditions, activeSidebarPanel must be one of:
        // SidebarPanelType.CAMERA, SidebarPanelType.LIGHTING, SidebarPanelType.FRAME_SETTINGS
        if (activeSidebarPanel === SidebarPanelType.FRAME_SETTINGS) {
             return <div className="p-4 text-gray-500">No frame selected. Please add or select a frame to see its settings.</div>;
        // Fix: Replaced the problematic 'if' with an 'else if' for CAMERA or LIGHTING.
        // If the outer 'if' conditions are met, and activeSidebarPanel is not FRAME_SETTINGS,
        // it must be CAMERA or LIGHTING for this block to be relevant (as AI_PROMPT, ELEMENTS, etc. are excluded).
        } else if (activeSidebarPanel === SidebarPanelType.CAMERA || activeSidebarPanel === SidebarPanelType.LIGHTING) {
            // These panels require a frame.
             return <div className="p-4 text-gray-500">No frame selected. Please add or select a frame.</div>;
        }
        // If activeSidebarPanel was null and somehow passed the outer checks (it wouldn't if null checks included properly),
        // or if it's a type not handled here, it will fall through.
        // The default case of the switch statement later handles `null` activeSidebarPanel.
    }

    switch (activeSidebarPanel) {
      case SidebarPanelType.ELEMENTS:
        return <ElementsPanel
                  currentFrame={currentFrame}
                  onAddCharacter={addCharacter}
                  onUpdateCharacter={updateCharacter}
                  onRemoveCharacter={removeCharacter}
                  onAddObject={addObject}
                  onUpdateObject={updateObject}
                  onRemoveObject={removeObject}
                  selectedAssetForForm={selectedAssetForForm}
                  onPrepareAssetForForm={handlePrepareAssetForForm}
                  onClearSelectedAsset={handleClearSelectedAssetForForm}
                  editingCharacterId={editingCharacterId}
                  onSetEditingCharacterId={handleSetEditingCharacter}
                  editingObjectId={editingObjectId}
                  onSetEditingObjectId={handleSetEditingObject}
                  // New props for AssetLibraryPanel enhancements
                  favoriteAssetIds={favoriteAssetIds}
                  recentlyUsedAssetIds={recentlyUsedAssetIds}
                  onToggleFavoriteAsset={handleToggleFavoriteAsset}
                  onAssetPreview={handleAssetPreview}
                  onAssetUsed={handleAssetUsed} // To update recently used
                />;
      case SidebarPanelType.CAMERA:
        if (!currentFrame) return <div className="p-4 text-gray-500">Select a frame to control its camera.</div>;
        return <CameraControlsTab
                  camera={currentFrame.camera}
                  onUpdateCamera={updateCameraFromControls} 
                  defaultCameraConfig={DEFAULT_CAMERA_CONFIG} 
                  cameraPresets={CAMERA_PRESETS}
                  onApplyPreset={applyCameraPreset}
                />;
      case SidebarPanelType.LIGHTING:
        if (!currentFrame) return <div className="p-4 text-gray-500">Select a frame to manage its lighting.</div>;
        return <LightingPanel
                  lights={currentFrame.lights}
                  onAddLight={addLight}
                  onUpdateLight={updateLight}
                  onRemoveLight={removeLight}
                  allSceneCharacters={currentFrame.characters}
                  allSceneObjects={currentFrame.objects}
                />;
      case SidebarPanelType.EFFECTS:
        return <Panel title="Effects"><p className="text-sm text-gray-400">Effects configuration coming soon.</p></Panel>;
      case SidebarPanelType.FRAME_SETTINGS:
        if (!currentFrame) return <div className="p-4 text-gray-500">Select a frame to configure its details.</div>;
        return <Panel title={`Frame Settings: ${currentFrame.name}`}>
              <div>
                <label htmlFor="sceneName" className="block text-sm font-medium text-gray-300">Frame Name</label>
                <input
                  type="text"
                  id="sceneName"
                  value={currentFrame.name}
                  onChange={(e) => updateCurrentFrame({ name: e.target.value })}
                  className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                />
              </div>
              <div className="mt-4">
                <label htmlFor="sceneDescription" className="block text-sm font-medium text-gray-300">Frame Description</label>
                <textarea
                  id="sceneDescription"
                  rows={5}
                  value={currentFrame.description || ''}
                  onChange={(e) => updateCurrentFrame({ description: e.target.value })}
                  className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                />
              </div>
              {currentFrame.externalAIPrompt && (
                <div className="mt-4">
                  <label htmlFor="externalAIPromptDisplay" className="block text-sm font-medium text-gray-300">External AI Prompt</label>
                  <textarea
                    id="externalAIPromptDisplay"
                    readOnly
                    rows={5}
                    value={currentFrame.externalAIPrompt}
                    className="mt-1 block w-full bg-gray-600 border border-gray-500 rounded-md shadow-sm py-2 px-3 focus:outline-none sm:text-sm text-gray-200"
                    aria-label="External AI Prompt for image generation"
                  />
                  <Button
                    onClick={() => {
                      if (currentFrame.externalAIPrompt) {
                        navigator.clipboard.writeText(currentFrame.externalAIPrompt)
                          .then(() => alert('External AI prompt copied to clipboard!'))
                          .catch(err => console.error('Failed to copy prompt: ', err));
                      }
                    }}
                    variant="secondary"
                    size="sm"
                    className="mt-2"
                  >
                    Copy Prompt
                  </Button>
                </div>
              )}
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-300">Background Color</label>
                <div className="mt-1 flex flex-wrap gap-2">
                  {BACKGROUND_COLORS.map(color => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => updateCurrentFrame({ backgroundColor: color })}
                      className={`w-8 h-8 rounded-full border-2 ${currentFrame.backgroundColor === color ? 'border-white ring-2 ring-indigo-400' : 'border-transparent hover:border-gray-500'}`}
                      style={{ backgroundColor: color }}
                      title={color}
                      aria-label={`Set background color to ${color}`}
                    />
                  ))}
                </div>
              </div>
        </Panel>;
      case SidebarPanelType.VIEWER_SETTINGS:
        return <Panel title="Viewer Settings">
          <div className="space-y-3 mt-3">
            {/* Camera Damping Toggle */}
            <div className="flex items-center justify-between">
              <label htmlFor="cameraDampingToggle" className="text-sm font-medium text-gray-300">
                Camera Damping
                <p className="text-xs text-gray-500">(Smoother camera, may impact performance)</p>
              </label>
              <button
                type="button" id="cameraDampingToggle" onClick={toggleCameraDamping}
                className={`${isCameraDampingEnabled ? 'bg-indigo-600' : 'bg-gray-600'} relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500`}
                role="switch" aria-checked={isCameraDampingEnabled}
              >
                <span className={`${isCameraDampingEnabled ? 'translate-x-6' : 'translate-x-1'} inline-block w-4 h-4 transform bg-white rounded-full transition-transform`}/>
              </button>
            </div>

            {/* Show Grid Toggle */}
            <div className="flex items-center justify-between">
              <label htmlFor="showGridToggle" className="text-sm font-medium text-gray-300">Show Grid</label>
              <button
                type="button" id="showGridToggle" onClick={toggleShowGrid}
                className={`${showGrid ? 'bg-indigo-600' : 'bg-gray-600'} relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500`}
                role="switch" aria-checked={showGrid}
              >
                <span className={`${showGrid ? 'translate-x-6' : 'translate-x-1'} inline-block w-4 h-4 transform bg-white rounded-full transition-transform`}/>
              </button>
            </div>

            {/* Show Ground Plane Toggle */}
            <div className="flex items-center justify-between">
              <label htmlFor="showGroundPlaneToggle" className="text-sm font-medium text-gray-300">Show Ground Plane</label>
              <button
                type="button" id="showGroundPlaneToggle" onClick={toggleShowGroundPlane}
                className={`${showGroundPlane ? 'bg-indigo-600' : 'bg-gray-600'} relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500`}
                role="switch" aria-checked={showGroundPlane}
              >
                <span className={`${showGroundPlane ? 'translate-x-6' : 'translate-x-1'} inline-block w-4 h-4 transform bg-white rounded-full transition-transform`}/>
              </button>
            </div>
            
            {/* Show Orientation Gizmo Toggle */}
            <div className="flex items-center justify-between">
              <label htmlFor="showOrientationGizmoToggle" className="text-sm font-medium text-gray-300">Show Orientation Gizmo</label>
              <button
                type="button" id="showOrientationGizmoToggle" onClick={toggleShowOrientationGizmo}
                className={`${showOrientationGizmo ? 'bg-indigo-600' : 'bg-gray-600'} relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500`}
                role="switch" aria-checked={showOrientationGizmo}
              >
                <span className={`${showOrientationGizmo ? 'translate-x-6' : 'translate-x-1'} inline-block w-4 h-4 transform bg-white rounded-full transition-transform`}/>
              </button>
            </div>
            
            {/* Timeline Playback Speed */}
            <div className="mt-4">
                <label htmlFor="timelinePlaybackSpeed" className="block text-sm font-medium text-gray-300">Timeline Playback Speed (ms)</label>
                <input
                  type="number"
                  id="timelinePlaybackSpeed"
                  value={timelinePlaybackSpeedMs}
                  onChange={handleTimelinePlaybackSpeedChange}
                  min="100"
                  step="100"
                  className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                />
              </div>
          </div>
        </Panel>;
      case SidebarPanelType.AI_PROMPT:
        return <PromptGenerator onApplyPrompt={handleScenePromptApplied} />;
      default:
        return <div className="p-4 text-center text-gray-500">Select an option from the menu.</div>;
    }
  };

  const toggleTimelineSidebar = () => setIsTimelineSidebarOpen(!isTimelineSidebarOpen);

  return (
    <div className="flex flex-col h-screen bg-gray-900 text-gray-100 overflow-hidden">
      <Header title={APP_TITLE} />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          items={sidebarItems}
          activePanel={activeSidebarPanel}
          onSelectItem={(panel) => setActiveSidebarPanel( prev => prev === panel ? null : panel)}
        />

        <main className="flex-1 flex overflow-hidden">
          {activeSidebarPanel && (
            <div className="w-64 md:w-72 bg-gray-800 border-r border-gray-700 overflow-y-auto shadow-lg h-full flex-shrink-0 custom-scrollbar">
              {renderSidebarPanelContent()}
            </div>
          )}
          <div className="flex-1 flex flex-col p-3 md:p-4 overflow-y-auto">
            <MainViewer
                frame={currentFrame} 
                isExporting={isExporting}
                onUpdateCamera={handleCameraUpdateFromViewer} 
                isTimelineSidebarOpen={isTimelineSidebarOpen}
                appRendererRef={appRendererRef}
                onAddFrame={addFrame}
                isCameraDampingEnabled={isCameraDampingEnabled}
                showGrid={showGrid}
                showGroundPlane={showGroundPlane}
                showOrientationGizmo={showOrientationGizmo}
            />
            {currentFrame && ( 
              <ControlsPanel
                onDownloadPNG={() => handleDownload('png')}
                onDownloadJPG={() => handleDownload('jpeg')}
                onZoomIn={() => handleZoom('in')}
                onZoomOut={() => handleZoom('out')}
              />
            )}
          </div>
        </main>

        <aside
            className={`bg-gray-850 border-l border-gray-700 flex flex-col overflow-hidden transition-all duration-300 ease-in-out
                        ${isTimelineSidebarOpen ? 'w-44 md:w-48 p-2' : 'w-0 p-0'}`}
            aria-label="Timeline Sidebar"
        >
          {isTimelineSidebarOpen && (
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between mb-2 px-1">
                <h3 className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">Timeline</h3>
                <IconButton onClick={toggleTimelineSidebar} tooltip="Toggle Timeline Sidebar">
                  <PanelRightCloseIcon className="w-5 h-5" />
                </IconButton>
              </div>
                <div className="grid grid-cols-3 gap-1 mb-3 px-1">
                    <button
                        onClick={addFrame}
                        className="p-1 bg-indigo-600 hover:bg-indigo-500 rounded text-white flex items-center justify-center text-xs"
                        title="Add New Frame"
                    >
                        <PlusIcon className="w-3 h-3 mr-1" /> New
                    </button>
                    <button
                        onClick={duplicateCurrentFrame}
                        disabled={!currentFrame}
                        className="p-1 bg-blue-600 hover:bg-blue-500 rounded text-white flex items-center justify-center text-xs disabled:opacity-50"
                        title="Duplicate Current Frame"
                    >
                        <DocumentDuplicateIcon className="w-3 h-3 mr-1" /> Dupe
                    </button>
                    <button
                        onClick={deleteCurrentFrame}
                        disabled={frames.length === 0}
                        className="p-1 bg-red-600 hover:bg-red-500 rounded text-white flex items-center justify-center text-xs disabled:opacity-50"
                        title="Delete Current Frame"
                    >
                        <TrashIcon className="w-3 h-3 mr-1" /> Del
                    </button>
                </div>
              <Timeline
                frames={frames}
                currentFrameIndex={currentFrameIndex}
                onSelectFrame={selectFrame}
                onAddFrame={addFrame}
                isPlaying={isPlaying}
                onTogglePlay={togglePlay}
              />
            </div>
          )}
        </aside>
        {!isTimelineSidebarOpen && (
             <div className="fixed right-0 top-1/2 transform -translate-y-1/2 z-20">
                <IconButton
                    onClick={toggleTimelineSidebar}
                    tooltip="Open Timeline Sidebar"
                    className="bg-gray-800 hover:bg-indigo-600 p-3 rounded-l-md shadow-lg"
                >
                    <PanelRightOpenIcon className="w-5 h-5" />
                </IconButton>
            </div>
        )}
      </div>
    </div>
  );
};

export default App;