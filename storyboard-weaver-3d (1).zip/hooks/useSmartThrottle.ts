import { useCallback, useRef, useEffect } from 'react';

interface SmartThrottleOptions {
  delay: number;
  immediate?: boolean; // Execute on the leading edge
  trailing?: boolean;  // Execute on the trailing edge
}

export function useSmartThrottle<T extends (...args: any[]) => void>(
  callback: T,
  options: SmartThrottleOptions
): T {
  const { delay, immediate = false, trailing = true } = options;

  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastCallTimeRef = useRef<number>(0);
  const lastArgsRef = useRef<Parameters<T> | undefined>(undefined);
  const hasBeenCalledRecentlyRef = useRef<boolean>(false);

  const throttledCallback = useCallback((...args: Parameters<T>) => {
    const now = Date.now();
    lastArgsRef.current = args;

    const executeCallback = (callArgs: Parameters<T>) => {
      callback(...callArgs);
      lastCallTimeRef.current = Date.now();
    };

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }

    if (immediate && !hasBeenCalledRecentlyRef.current) {
      executeCallback(args);
      hasBeenCalledRecentlyRef.current = true;
      // Set a timeout to reset hasBeenCalledRecentlyRef after the delay,
      // allowing another immediate call after the cooldown period.
      timeoutRef.current = setTimeout(() => {
        hasBeenCalledRecentlyRef.current = false;
        // If trailing is also true and new args came in during cooldown, execute them.
        if (trailing && lastArgsRef.current && Date.now() - lastCallTimeRef.current >= delay) {
           executeCallback(lastArgsRef.current);
        }
      }, delay);
    } else if (trailing) {
      // If not immediate, or if immediate has happened and trailing is on,
      // set up the trailing call.
      timeoutRef.current = setTimeout(() => {
        // Ensure we execute with the latest arguments if they were updated.
        if (lastArgsRef.current) {
          executeCallback(lastArgsRef.current);
        }
        hasBeenCalledRecentlyRef.current = false; // Reset for next immediate cycle
        timeoutRef.current = null;
      }, delay - (now - lastCallTimeRef.current)); // Adjust delay if called within window
    }
     // If neither immediate nor trailing, this setup won't call the callback.
     // This usually means one of them should be true. Default is trailing=true.
  }, [callback, delay, immediate, trailing]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return throttledCallback as T;
}
