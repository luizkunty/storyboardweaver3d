
import { AssetLibraryItem } from './types';

export const ASSET_LIBRARY: AssetLibraryItem[] = [
  // === CHARACTERS ===
  {
    id: 'lib-char-fox',
    name: 'Fox (Animated)',
    type: 'character',
    category: 'Animals',
    thumbnailUrl: 'https://picsum.photos/seed/animalfox/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Fox/glTF-Binary/Fox.glb',
    defaultScale: { x: 0.025, y: 0.025, z: 0.025 },
    yOffset: 0,
    description: 'A charming, animated fox. (KhronosGroup Sample)',
  },
  {
    id: 'lib-char-generic-human',
    name: 'Human Figure (Skinned)',
    type: 'character',
    category: 'Humans - Adult',
    thumbnailUrl: 'https://picsum.photos/seed/humanskin/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/SimpleSkin/glTF-Embedded/SimpleSkin.gltf',
    defaultScale: { x: 0.5, y: 0.5, z: 0.5 },
    yOffset: 0.82, 
    description: 'Generic skinned human figure. Useful as a base. (KhronosGroup Sample)',
  },
  {
    id: 'lib-char-casual-man',
    name: 'Man (Casual)',
    type: 'character',
    category: 'Humans - Adult',
    thumbnailUrl: 'https://picsum.photos/seed/humancasualman/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/SimpleSkin/glTF-Embedded/SimpleSkin.gltf',
    defaultScale: { x: 0.52, y: 0.52, z: 0.52 }, 
    yOffset: 0.85,
    description: 'Represents an adult male in casual attire. (Uses SimpleSkin)',
  },
  {
    id: 'lib-char-business-woman',
    name: 'Woman (Business)',
    type: 'character',
    category: 'Humans - Adult',
    thumbnailUrl: 'https://picsum.photos/seed/humanbusinesswoman/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/SimpleSkin/glTF-Embedded/SimpleSkin.gltf',
    defaultScale: { x: 0.48, y: 0.48, z: 0.48 }, 
    yOffset: 0.78,
    description: 'Represents an adult female in business attire. (Uses SimpleSkin)',
  },
  {
    id: 'lib-char-child',
    name: 'Child Figure',
    type: 'character',
    category: 'Humans - Child',
    thumbnailUrl: 'https://picsum.photos/seed/humanchild/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/SimpleSkin/glTF-Embedded/SimpleSkin.gltf',
    defaultScale: { x: 0.35, y: 0.35, z: 0.35 }, 
    yOffset: 0.58,
    description: 'Represents a child. (Uses SimpleSkin, scaled down)',
  },
   {
    id: 'lib-char-robot-brainstem',
    name: 'Brain Bot',
    type: 'character',
    category: 'Robots & Sci-Fi',
    thumbnailUrl: 'https://picsum.photos/seed/robotbrain/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/BrainStem/glTF-Binary/BrainStem.glb',
    defaultScale: { x: 0.8, y: 0.8, z: 0.8 },
    yOffset: 0.5, 
    description: 'Organic-looking brain bot. (KhronosGroup BrainStem)',
  },
  {
    id: 'lib-char-robot-headbot', // Changed ID from lib-char-robot-sponza
    name: 'Head Bot (Pilot)',       // Changed Name
    type: 'character',
    category: 'Robots & Sci-Fi',
    thumbnailUrl: 'https://picsum.photos/seed/robotheadpilot/100/80', // New seed for thumbnail
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/FlightHelmet/glTF/FlightHelmet.gltf', // Using FlightHelmet
    defaultScale: { x: 2.0, y: 2.0, z: 2.0 }, // Adjusted scale for character use
    yOffset: 0.3, // Adjusted yOffset (FlightHelmet's origin is near its base)
    description: 'A pilot helmet character, representing a simple bot head. (Uses FlightHelmet model)',
  },


  // === OBJECTS ===

  // Sci-Fi Props
  {
    id: 'lib-obj-damagedhelmet',
    name: 'Damaged Sci-Fi Helmet',
    type: 'object',
    category: 'Sci-Fi Props',
    thumbnailUrl: 'https://picsum.photos/seed/scifihelmetdamaged/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/DamagedHelmet/glTF-Binary/DamagedHelmet.glb',
    defaultScale: { x: 0.8, y: 0.8, z: 0.8 },
    yOffset: 0.4, 
    description: 'Detailed damaged sci-fi helmet. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-scifihelmet-clean',
    name: 'Sci-Fi Helmet (Clean)',
    type: 'object',
    category: 'Sci-Fi Props',
    thumbnailUrl: 'https://picsum.photos/seed/scifihelmetclean/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/SciFiHelmet/glTF-Binary/SciFiHelmet.glb',
    defaultScale: { x: 0.8, y: 0.8, z: 0.8 },
    yOffset: 0.4,
    description: 'A clean, futuristic sci-fi helmet. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-flighthelmet',
    name: 'Flight Helmet',
    type: 'object',
    category: 'Sci-Fi Props', // Or Props - General
    thumbnailUrl: 'https://picsum.photos/seed/flighthelmet/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/FlightHelmet/glTF/FlightHelmet.gltf',
    defaultScale: { x: 2.5, y: 2.5, z: 2.5 }, // Model is somewhat small
    yOffset: 0.3,
    description: 'A detailed flight helmet. (KhronosGroup Sample)',
  },


  // Props - General
  {
    id: 'lib-obj-lantern',
    name: 'Khronos Lantern',
    type: 'object',
    category: 'Props - General',
    thumbnailUrl: 'https://picsum.photos/seed/propslantern/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Lantern/glTF-Binary/Lantern.glb',
    defaultScale: { x: 0.1, y: 0.1, z: 0.1 }, 
    yOffset: 0.05, 
    description: 'Classic style lantern. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-wooden-crate',
    name: 'Wooden Crate Box',
    type: 'object',
    category: 'Props - General',
    thumbnailUrl: 'https://picsum.photos/seed/propscrate/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Box/glTF-Binary/Box.glb',
    defaultScale: { x: 0.5, y: 0.5, z: 0.5 },
    yOffset: 0.25, 
    description: 'A simple wooden crate. (KhronosGroup Box Sample)',
  },
  {
    id: 'lib-obj-waterbottle',
    name: 'Water Bottle',
    type: 'object',
    category: 'Props - General',
    thumbnailUrl: 'https://picsum.photos/seed/propswaterbottle/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/WaterBottle/glTF-Binary/WaterBottle.glb',
    defaultScale: {x:0.5, y:0.5, z:0.5},
    yOffset: 0.2, 
    description: 'A plastic water bottle. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-barramundi',
    name: 'Barramundi Fish',
    type: 'object',
    category: 'Props - General', // Or Animals if it were a character
    thumbnailUrl: 'https://picsum.photos/seed/fishbarramundi/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/BarramundiFish/glTF-Binary/BarramundiFish.glb',
    defaultScale: {x:0.5, y:0.5, z:0.5},
    yOffset: 0, // Model origin seems fine
    description: 'A Barramundi fish model. (KhronosGroup Sample)',
  },

  // Food
  {
    id: 'lib-obj-avocado',
    name: 'Avocado',
    type: 'object',
    category: 'Food',
    thumbnailUrl: 'https://picsum.photos/seed/foodavocado/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Avocado/glTF-Binary/Avocado.glb',
    defaultScale: { x: 15, y: 15, z: 15 }, 
    yOffset: 0.15, 
    description: 'A ripe avocado. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-apple',
    name: 'Red Apple',
    type: 'object',
    category: 'Food',
    thumbnailUrl: 'https://picsum.photos/seed/foodapple/100/80',
    // No direct apple in Khronos, using a sphere as placeholder conceptually for data structure
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/MetalRoughSpheres/glTF-Binary/MetalRoughSpheres.glb', // Placeholder model
    defaultScale: { x: 0.1, y: 0.1, z: 0.1 },
    yOffset: 0.05,
    description: 'A shiny red apple (uses PBR Spheres model as placeholder).',
  },

  // Vehicles
  {
    id: 'lib-obj-cesiummilktruck',
    name: 'Milk Truck',
    type: 'object',
    category: 'Vehicles',
    thumbnailUrl: 'https://picsum.photos/seed/vehicletruck/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/CesiumMilkTruck/glTF-Binary/CesiumMilkTruck.glb',
    defaultScale: { x: 0.3, y: 0.3, z: 0.3 },
    yOffset: 0, 
    description: 'A Cesium milk truck. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-buggy',
    name: 'Dune Buggy (Animated)',
    type: 'object',
    category: 'Vehicles',
    thumbnailUrl: 'https://picsum.photos/seed/vehiclebuggy/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Buggy/glTF-Binary/Buggy.glb',
    defaultScale: { x: 0.3, y: 0.3, z: 0.3 },
    yOffset: 0.1, 
    description: 'A small, animated dune buggy. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-drone',
    name: 'Delivery Drone',
    type: 'object',
    category: 'Vehicles', // Or Sci-Fi
    thumbnailUrl: 'https://picsum.photos/seed/vehicledrone/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Drone/glTF-Binary/Drone.glb',
    defaultScale: { x: 0.5, y: 0.5, z: 0.5 },
    yOffset: 0.2,
    description: 'A delivery drone model. (KhronosGroup Sample)',
  },
  
  // Furniture
  {
    id: 'lib-obj-bookshelf',
    name: 'Simple Bookshelf',
    type: 'object',
    category: 'Furniture',
    thumbnailUrl: 'https://picsum.photos/seed/furniturebookshelf/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Shelf/glTF-Binary/Shelf.glb',
    defaultScale: {x: 0.5, y: 0.5, z: 0.5},
    yOffset: 0.3, 
    description: 'A simple bookshelf with items. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-corset', 
    name: 'Corset (Display)',
    type: 'object',
    category: 'Furniture',
    thumbnailUrl: 'https://picsum.photos/seed/furniturecorset/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Corset/glTF-Binary/Corset.glb',
    defaultScale: {x:8, y:8, z:8}, 
    yOffset: 0.7,
    description: 'A vintage corset, could be on a display stand. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-chair',
    name: 'Office Chair',
    type: 'object',
    category: 'Furniture',
    thumbnailUrl: 'https://picsum.photos/seed/furniturechair/100/80',
    // No direct chair in Khronos, using a simple box conceptually
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Box/glTF-Binary/Box.glb', // Placeholder
    defaultScale: {x: 0.3, y:0.5, z:0.3},
    yOffset: 0.25,
    description: 'A generic office chair (uses Box model as placeholder).',
  },


  // Nature & Decor
  {
    id: 'lib-obj-duck',
    name: 'Rubber Duck',
    type: 'object',
    category: 'Nature & Decor', 
    thumbnailUrl: 'https://picsum.photos/seed/decorrubberduck/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Duck/glTF-Binary/Duck.glb',
    defaultScale: { x: 0.5, y: 0.5, z: 0.5 },
    yOffset: 0.1, 
    description: 'A classic rubber duck. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-metalroughspheres',
    name: 'PBR Spheres',
    type: 'object',
    category: 'Nature & Decor', 
    thumbnailUrl: 'https://picsum.photos/seed/decorspheres/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/MetalRoughSpheres/glTF-Binary/MetalRoughSpheres.glb',
    defaultScale: {x: 0.5, y: 0.5, z: 0.5},
    yOffset: 0.25, 
    description: 'Spheres demonstrating PBR materials. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-potted-plant',
    name: 'Potted Plant',
    type: 'object',
    category: 'Nature & Decor',
    thumbnailUrl: 'https://picsum.photos/seed/decorplant/100/80',
    // No direct plant in Khronos, using cylinder + sphere conceptually
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/SimpleSparseAccessor/glTF/SimpleSparseAccessor.gltf', // Placeholder
    defaultScale: { x: 0.3, y: 0.3, z: 0.3 },
    yOffset: 0.15,
    description: 'A generic potted plant (uses Sparse Accessor model as placeholder).',
  },

  // Technology
  {
    id: 'lib-obj-boombox',
    name: 'BoomBox',
    type: 'object',
    category: 'Technology',
    thumbnailUrl: 'https://picsum.photos/seed/techboombox/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/BoomBox/glTF-Binary/BoomBox.glb',
    defaultScale: {x:50, y:50, z:50}, 
    yOffset: 0.15,
    description: 'A retro boombox. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-antique-camera',
    name: 'Antique Camera',
    type: 'object',
    category: 'Technology',
    thumbnailUrl: 'https://picsum.photos/seed/techcamera/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/AntiqueCamera/glTF-Binary/AntiqueCamera.glb',
    defaultScale: {x:0.2, y:0.2, z:0.2},
    yOffset: 0.05,
    description: 'An antique film camera. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-reciprocating-saw',
    name: 'Reciprocating Saw',
    type: 'object',
    category: 'Technology', 
    thumbnailUrl: 'https://picsum.photos/seed/techsaw/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/ReciprocatingSaw/glTF-Binary/ReciprocatingSaw.glb',
    defaultScale: {x:0.2, y:0.2, z:0.2},
    yOffset: 0.05,
    description: 'A power tool. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-old-computer',
    name: 'Vintage Computer',
    type: 'object',
    category: 'Technology',
    thumbnailUrl: 'https://picsum.photos/seed/techcomputer/100/80',
    // Using BoxAnimated as a placeholder shape
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/BoxAnimated/glTF-Binary/BoxAnimated.glb',
    defaultScale: { x: 0.4, y: 0.3, z: 0.45 },
    yOffset: 0.15,
    description: 'A vintage desktop computer (uses Animated Box as placeholder).',
  },
  
  // Urban 
   {
    id: 'lib-obj-box-animated',
    name: 'Animated Cube',
    type: 'object',
    category: 'Urban', 
    thumbnailUrl: 'https://picsum.photos/seed/urbananimatedbox/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/BoxAnimated/glTF-Binary/BoxAnimated.glb',
    defaultScale: { x: 0.4, y: 0.4, z: 0.4 },
    yOffset: 0.2,
    description: 'An animated box. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-traffic-cone',
    name: 'Traffic Cone',
    type: 'object',
    category: 'Urban',
    thumbnailUrl: 'https://picsum.photos/seed/urbantrafficcone/100/80',
    // Using Cylinder as placeholder
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/SimpleMaterial/glTF/SimpleMaterial.gltf', // Placeholder (it's a cylinder)
    defaultScale: { x: 0.2, y: 0.4, z: 0.2 },
    yOffset: 0.2,
    description: 'A traffic cone (uses SimpleMaterial cylinder as placeholder).',
  },


  // Abstract & Art
  {
    id: 'lib-obj-gearbox',
    name: 'Gearbox Assembly',
    type: 'object',
    category: 'Abstract & Art', 
    thumbnailUrl: 'https://picsum.photos/seed/artgearbox/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/GearboxAssy/glTF-Binary/GearboxAssy.glb',
    defaultScale: { x: 0.3, y: 0.3, z: 0.3 },
    yOffset: 0, 
    description: 'A detailed gearbox assembly. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-suzanne',
    name: 'Suzanne (Blender Monkey)',
    type: 'object',
    category: 'Abstract & Art',
    thumbnailUrl: 'https://picsum.photos/seed/artsuzanne/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Suzanne/glTF-Binary/Suzanne.glb',
    defaultScale: { x: 0.4, y: 0.4, z: 0.4 },
    yOffset: 0.25, 
    description: 'The Blender monkey mascot. (KhronosGroup Sample)',
  },
  {
    id: 'lib-obj-orb',
    name: 'Mysterious Orb',
    type: 'object',
    category: 'Abstract & Art',
    thumbnailUrl: 'https://picsum.photos/seed/artorb/100/80',
    modelUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/MetalRoughSpheres/glTF-Binary/MetalRoughSpheres.glb', // Using one of the spheres
    defaultScale: { x: 0.3, y: 0.3, z: 0.3 },
    yOffset: 0.15,
    description: 'A mysterious orb with PBR material (uses one PBR sphere).',
  },
];
