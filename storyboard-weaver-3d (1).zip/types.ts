

// Fix: Removed unused import from './constants' to prevent circular dependencies.
// The types defined here do not directly use values like DEFAULT_CAMERA_CONFIG or BACKGROUND_COLORS for their definitions.
// import { DEFAULT_CAMERA_CONFIG, BACKGROUND_COLORS } from './constants'; // Keep only what's needed for type-level or direct use not creating cycles

export interface CameraConfig {
  position: { x: number; y: number; z: number };
  rotation: { x: number; y: number; z: number }; // Euler angles in degrees
  fov: number;
  zoom: number;
  timestamp?: number; // Timestamp of the last update
  source?: 'ui' | 'orbitControls' | 'orbitControlsScroll' | 'preset' | 'appInternal' | 'ai' | 'duplicate'; // Source of the update
  updateId?: string; // Unique ID for each update to prevent conflicts
}

export interface EditableCameraConfig {
  position: { x: string; y: string; z: string };
  rotation: { x: string; y: string; z: string };
  fov: string;
  zoom: string;
  timestamp?: number; // Optional: Can be carried over for reference
  source?: string;    // Optional: Can be carried over for reference
  updateId?: string;  // Optional: Can be carried over for reference
}

export interface AssetLibraryItem {
  id: string;
  name: string;
  type: 'character' | 'object';
  category?: string; // e.g., "Humans - Adult", "Vehicles", "Sci-Fi Props"
  thumbnailUrl: string;
  modelUrl: string;
  defaultScale?: { x: number; y: number; z: number };
  yOffset?: number; // To adjust ground position for models not centered at their base
  description?: string;
  tags?: string[]; // New field for searchable tags
}

export interface StoryCharacter {
  id: string;
  name: string;
  ageBracket?: string;
  pose: string;
  movement: string;
  color: string;
  position?: { x: number; y: number; z: number };
  rotation?: { x: number; y: number; z: number };
  scale?: { x: number; y: number; z: number }; // Original scale for primitives or adjustment for models
  threeUUID?: string;
  modelUrl?: string; // URL to the GLTF/GLB model
  assetScale?: { x: number; y: number; z: number }; // Intrinsic scale of the loaded asset
  yOffset?: number; // Y-offset for proper ground placement of the model
}

export interface StoryObject {
  id: string;
  name: string;
  type: string;
  color: string;
  size: number;
  position?: { x: number; y: number; z: number };
  rotation?: { x: number; y: number; z: number };
  scale?: { x: number; y: number; z: number }; // Original scale for primitives or adjustment for models
  threeUUID?: string;
  modelUrl?: string; // URL to the GLTF/GLB model
  assetScale?: { x: number; y: number; z: number }; // Intrinsic scale of the loaded asset
  yOffset?: number; // Y-offset for proper ground placement of the model
}

export type LightType = 'Ambient' | 'Directional' | 'Point' | 'Spot';

export interface LightConfig {
  id: string;
  name: string;
  type: LightType;
  color: string; // hex string
  intensity: number; // 0 to N
  position: { x: number; y: number; z: number }; // For Directional, Point, Spot
  target: { x: number; y: number; z: number }; // For Directional (direction), Spot
  angle?: number; // For Spot (degrees)
  penumbra?: number; // For Spot (0-1)
  decay?: number; // For Point, Spot (0-2 typically)
  castShadow: boolean;
  threeUUID?: string; // To map to THREE.js light object
}

export interface Frame {
  id:string;
  name: string;
  description?: string;
  camera: CameraConfig;
  characters: StoryCharacter[];
  objects: StoryObject[];
  lights: LightConfig[]; // Added lights
  effects: string[];
  thumbnailUrl: string;
  backgroundColor: string;
  externalAIPrompt?: string;
}

export enum SidebarPanelType {
  ELEMENTS = 'ELEMENTS',
  CAMERA = 'CAMERA',
  LIGHTING = 'LIGHTING',
  EFFECTS = 'EFFECTS',
  FRAME_SETTINGS = 'FRAME_SETTINGS', // Renamed from SETTINGS
  VIEWER_SETTINGS = 'VIEWER_SETTINGS', // New panel type
  AI_PROMPT = 'AI_PROMPT',
}

export interface CameraPreset {
  name: string;
  config: Partial<CameraConfig>;
}

export type PrimitiveType = 'character' | 'object' | 'wall' | 'room';

// createNewFrameUtil moved to frameUtils.ts