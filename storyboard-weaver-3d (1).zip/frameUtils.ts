
import { Frame, CameraConfig } from './types';
import {
    DEFAULT_CAMERA_CONFIG,
    BACKGROUND_COLORS,
    DEFAULT_AMBIENT_LIGHT_CONFIG,
    DEFAULT_DIRECTIONAL_LIGHT_CONFIG
} from './constants';
import { CameraSyncManager } from './utils/cameraSyncManager'; // Import the manager

export const createNewFrameUtil = (name: string, frameToCopy?: Frame | null): Frame => {
  const frameId = Date.now().toString();
  const syncManager = CameraSyncManager.getInstance(); // Get singleton instance

  if (frameToCopy) {
    // For duplicated frames, ensure deep copies of nested objects too
    // Create a new camera object with fresh sync metadata
    const copiedCamera = JSON.parse(JSON.stringify(frameToCopy.camera));
    return {
      id: frameId,
      name: name,
      description: frameToCopy.description || '',
      camera: {
        ...copiedCamera, // Spread existing values like position, fov, zoom
        timestamp: Date.now(),
        source: 'duplicate', // Specific source for duplicated frames
        updateId: syncManager.generateUpdateId(),
      },
      characters: JSON.parse(JSON.stringify(frameToCopy.characters)),
      objects: JSON.parse(JSON.stringify(frameToCopy.objects)),
      lights: JSON.parse(JSON.stringify(frameToCopy.lights)),
      effects: JSON.parse(JSON.stringify(frameToCopy.effects)),
      backgroundColor: frameToCopy.backgroundColor,
      thumbnailUrl: `https://picsum.photos/seed/${frameId}/150/100`,
      externalAIPrompt: frameToCopy.externalAIPrompt || '',
    };
  }

  // For new, non-duplicated frames
  return {
    id: frameId,
    name: name,
    description: '',
    // Ensure a deep copy of the default camera config and add sync metadata
    camera: {
      ...JSON.parse(JSON.stringify(DEFAULT_CAMERA_CONFIG)),
      timestamp: Date.now(),
      source: 'appInternal', // Source for newly created frames
      updateId: syncManager.generateUpdateId(),
    },
    characters: [],
    objects: [],
    lights: [ // Initialize with default lights, also deep copied
      JSON.parse(JSON.stringify(DEFAULT_AMBIENT_LIGHT_CONFIG)),
      JSON.parse(JSON.stringify(DEFAULT_DIRECTIONAL_LIGHT_CONFIG)),
    ],
    effects: [],
    thumbnailUrl: `https://picsum.photos/seed/${frameId}/150/100`,
    backgroundColor: BACKGROUND_COLORS[0],
    externalAIPrompt: '',
  };
};
