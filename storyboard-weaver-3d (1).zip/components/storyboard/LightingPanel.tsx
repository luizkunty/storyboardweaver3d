
import React, { useState, useEffect } from 'react';
import { LightConfig, LightType, StoryCharacter, StoryObject } from '../../types';
import { DEFAULT_AMBIENT_LIGHT_CONFIG, DEFAULT_DIRECTIONAL_LIGHT_CONFIG, LIGHT_TYPES, PlusIcon, TrashIcon, ResetIcon } from '../../constants';
import Panel from '../ui/Panel';
import Button from '../ui/Button';
import IconButton from '../ui/IconButton';
import TextInput from '../ui/TextInput';
import MiniMap from '../ui/MiniMap'; // Import MiniMap

interface LightingPanelProps {
  lights: LightConfig[];
  onAddLight: (light: Omit<LightConfig, 'id' | 'threeUUID'>) => void;
  onUpdateLight: (light: LightConfig) => void;
  onRemoveLight: (lightId: string) => void;
  allSceneCharacters: StoryCharacter[]; // For MiniMap context
  allSceneObjects: StoryObject[];     // For MiniMap context
}

const LightingPanel: React.FC<LightingPanelProps> = ({ 
    lights, 
    onAddLight, 
    onUpdateLight, 
    onRemoveLight,
    allSceneCharacters,
    allSceneObjects
}) => {
  const [newLightType, setNewLightType] = useState<LightType>('Point');
  const [editingLight, setEditingLight] = useState<LightConfig | null>(null);
  const [editTargetOnMap, setEditTargetOnMap] = useState<boolean>(false);
  const [selectedTargetEntityId, setSelectedTargetEntityId] = useState<string>('');


  useEffect(() => {
    if (editingLight && !lights.find(l => l.id === editingLight.id)) {
      setEditingLight(null);
    }
    if (!editingLight || (editingLight.type !== 'Directional' && editingLight.type !== 'Spot')) {
        setEditTargetOnMap(false);
    }
     // When editingLight changes, sync selectedTargetEntityId
    if (editingLight) {
        // Heuristic: if target coords match an entity's coords, pre-select it.
        // This is a simple check. A more robust way would be to store targetEntityId on LightConfig.
        let foundEntityTarget = false;
        if (editingLight.type === 'Directional' || editingLight.type === 'Spot') {
            const targetX = editingLight.target.x;
            const targetY = editingLight.target.y;
            const targetZ = editingLight.target.z;

            for (const char of allSceneCharacters) {
                if (char.position && char.position.x === targetX && char.position.y === targetY && char.position.z === targetZ) {
                    setSelectedTargetEntityId(char.id);
                    foundEntityTarget = true;
                    break;
                }
            }
            if (!foundEntityTarget) {
                for (const obj of allSceneObjects) {
                    if (obj.position && obj.position.x === targetX && obj.position.y === targetY && obj.position.z === targetZ) {
                        setSelectedTargetEntityId(obj.id);
                        foundEntityTarget = true;
                        break;
                    }
                }
            }
        }
        if (!foundEntityTarget) {
            setSelectedTargetEntityId(''); // Default to manual
        }
    } else {
        setSelectedTargetEntityId('');
    }
  }, [lights, editingLight, allSceneCharacters, allSceneObjects]);
  
  useEffect(() => {
    if (!editingLight || (editingLight.type !== 'Directional' && editingLight.type !== 'Spot')) return;

    if (selectedTargetEntityId === '' || selectedTargetEntityId === 'manual') {
        // User selected manual coordinates, no automatic update needed from here.
        return;
    }

    let targetEntity: StoryCharacter | StoryObject | undefined;
    targetEntity = allSceneCharacters.find(c => c.id === selectedTargetEntityId);
    if (!targetEntity) {
        targetEntity = allSceneObjects.find(o => o.id === selectedTargetEntityId);
    }

    if (targetEntity && targetEntity.position) {
        const newTargetCoords = { 
            x: targetEntity.position.x, 
            y: targetEntity.position.y, 
            z: targetEntity.position.z 
        };
        // Check if target coords actually changed to prevent feedback loop
        if (editingLight.target.x !== newTargetCoords.x ||
            editingLight.target.y !== newTargetCoords.y ||
            editingLight.target.z !== newTargetCoords.z) {
            
            const updatedLight = { ...editingLight, target: newTargetCoords };
            onUpdateLight(updatedLight);
            setEditingLight(updatedLight); // Keep editingLight state in sync
        }
    }
  }, [selectedTargetEntityId, editingLight, allSceneCharacters, allSceneObjects, onUpdateLight]);


  const handleAddLight = () => {
    let baseConfig: Partial<LightConfig> = {};
    switch(newLightType) {
        case 'Ambient': baseConfig = { ...DEFAULT_AMBIENT_LIGHT_CONFIG, color: '#ffffff', intensity: 0.5 }; break;
        case 'Directional': baseConfig = { ...DEFAULT_DIRECTIONAL_LIGHT_CONFIG, color: '#ffffff', intensity: 1, position: {x: 1, y:10, z:1}, target: {x:0,y:0,z:0}, castShadow: true }; break;
        case 'Point': baseConfig = { type: 'Point', name: 'Point Light', color: '#ffffff', intensity: 1, position: {x:0,y:2,z:2}, target: {x:0,y:0,z:0}, castShadow: true, decay: 1 }; break;
        case 'Spot': baseConfig = { type: 'Spot', name: 'Spot Light', color: '#ffffff', intensity: 2, position: {x:0,y:3,z:3}, target: {x:0,y:0,z:0}, castShadow: true, angle: 30, penumbra: 0.2, decay: 1}; break;
    }
    onAddLight({type: newLightType, ...baseConfig} as Omit<LightConfig, 'id' | 'threeUUID'>);
  };

  const handleUpdateField = (id: string, field: keyof LightConfig, value: any) => {
    const lightToUpdate = lights.find(l => l.id === id);
    if (lightToUpdate) {
      let parsedValue = value;
      if (['intensity', 'angle', 'penumbra', 'decay'].includes(field as string)) {
        parsedValue = parseFloat(value);
        if (isNaN(parsedValue)) {
            parsedValue = field === 'intensity' ? 1 : 
                          (field === 'angle' ? 30 : 
                          (field === 'penumbra' ? 0.1 : 1));
        }
        // Specifically clamp penumbra after parsing and default assignment
        if (field === 'penumbra') {
            parsedValue = Math.max(0, Math.min(1, parsedValue));
        }
      }
      if (field === 'castShadow') {
        parsedValue = typeof value === 'boolean' ? value : (value === 'true');
      }
      
      const updatedLight = { ...lightToUpdate, [field]: parsedValue };
      onUpdateLight(updatedLight);
      if (editingLight && editingLight.id === id) {
        setEditingLight(updatedLight);
      }
    }
  };
  
 const handleUpdatePositionOrTarget = (id: string, field: 'position' | 'target', axis: 'x' | 'y' | 'z', value: string) => {
    const lightToUpdate = lights.find(l => l.id === id);
    if (lightToUpdate) {
      const numValue = parseFloat(value); // Keep as NaN if not a number for now
      const updatedFieldVal = { ...lightToUpdate[field], [axis]: isNaN(numValue) ? (value === '-' ? '-' : '') : numValue };
      
      const updatedLight = { ...lightToUpdate, [field]: updatedFieldVal };
      onUpdateLight(updatedLight); // This will be debounced in App eventually
       if (editingLight && editingLight.id === id) {
        setEditingLight(updatedLight);
      }
    }
  };

  const handlePositionOrTargetBlur = (id: string, field: 'position' | 'target', axis: 'x' | 'y' | 'z', currentValue: string | number) => {
    const lightToUpdate = lights.find(l => l.id === id);
    if (lightToUpdate) {
        let finalValue = parseFloat(currentValue as string);
        if (isNaN(finalValue)) {
            finalValue = lightToUpdate[field][axis] || 0; // Revert to existing or 0
        }
        const updatedFieldVal = { ...lightToUpdate[field], [axis]: finalValue };
        const updatedLight = { ...lightToUpdate, [field]: updatedFieldVal };
        onUpdateLight(updatedLight); // Final update
        if (editingLight && editingLight.id === id) {
            setEditingLight(updatedLight);
        }
    }
  };
  
  const handleMapClick = (sceneX: number, sceneZ: number) => {
    if (!editingLight) return;

    const fieldToUpdate = (editingLight.type === 'Directional' || editingLight.type === 'Spot') && editTargetOnMap
      ? 'target'
      : 'position';
    
    const currentY = editingLight[fieldToUpdate]?.y; 
    const newY = fieldToUpdate === 'target' ? (currentY ?? 0) : (currentY ?? (fieldToUpdate === 'position' ? 2 : 0));


    const updatedField = {
        x: parseFloat(sceneX.toFixed(1)),
        y: newY, 
        z: parseFloat(sceneZ.toFixed(1))
    };
    const updatedLight = { ...editingLight, [fieldToUpdate]: updatedField };
    onUpdateLight(updatedLight);
    setEditingLight(updatedLight);
    if (fieldToUpdate === 'target') { // If target was updated via map, deselect entity target
        setSelectedTargetEntityId('');
    }
  };


  const renderLightControls = (light: LightConfig) => {
    const mapItemsForLight = [
        ...(allSceneCharacters || []).map(c => ({ id: c.id, x: c.position?.x ?? 0, z: c.position?.z ?? 0, type: 'character' as const, name: c.name })),
        ...(allSceneObjects || []).map(o => ({ id: o.id, x: o.position?.x ?? 0, z: o.position?.z ?? 0, type: 'object' as const, name: o.name })),
        ...(lights || []).filter(l => l.id !== light.id && l.type !== 'Ambient').map(l => ({ id: l.id, x: l.position.x, z: l.position.z, type: 'light' as const, name: l.name })),
    ];
    
    const currentPositionToDisplay = {
        x: typeof light.position.x === 'number' ? light.position.x.toString() : light.position.x,
        y: typeof light.position.y === 'number' ? light.position.y.toString() : light.position.y,
        z: typeof light.position.z === 'number' ? light.position.z.toString() : light.position.z,
    };
    const currentTargetToDisplay = {
        x: typeof light.target?.x === 'number' ? light.target.x.toString() : light.target?.x ?? '0',
        y: typeof light.target?.y === 'number' ? light.target.y.toString() : light.target?.y ?? '0',
        z: typeof light.target?.z === 'number' ? light.target.z.toString() : light.target?.z ?? '0',
    };

    const commonControls = (
      <>
        <TextInput label="Name" id={`lightName-${light.id}`} value={light.name} onChange={(e) => handleUpdateField(light.id, 'name', e.target.value)} />
        <div>
          <label htmlFor={`lightColor-${light.id}`} className="block text-sm font-medium text-gray-300 mb-1">Color</label>
          <input type="color" id={`lightColor-${light.id}`} value={light.color} onChange={(e) => handleUpdateField(light.id, 'color', e.target.value)} className="w-full h-10 bg-gray-700 border-gray-600 rounded-md" />
        </div>
        <div>
          <label htmlFor={`lightIntensity-${light.id}`} className="block text-sm font-medium text-gray-300 mb-1">Intensity ({light.intensity.toFixed(2)})</label>
          <input type="range" id={`lightIntensity-${light.id}`} min="0" max="5" step="0.1" value={light.intensity} onChange={(e) => handleUpdateField(light.id, 'intensity', e.target.value)} className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-indigo-500" />
        </div>
      </>
    );

    const positionalControls = (light.type === 'Directional' || light.type === 'Point' || light.type === 'Spot') && (
      <div className="mt-2">
        <label className="block text-sm font-medium text-gray-300 mb-1">Position (X, Y, Z)</label>
        <div className="grid grid-cols-3 gap-2">
          <TextInput label="" id={`lightPosX-${light.id}`} type="text" value={currentPositionToDisplay.x} onChange={e => handleUpdatePositionOrTarget(light.id, 'position', 'x', e.target.value)} onBlur={e => handlePositionOrTargetBlur(light.id, 'position', 'x', e.target.value)} />
          <TextInput label="" id={`lightPosY-${light.id}`} type="text" value={currentPositionToDisplay.y} onChange={e => handleUpdatePositionOrTarget(light.id, 'position', 'y', e.target.value)} onBlur={e => handlePositionOrTargetBlur(light.id, 'position', 'y', e.target.value)} />
          <TextInput label="" id={`lightPosZ-${light.id}`} type="text" value={currentPositionToDisplay.z} onChange={e => handleUpdatePositionOrTarget(light.id, 'position', 'z', e.target.value)} onBlur={e => handlePositionOrTargetBlur(light.id, 'position', 'z', e.target.value)} />
        </div>
      </div>
    );
    
    const targetControls = (light.type === 'Directional' || light.type === 'Spot') && (
      <div className="mt-2">
        <label className="block text-sm font-medium text-gray-300 mb-1">Target</label>
         <select 
            value={selectedTargetEntityId} 
            onChange={e => setSelectedTargetEntityId(e.target.value)}
            className="block w-full bg-gray-700 border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm mb-2"
          >
            <option value="">Manual Coordinates</option>
            <optgroup label="Characters">
              {allSceneCharacters.map(char => <option key={char.id} value={char.id}>{char.name}</option>)}
            </optgroup>
            <optgroup label="Objects">
              {allSceneObjects.map(obj => <option key={obj.id} value={obj.id}>{obj.name}</option>)}
            </optgroup>
          </select>
        <div className="grid grid-cols-3 gap-2">
          <TextInput label="" id={`lightTargetX-${light.id}`} type="text" value={currentTargetToDisplay.x} onChange={e => handleUpdatePositionOrTarget(light.id, 'target', 'x', e.target.value)} onBlur={e => handlePositionOrTargetBlur(light.id, 'target', 'x', e.target.value)} disabled={selectedTargetEntityId !== '' && selectedTargetEntityId !== 'manual'} />
          <TextInput label="" id={`lightTargetY-${light.id}`} type="text" value={currentTargetToDisplay.y} onChange={e => handleUpdatePositionOrTarget(light.id, 'target', 'y', e.target.value)} onBlur={e => handlePositionOrTargetBlur(light.id, 'target', 'y', e.target.value)} disabled={selectedTargetEntityId !== '' && selectedTargetEntityId !== 'manual'} />
          <TextInput label="" id={`lightTargetZ-${light.id}`} type="text" value={currentTargetToDisplay.z} onChange={e => handleUpdatePositionOrTarget(light.id, 'target', 'z', e.target.value)} onBlur={e => handlePositionOrTargetBlur(light.id, 'target', 'z', e.target.value)} disabled={selectedTargetEntityId !== '' && selectedTargetEntityId !== 'manual'} />
        </div>
      </div>
    );

    const spotControls = light.type === 'Spot' && (
      <>
        <div className="mt-2">
          <label htmlFor={`lightAngle-${light.id}`} className="block text-sm font-medium text-gray-300 mb-1">Angle ({(light.angle ?? 0).toFixed(1)}°)</label>
          <input type="range" id={`lightAngle-${light.id}`} min="0" max="90" step="1" value={light.angle ?? 30} onChange={(e) => handleUpdateField(light.id, 'angle', e.target.value)} className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-indigo-500" />
        </div>
        <div className="mt-2">
          <label htmlFor={`lightPenumbra-${light.id}`} className="block text-sm font-medium text-gray-300 mb-1">Penumbra ({(light.penumbra ?? 0).toFixed(2)})</label>
          <input type="range" id={`lightPenumbra-${light.id}`} min="0" max="1" step="0.01" value={light.penumbra ?? 0.1} onChange={(e) => handleUpdateField(light.id, 'penumbra', e.target.value)} className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-indigo-500" />
        </div>
      </>
    );
    
    const decayControls = (light.type === 'Point' || light.type === 'Spot') && (
         <div className="mt-2">
          <label htmlFor={`lightDecay-${light.id}`} className="block text-sm font-medium text-gray-300 mb-1">Decay ({(light.decay ?? 0).toFixed(1)})</label>
          <input type="range" id={`lightDecay-${light.id}`} min="0" max="2" step="0.1" value={light.decay ?? 1} onChange={(e) => handleUpdateField(light.id, 'decay', e.target.value)} className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-indigo-500" />
        </div>
    );

    const shadowControl = (light.type === 'Directional' || light.type === 'Point' || light.type === 'Spot') && (
      <div className="mt-3 flex items-center">
        <input type="checkbox" id={`lightCastShadow-${light.id}`} checked={light.castShadow} onChange={(e) => handleUpdateField(light.id, 'castShadow', e.target.checked)} className="h-4 w-4 text-indigo-600 border-gray-500 rounded focus:ring-indigo-500" />
        <label htmlFor={`lightCastShadow-${light.id}`} className="ml-2 block text-sm text-gray-300">Cast Shadow</label>
      </div>
    );
    
    const miniMapAndTargetToggle = (light.type === 'Directional' || light.type === 'Spot' || light.type === 'Point') && (
        <div className="mt-3 space-y-2">
            {(light.type === 'Directional' || light.type === 'Spot') && (
                <Button
                    onClick={() => {
                        setEditTargetOnMap(prev => !prev);
                        if (!editTargetOnMap) { // If switching to "Edit Target on Map"
                            setSelectedTargetEntityId(''); // Clear entity target selection
                        }
                    }}
                    variant={editTargetOnMap ? "primary" : "secondary"}
                    size="sm"
                    className="w-full"
                >
                    {editTargetOnMap ? "Editing Target on Map" : "Editing Position on Map"}
                </Button>
            )}
            <MiniMap
                items={mapItemsForLight}
                bounds={{ minX: -25, maxX: 25, minZ: -25, maxZ: 25 }}
                pendingX={editTargetOnMap && (light.type === 'Directional' || light.type === 'Spot') ? light.target.x : light.position.x}
                pendingZ={editTargetOnMap && (light.type === 'Directional' || light.type === 'Spot') ? light.target.z : light.position.z}
                onMapClick={handleMapClick}
                mapPixelDimensions={{ width: 180, height: 180 }}
                lightSourcePosition={editTargetOnMap && (light.type === 'Directional' || light.type === 'Spot') ? { x: light.position.x, z: light.position.z } : undefined}
                drawDirectionLine={editTargetOnMap && (light.type === 'Directional' || light.type === 'Spot')}
            />
        </div>
    );


    return (
      <div className="p-3 bg-gray-750 rounded-md shadow-sm border border-gray-600/50 space-y-3">
        {commonControls}
        {positionalControls}
        {targetControls}
        {spotControls}
        {decayControls}
        {shadowControl}
        {miniMapAndTargetToggle}
        <Button onClick={() => {setEditingLight(null); setSelectedTargetEntityId('');}} variant="secondary" size="sm" className="w-full mt-2">Done Editing</Button>
      </div>
    );
  };


  return (
    <Panel title="Lighting Setup" className="h-full overflow-y-auto">
      <div className="mb-4 p-3 bg-gray-750 rounded-md shadow-sm border border-gray-600/50">
        <h4 className="text-md font-semibold text-gray-200 mb-2">Add New Light</h4>
        <div className="space-y-2">
          <div>
            <label htmlFor="newLightType" className="block text-xs font-medium text-gray-400 mb-1">Type</label>
            <select
              id="newLightType"
              value={newLightType}
              onChange={(e) => setNewLightType(e.target.value as LightType)}
              className="block w-full bg-gray-700 border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            >
              {LIGHT_TYPES.map(lt => <option key={lt.value} value={lt.value}>{lt.label}</option>)}
            </select>
          </div>
          <Button onClick={handleAddLight} variant="primary" size="md" className="w-full h-10">
            <PlusIcon className="w-5 h-5 mr-2" /> Add Light
          </Button>
        </div>
      </div>

      {editingLight && (
        <div className="mb-6">
           <h4 className="text-md font-semibold text-gray-200 mb-2">Editing: {editingLight.name}</h4>
          {renderLightControls(editingLight)}
        </div>
      )}

      <h4 className="text-md font-semibold text-gray-200 mb-3">Scene Lights ({lights.length})</h4>
      {lights.length === 0 && <p className="text-sm text-gray-500">No lights in this scene. Add one above.</p>}
      <ul className="space-y-2">
        {lights.map(light => (
          <li key={light.id} className={`p-2.5 rounded-md flex flex-col sm:flex-row items-start sm:items-center justify-between transition-all duration-150 ${editingLight?.id === light.id ? 'bg-indigo-700 bg-opacity-30 border-indigo-500 border-2' : 'bg-gray-700 hover:bg-gray-650 border border-gray-600'}`}>
            <div className="flex-grow mb-2 sm:mb-0">
              <p className="text-sm font-medium text-gray-100">{light.name} <span className="text-xs text-gray-400">({light.type})</span></p>
              <div className="text-xs text-gray-300 mt-1">
                <span className="mr-2">Color: <span style={{display: 'inline-block', width: '10px', height: '10px', backgroundColor: light.color, borderRadius: '2px', marginRight: '2px', verticalAlign: 'middle'}}></span>{light.color}</span>
                <span>Intensity: {light.intensity.toFixed(1)}</span>
              </div>
            </div>
            <div className="space-x-1.5 flex-shrink-0 self-end sm:self-center">
              <Button onClick={() => setEditingLight(light)} variant="ghost" size="sm" className="px-2 py-1 text-xs">Edit</Button>
              <IconButton onClick={() => onRemoveLight(light.id)} tooltip="Remove Light" className="p-1.5">
                <TrashIcon className="w-4 h-4 text-red-400 hover:text-red-300" />
              </IconButton>
            </div>
          </li>
        ))}
      </ul>
    </Panel>
  );
};

export default LightingPanel;
        