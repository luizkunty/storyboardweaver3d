
import React, { useState, useEffect } from 'react';
import { Frame, StoryCharacter, StoryObject, AssetLibraryItem, LightConfig } from '../../types';
import { AVAILABLE_COLORS, BookOpenIcon, SparklesIcon as PrimitivesIcon } from '../../constants'; // Using Sparkles for Primitives for now
import AssetLibraryPanel from './AssetLibraryPanel';
import CharacterForm from './CharacterForm';
import ObjectForm from './ObjectForm';
import PrimitiveCreator from './PrimitiveCreator'; // New component

type ActiveMainTab = 'library' | 'primitives';
type CurrentView = 'overview' | 'configure_asset' | 'edit_character' | 'edit_object';

interface ElementsPanelProps {
  currentFrame: Frame | undefined;
  onAddCharacter: (character: Omit<StoryCharacter, 'id' | 'threeUUID'> & { assetId?: string }) => void;
  onUpdateCharacter: (character: StoryCharacter) => void;
  onRemoveCharacter: (characterId: string) => void;
  onAddObject: (obj: Omit<StoryObject, 'id' | 'threeUUID'> & { assetId?: string }) => void;
  onUpdateObject: (obj: StoryObject) => void;
  onRemoveObject: (objectId: string) => void;
  
  selectedAssetForForm: AssetLibraryItem | null;
  onPrepareAssetForForm: (asset: AssetLibraryItem) => void; 
  onClearSelectedAsset: () => void;

  editingCharacterId: string | null;
  onSetEditingCharacterId: (id: string | null) => void;
  editingObjectId: string | null;
  onSetEditingObjectId: (id: string | null) => void;

  // New props for AssetLibraryPanel enhancements
  favoriteAssetIds: string[];
  recentlyUsedAssetIds: string[];
  onToggleFavoriteAsset: (assetId: string) => void;
  onAssetPreview: (asset: AssetLibraryItem) => void;
  onAssetUsed: (assetId: string) => void; // To update recently used
}

const ElementsPanel: React.FC<ElementsPanelProps> = ({
  currentFrame,
  onAddCharacter,
  onUpdateCharacter,
  onRemoveCharacter,
  onAddObject,
  onUpdateObject,
  onRemoveObject,
  selectedAssetForForm,
  onPrepareAssetForForm,
  onClearSelectedAsset,
  editingCharacterId,
  onSetEditingCharacterId,
  editingObjectId,
  onSetEditingObjectId,
  favoriteAssetIds,
  recentlyUsedAssetIds,
  onToggleFavoriteAsset,
  onAssetPreview,
  onAssetUsed
}) => {
  const [activeMainTab, setActiveMainTab] = useState<ActiveMainTab>('library');
  const [currentView, setCurrentView] = useState<CurrentView>('overview');

  const editingCharacter = currentFrame?.characters.find(c => c.id === editingCharacterId);
  const editingObject = currentFrame?.objects.find(o => o.id === editingObjectId);

  // Effect to switch view when an asset is selected for configuration
  useEffect(() => {
    if (selectedAssetForForm) {
      setCurrentView('configure_asset');
      // Optionally switch main tab to 'library' if not already, or handle display within current tab
      // setActiveMainTab('library'); // Or manage this more flexibly
    }
  }, [selectedAssetForForm]);

  // Effect to switch view when an item is selected for editing
  useEffect(() => {
    if (editingCharacterId) {
      setCurrentView('edit_character');
      setActiveMainTab('primitives'); // Switch to primitives tab where editing happens
    } else if (editingObjectId) {
      setCurrentView('edit_object');
      setActiveMainTab('primitives'); // Switch to primitives tab
    }
  }, [editingCharacterId, editingObjectId]);


  const handleAssetSelectedFromLibrary = (asset: AssetLibraryItem) => {
    onPrepareAssetForForm(asset); // This sets selectedAssetForForm in App.tsx
    onAssetUsed(asset.id); // Mark asset as used
    // useEffect above will catch selectedAssetForForm and set currentView
  };

  const handleEditCharacterFromPrimitiveList = (characterId: string) => {
    onSetEditingCharacterId(characterId); // This sets editingCharacterId in App.tsx
     // useEffect above will catch editingCharacterId and set currentView & activeMainTab
  };

  const handleEditObjectFromPrimitiveList = (objectId: string) => {
    onSetEditingObjectId(objectId);
     // useEffect above will catch editingObjectId and set currentView & activeMainTab
  };
  
  const handleFormCancel = () => {
    onClearSelectedAsset();
    onSetEditingCharacterId(null);
    onSetEditingObjectId(null);
    setCurrentView('overview');
    // Potentially switch activeMainTab back to 'library' or 'primitives' based on context
    // For now, let's assume cancel returns to the overview of the current activeMainTab.
  };
  
  const handleFormSubmitAfterLibraryAsset = () => {
    onClearSelectedAsset();
    setCurrentView('overview');
    setActiveMainTab('library'); // Go back to library after adding asset
  };
  
  const handleFormSubmitAfterEdit = () => {
    onSetEditingCharacterId(null);
    onSetEditingObjectId(null);
    setCurrentView('overview');
    setActiveMainTab('primitives'); // Go back to primitives list after editing
  };


  const mainTabs: { id: ActiveMainTab; label: string; icon: React.FC<{className?: string}> }[] = [
    { id: 'library', label: 'Library', icon: BookOpenIcon },
    { id: 'primitives', label: 'Primitives', icon: PrimitivesIcon },
  ];

  const renderContent = () => {
    if (currentView === 'configure_asset' && selectedAssetForForm) {
      // Pass assetId for onAddCharacter/onAddObject to track usage
      const assetAwareAddCharacter = (charData: Omit<StoryCharacter, 'id' | 'threeUUID'>) => {
          onAddCharacter({ ...charData, assetId: selectedAssetForForm.id });
      };
      const assetAwareAddObject = (objData: Omit<StoryObject, 'id' | 'threeUUID'>) => {
          onAddObject({ ...objData, assetId: selectedAssetForForm.id });
      };

      if (selectedAssetForForm.type === 'character' && currentFrame) {
        return <CharacterForm
                  selectedAssetForForm={selectedAssetForForm}
                  onAddCharacter={assetAwareAddCharacter}
                  onUpdateCharacter={onUpdateCharacter} // Not used when configuring new asset
                  availableColors={AVAILABLE_COLORS}
                  onClearSelectedAsset={onClearSelectedAsset}
                  onFormSubmitAfterLibraryAssetAdd={handleFormSubmitAfterLibraryAsset}
                  onCancel={handleFormCancel}
                  currentFrame={currentFrame}
                  allSceneObjects={currentFrame.objects}
                  allSceneLights={currentFrame.lights}
                />;
      }
      if (selectedAssetForForm.type === 'object' && currentFrame) {
        return <ObjectForm
                  selectedAssetForForm={selectedAssetForForm}
                  onAddObject={assetAwareAddObject}
                  onUpdateObject={onUpdateObject} // Not used
                  availableColors={AVAILABLE_COLORS}
                  onClearSelectedAsset={onClearSelectedAsset}
                  onFormSubmitAfterLibraryAssetAdd={handleFormSubmitAfterLibraryAsset}
                  onCancel={handleFormCancel}
                  currentFrame={currentFrame}
                  allSceneCharacters={currentFrame.characters}
                  allSceneLights={currentFrame.lights}
                />;
      }
    }

    if (currentView === 'edit_character' && editingCharacter && currentFrame) {
       return <CharacterForm
                initialData={editingCharacter}
                onAddCharacter={onAddCharacter} // Not used
                onUpdateCharacter={(char) => { onUpdateCharacter(char); handleFormSubmitAfterEdit(); }}
                availableColors={AVAILABLE_COLORS}
                onClearSelectedAsset={onClearSelectedAsset} // Not directly used for edit
                onCancel={handleFormCancel}
                currentFrame={currentFrame}
                allSceneObjects={currentFrame.objects}
                allSceneLights={currentFrame.lights}
              />;
    }
    if (currentView === 'edit_object' && editingObject && currentFrame) {
        return <ObjectForm
                initialData={editingObject}
                onAddObject={onAddObject} // Not used
                onUpdateObject={(obj) => { onUpdateObject(obj); handleFormSubmitAfterEdit(); }}
                availableColors={AVAILABLE_COLORS}
                onClearSelectedAsset={onClearSelectedAsset} // Not directly used
                onCancel={handleFormCancel}
                currentFrame={currentFrame}
                allSceneCharacters={currentFrame.characters}
                allSceneLights={currentFrame.lights}
              />;
    }

    // Overview states for each main tab
    if (activeMainTab === 'library') {
      return <AssetLibraryPanel 
                onSelectAsset={handleAssetSelectedFromLibrary} 
                favorites={favoriteAssetIds}
                onToggleFavorite={onToggleFavoriteAsset}
                recentlyUsed={recentlyUsedAssetIds}
                onAssetPreview={onAssetPreview}
             />;
    }
    if (activeMainTab === 'primitives') {
      if (!currentFrame) {
        return (
          <div className="p-4 text-center text-gray-400">
            <PrimitivesIcon className="w-12 h-12 mx-auto mb-3 text-gray-500" />
            <p>Please select or create a frame to add primitives.</p>
          </div>
        );
      }
      return <PrimitiveCreator
                currentFrame={currentFrame}
                onAddCharacter={onAddCharacter}
                onRemoveCharacter={onRemoveCharacter}
                onEditCharacter={handleEditCharacterFromPrimitiveList}
                onAddObject={onAddObject}
                onRemoveObject={onRemoveObject}
                onEditObject={handleEditObjectFromPrimitiveList}
                availableColors={AVAILABLE_COLORS}
             />;
    }
    return null;
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-shrink-0 border-b border-gray-700">
        <nav className="flex justify-around -mb-px">
          {mainTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveMainTab(tab.id);
                setCurrentView('overview'); // Reset view when switching main tabs
                onClearSelectedAsset();    // Clear any pending asset configuration
                onSetEditingCharacterId(null); // Clear editing states
                onSetEditingObjectId(null);
              }}
              className={`
                flex items-center justify-center py-3 px-1 border-b-2 text-sm font-medium 
                w-1/${mainTabs.length} transition-colors duration-150 ease-in-out
                ${
                  activeMainTab === tab.id && currentView === 'overview' // Highlight only if in overview
                    ? 'border-indigo-500 text-indigo-400'
                    : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
                }
                 disabled:opacity-50 disabled:hover:border-transparent disabled:hover:text-gray-400
              `}
              aria-current={activeMainTab === tab.id ? 'page' : undefined}
            >
              <tab.icon className={`w-4 h-4 mr-2 ${activeMainTab === tab.id && currentView === 'overview' ? 'text-indigo-400' : 'text-gray-500 group-hover:text-gray-300'}`} />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
      <div className="flex-grow overflow-y-auto custom-scrollbar">
        {renderContent()}
      </div>
    </div>
  );
};

export default ElementsPanel;