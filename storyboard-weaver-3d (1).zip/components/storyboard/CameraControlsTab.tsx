
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { CameraConfig, EditableCameraConfig, CameraPreset } from '../../types';
import Panel from '../ui/Panel';
import Button from '../ui/Button';
import IconButton from '../ui/IconButton';
import {
    ResetIcon, FovIcon, ZoomIcon,
    PositionXAxisIcon, PositionYAxisIcon, PositionZAxisIcon,
    RotationPitchIcon, RotationYawIcon, RotationRollIcon,
    CameraIcon as SidebarCameraIcon
} from '../../constants';
import { CameraSyncManager } from '../../utils/cameraSyncManager';
import { useSmartThrottle } from '../../hooks/useSmartThrottle';

interface CameraControlsTabProps {
  camera: CameraConfig; // This is the camera from the global state (App.tsx -> currentFrame.camera)
  onUpdateCamera: (cameraConfig: CameraConfig) => void; // Callback to update global state
  defaultCameraConfig: CameraConfig; // App-wide default
  cameraPresets: CameraPreset[];
  onApplyPreset: (preset: CameraPreset) => void;
}

// --- Slider Transformation Logic ---
interface ControlTransform {
  appMin: number;
  appNeutral: number;
  appMax: number;
  sliderHtmlMin: number;
  sliderHtmlMax: number;
  isTransformed: boolean;
  appStep: number;
}

const getControlTransform = (
  group: keyof CameraConfig | 'fov' | 'zoom', // Extended to allow 'fov'/'zoom' directly
  field: keyof CameraConfig['position'] | keyof CameraConfig['rotation'] | undefined,
  appMin: number,
  appMax: number,
  appStep: number,
  defaultCamera: CameraConfig
): ControlTransform => {
  const base: ControlTransform = { appMin, appMax, appStep, sliderHtmlMin: appMin, sliderHtmlMax: appMax, isTransformed: false, appNeutral: 0 };

  const setNeutral = (grp: 'position' | 'rotation' | 'fov' | 'zoom') => {
     if (grp === 'fov' || grp === 'zoom') {
        base.appNeutral = defaultCamera[grp];
     } else if (field && defaultCamera[grp] && (defaultCamera[grp] as any)[field] !== undefined) {
        base.appNeutral = (defaultCamera[grp] as any)[field];
     }
  };

  if (group === 'zoom' || group === 'rotation' || group === 'fov') {
    base.isTransformed = true;
    setNeutral(group as 'position' | 'rotation' | 'fov' | 'zoom');
    base.sliderHtmlMin = -100;
    base.sliderHtmlMax = 100;
  } else if (group === 'position' && field) {
    setNeutral('position');
  }
  return base;
};

const mapAppValueToNormalizedSlider = (appValue: number, transform: ControlTransform): number => {
  if (!transform.isTransformed) return appValue;
  const { appMin, appNeutral, appMax, sliderHtmlMin, sliderHtmlMax } = transform;
  const sliderMidPoint = sliderHtmlMin + (sliderHtmlMax - sliderHtmlMin) / 2;

  if (appValue === appNeutral) return sliderMidPoint;
  if (appValue < appNeutral) {
    return appNeutral === appMin ? sliderHtmlMin : sliderHtmlMin + ((appValue - appMin) / (appNeutral - appMin)) * (sliderMidPoint - sliderHtmlMin);
  } else {
    return appNeutral === appMax ? sliderHtmlMax : sliderMidPoint + ((appValue - appNeutral) / (appMax - appNeutral)) * (sliderHtmlMax - sliderMidPoint);
  }
};

const mapNormalizedSliderToAppValue = (sliderValue: number, transform: ControlTransform): number => {
  if (!transform.isTransformed) return sliderValue;
  const { appMin, appNeutral, appMax, sliderHtmlMin, sliderHtmlMax } = transform;
  const sliderMidPoint = sliderHtmlMin + (sliderHtmlMax - sliderHtmlMin) / 2;
  let appVal;
  if (sliderValue === sliderMidPoint) appVal = appNeutral;
  else if (sliderValue < sliderMidPoint) {
    appVal = sliderMidPoint === sliderHtmlMin ? appMin : appMin + ((sliderValue - sliderHtmlMin) / (sliderMidPoint - sliderHtmlMin)) * (appNeutral - appMin);
  } else {
    appVal = sliderMidPoint === sliderHtmlMax ? appMax : appNeutral + ((sliderValue - sliderMidPoint) / (sliderHtmlMax - sliderMidPoint)) * (appMax - appNeutral);
  }
  return Math.max(transform.appMin, Math.min(transform.appMax, appVal));
};
// --- End Slider Transformation Logic ---

const CameraControlsTab: React.FC<CameraControlsTabProps> = ({
  camera: propsCamera,
  onUpdateCamera,
  defaultCameraConfig, // App-wide default
  cameraPresets,
  onApplyPreset,
}) => {
  const syncManager = CameraSyncManager.getInstance();
  const [localEditableCamera, setLocalEditableCamera] = useState<EditableCameraConfig>(
    syncManager.toEditableConfig(propsCamera)
  );
  const [isUserEditing, setIsUserEditing] = useState<boolean>(false);
  const inputFocusRef = useRef<{ [key: string]: boolean }>({});
  const lastSentUpdateIdRef = useRef<string | null>(null);
  const lastExternalTimestampRef = useRef<number>(propsCamera.timestamp || 0);
  const userEditTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const markUserEditing = useCallback((duration: number = 1000) => {
    setIsUserEditing(true);
    if (userEditTimeoutRef.current) clearTimeout(userEditTimeoutRef.current);
    userEditTimeoutRef.current = setTimeout(() => setIsUserEditing(false), duration);
  }, []);

  const propagateUpdate = useCallback((newNumericConfig: CameraConfig, isThrottled: boolean) => {
      const updateId = syncManager.generateUpdateId();
      const cameraWithMeta = {
        ...newNumericConfig,
        timestamp: Date.now(),
        source: 'ui' as const,
        updateId,
      };
      lastSentUpdateIdRef.current = updateId;
      onUpdateCamera(cameraWithMeta);
      // If it's an immediate update (blur), also update lastExternalTimestampRef to prevent self-overwrite by a slightly delayed prop echo.
      if (!isThrottled) {
          lastExternalTimestampRef.current = cameraWithMeta.timestamp;
      }
  }, [onUpdateCamera, syncManager]);


  const throttledSliderUpdate = useSmartThrottle(
     (newCamera: CameraConfig) => propagateUpdate(newCamera, true),
    { delay: 150, immediate: false, trailing: true }
  );

  const debouncedInputUpdate = useSmartThrottle(
    (newCamera: CameraConfig) => propagateUpdate(newCamera, true),
    { delay: 300, immediate: false, trailing: true }
  );

  useEffect(() => {
    const shouldAccept = syncManager.shouldAcceptUpdate(
      propsCamera,
      localEditableCamera,
      lastSentUpdateIdRef.current,
      lastExternalTimestampRef.current
    );

    if (!shouldAccept) return;
    if (isUserEditing) return; // Don't update if user is actively editing inputs
    
    const hasFocusedInput = Object.values(inputFocusRef.current).some(Boolean);
    if (hasFocusedInput) return; // Don't update if an input field has focus (user might be about to type)


    const newEditable = syncManager.toEditableConfig(propsCamera);
    setLocalEditableCamera(newEditable);

    if (propsCamera.source !== 'ui' && propsCamera.timestamp) {
      lastExternalTimestampRef.current = propsCamera.timestamp;
    }
  }, [propsCamera, localEditableCamera, isUserEditing, syncManager]);


  const handleSliderChange = useCallback((
    category: 'position' | 'rotation' | 'fov' | 'zoom',
    axis: 'x' | 'y' | 'z' | undefined, // Undefined for fov/zoom
    value: string, // Slider value is always string
    transform: ControlTransform
  ) => {
    markUserEditing(500);
    const sliderNumericValue = parseFloat(value);
    let appValue = mapNormalizedSliderToAppValue(sliderNumericValue, transform);

    // Clamp values based on type
    if (category === 'rotation' && axis === 'x') appValue = Math.max(-89.9, Math.min(89.9, appValue));
    if (category === 'fov') appValue = Math.max(10, Math.min(120, appValue));
    if (category === 'zoom') appValue = Math.max(0.1, Math.min(20, appValue));

    setLocalEditableCamera(prev => {
      const newEditable = syncManager.toEditableConfig(syncManager.toNumericConfig(prev, propsCamera)); // Ensure numeric base for toEditableConfig
      const targetKey = category === 'fov' || category === 'zoom' ? category : axis!;
      const precision = category === 'zoom' ? 2 : (category === 'fov' ? 1 : 3);

      if (category === 'fov' || category === 'zoom') {
        (newEditable[category]) = appValue.toFixed(precision);
      } else {
        (newEditable[category] as any)[targetKey] = appValue.toFixed(precision);
      }
      return newEditable;
    });
    
    const numericFromLocal = syncManager.toNumericConfig(localEditableCamera, propsCamera);
     if (category === 'fov' || category === 'zoom') {
        (numericFromLocal[category]) = appValue;
      } else {
        (numericFromLocal[category] as any)[axis!] = appValue;
      }
    throttledSliderUpdate(numericFromLocal);
  }, [localEditableCamera, propsCamera, markUserEditing, throttledSliderUpdate, syncManager]);

  const handleInputChange = useCallback((
    category: 'position' | 'rotation' | 'fov' | 'zoom',
    axis: 'x' | 'y' | 'z' | undefined,
    value: string // Input value is string
  ) => {
    markUserEditing(1500);
    setLocalEditableCamera(prev => {
      const newEditable = { ...prev }; // Shallow copy is fine for top level
      if (category === 'fov' || category === 'zoom') {
        newEditable[category] = value;
      } else {
        newEditable[category] = { ...prev[category], [axis!]: value };
      }
      return newEditable;
    });
    // Debounced update will use the latest state from localEditableCamera
    debouncedInputUpdate(syncManager.toNumericConfig(localEditableCamera, propsCamera));

  }, [localEditableCamera, propsCamera, markUserEditing, debouncedInputUpdate, syncManager]);


  const handleInputFocus = useCallback((fieldName: string) => {
    inputFocusRef.current[fieldName] = true;
    markUserEditing(2000); // Keep user editing flag true while focused
  }, [markUserEditing]);

  const handleInputBlur = useCallback((
    category: 'position' | 'rotation' | 'fov' | 'zoom',
    axis: 'x' | 'y' | 'z' | undefined,
    transform: ControlTransform
  ) => {
    inputFocusRef.current[`${category}.${axis || category}`] = false;
    
    // Force immediate update on blur, ensuring value is valid and formatted
    const numericConf = syncManager.toNumericConfig(localEditableCamera, propsCamera);
    let valueToValidate: number;

    if (category === 'fov' || category === 'zoom') {
        valueToValidate = numericConf[category];
    } else {
        valueToValidate = (numericConf[category] as any)[axis!];
    }
    
    // Apply clamps from transform
    valueToValidate = Math.max(transform.appMin, Math.min(transform.appMax, valueToValidate));
    if (category === 'rotation' && axis === 'x') valueToValidate = Math.max(-89.9, Math.min(89.9, valueToValidate));
    if (category === 'fov') valueToValidate = Math.max(10, Math.min(120, valueToValidate));
    if (category === 'zoom') valueToValidate = Math.max(0.1, Math.min(20, valueToValidate));

    if (category === 'fov' || category === 'zoom') {
        numericConf[category] = valueToValidate;
    } else {
       (numericConf[category]as any)[axis!] = valueToValidate;
    }
    
    setLocalEditableCamera(syncManager.toEditableConfig(numericConf)); // Update local state with validated & formatted value
    propagateUpdate(numericConf, false); // false for immediate update

  }, [localEditableCamera, propsCamera, syncManager, propagateUpdate]);


  const renderControl = (
    label: string, idPrefix: string,
    appMin: number, appMax: number, appStep: number,
    category: 'position' | 'rotation' | 'fov' | 'zoom',
    axis?: 'x' | 'y' | 'z',
    displaySuffix = "",
    IconComponent?: React.FC<{ className?: string }>
  ) => {
    const fieldName = `${category}.${axis || category}`;
    const transform = getControlTransform(category, axis, appMin, appMax, appStep, defaultCameraConfig);
    
    let currentValueForSlider: number;
    let displayValueForText: string;

    if (category === 'fov' || category === 'zoom') {
      currentValueForSlider = parseFloat(localEditableCamera[category] as string);
      displayValueForText = localEditableCamera[category] as string;
    } else {
      currentValueForSlider = parseFloat((localEditableCamera[category] as any)[axis!] as string);
      displayValueForText = (localEditableCamera[category] as any)[axis!] as string;
    }
    if (isNaN(currentValueForSlider)) { // Fallback if parsing fails (e.g. user typed text)
        const fallbackNumeric = (category === 'fov' || category === 'zoom') ? 
            propsCamera[category] : 
            (propsCamera[category] as any)[axis!];
        currentValueForSlider = fallbackNumeric;
    }
    
    const sliderVisualValue = mapAppValueToNormalizedSlider(currentValueForSlider, transform);

    return (
      <div className="p-1.5 bg-gray-750 rounded-md">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center">
            {IconComponent && <IconComponent className="w-4 h-4 mr-1.5 text-gray-400" />}
            <label htmlFor={`${idPrefix}-num`} className="block text-sm font-medium text-gray-300">
              {label}: {parseFloat(displayValueForText).toFixed(category === 'zoom' ? 2 : 1)}{displaySuffix}
            </label>
          </div>
           <IconButton 
            onClick={() => { /* Reset logic needs to be implemented if desired for single controls */}} 
            tooltip={`Reset ${label}`} 
            className="p-0.5 hover:bg-gray-600"
            disabled // Placeholder for individual reset
          >
            <ResetIcon className="w-3.5 h-3.5 text-gray-400 opacity-50" />
          </IconButton>
        </div>
        <div className="space-y-1.5">
          <input
            type="number" // Changed to number for better native handling, but still parse from string
            id={`${idPrefix}-num`}
            value={displayValueForText}
            step={appStep.toString()}
            min={appMin.toString()}
            max={appMax.toString()}
            onChange={(e) => handleInputChange(category, axis, e.target.value)}
            onFocus={() => handleInputFocus(fieldName)}
            onBlur={() => handleInputBlur(category, axis, transform)}
            className="w-full bg-gray-800 border border-gray-600 text-gray-200 rounded-md py-1 px-2 text-sm focus:ring-indigo-500 focus:border-indigo-500"
          />
          <div className="relative w-full">
            <input
              type="range"
              id={`${idPrefix}-slider`}
              min={transform.sliderHtmlMin}
              max={transform.sliderHtmlMax}
              step={transform.isTransformed ? 1 : appStep}
              value={sliderVisualValue}
              onChange={(e) => handleSliderChange(category, axis, e.target.value, transform)}
              className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-400"
            />
             {/* Optional: Default mark for sliders based on defaultCameraConfig */}
          </div>
        </div>
      </div>
    );
  };

  return (
    <Panel title="Camera Controls" className="overflow-y-auto h-full">
      <div>
        <div className="mb-4">
          <label htmlFor="cameraPreset" className="block text-sm font-medium text-gray-300 mb-1">Camera Presets</label>
          <select
            id="cameraPreset"
            value=""
            onChange={(e) => {
              const selected = cameraPresets.find(p => p.name === e.target.value);
              if (selected) onApplyPreset(selected);
              e.target.value = "";
            }}
            className="block w-full bg-gray-700 border-gray-600 text-gray-200 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          >
            <option value="">Select a preset...</option>
            {cameraPresets.map(preset => <option key={preset.name} value={preset.name}>{preset.name}</option>)}
          </select>
        </div>

        <div className="space-y-4">
          <div className="camera-control-group">
            <h4 className="text-sm font-medium text-indigo-300 mb-2 border-b border-gray-600 pb-1.5 pt-1">Position</h4>
            <div className="space-y-2 pl-1">
              {renderControl("X", "posX", -50, 50, 0.1, 'position', 'x', "m", PositionXAxisIcon)}
              {renderControl("Y", "posY", -20, 50, 0.1, 'position', 'y', "m", PositionYAxisIcon)}
              {renderControl("Z", "posZ", -50, 50, 0.1, 'position', 'z', "m", PositionZAxisIcon)}
            </div>
          </div>
          <div className="camera-control-group">
            <h4 className="text-sm font-medium text-indigo-300 mb-2 border-b border-gray-600 pb-1.5 pt-1">Rotation</h4>
            <div className="space-y-2 pl-1">
              {renderControl("Pitch (X)", "rotX", -89.9, 89.9, 0.1, 'rotation', 'x', "°", RotationPitchIcon)}
              {renderControl("Yaw (Y)", "rotY", -360, 360, 0.1, 'rotation', 'y', "°", RotationYawIcon)}
              {renderControl("Roll (Z)", "rotZ", -180, 180, 0.1, 'rotation', 'z', "°", RotationRollIcon)}
            </div>
          </div>
          <div className="camera-control-group">
            <h4 className="text-sm font-medium text-indigo-300 mb-2 border-b border-gray-600 pb-1.5 pt-1">Lens</h4>
            <div className="space-y-2 pl-1">
              {renderControl("FOV", "fov", 10, 120, 1, 'fov', undefined, "°", FovIcon)}
              {renderControl("Zoom", "zoom", 0.1, 20, 0.01, 'zoom', undefined, "x", ZoomIcon)}
            </div>
          </div>
        </div>
      </div>
      <Button
        onClick={() => {
          const fullDefaultConfig = {
            ...defaultCameraConfig, // App-wide default
            source: 'ui' as const,
            timestamp: Date.now(),
            updateId: syncManager.generateUpdateId(),
          };
          setLocalEditableCamera(syncManager.toEditableConfig(fullDefaultConfig));
          propagateUpdate(fullDefaultConfig, false); // false for immediate
        }}
        variant="secondary"
        size="sm"
        className="w-full mt-6 py-2"
      >
        <div className="flex flex-col items-center">
          <div className="flex"><ResetIcon className="w-4 h-4 text-gray-300" /><SidebarCameraIcon className="w-4 h-4 ml-1 text-gray-300" /></div>
          <span className="text-xs mt-0.5">Reset All to Default</span>
        </div>
      </Button>
       {/* Debug info */}
      <div className="debug-info text-xs opacity-70 mt-3 p-2 bg-gray-850 rounded">
        <div>Source: {propsCamera.source} (TS: {propsCamera.timestamp?.toString().slice(-5)})</div>
        <div>Update ID: {propsCamera.updateId?.slice(-8)}</div>
        <div>User Edit: {isUserEditing ? 'Yes' : 'No'}</div>
        <div>Focused: {JSON.stringify(inputFocusRef.current)}</div>
      </div>
    </Panel>
  );
};

export default CameraControlsTab;
