
import React from 'react';
import { Frame } from '../../types';

interface FrameCardProps {
  frame: Frame;
  isSelected: boolean;
  onClick: () => void;
}

const FrameCard: React.FC<FrameCardProps> = ({ frame, isSelected, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`flex-shrink-0 w-40 h-28 bg-gray-700 rounded-md overflow-hidden border-2 transition-all duration-150 ease-in-out
                  ${isSelected ? 'border-indigo-500 shadow-lg scale-105' : 'border-gray-600 hover:border-indigo-400'}
                  focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-800
                  flex flex-col justify-between items-center p-1.5 group`}
    >
      <img 
        src={frame.thumbnailUrl} 
        alt={frame.name} 
        className="w-full h-16 object-cover rounded-sm mb-1 group-hover:opacity-80 transition-opacity"
      />
      <span className="text-xs text-center text-gray-300 group-hover:text-white truncate w-full">
        {frame.name}
      </span>
      <div className="text-xxs text-gray-400">
        {frame.characters.length} C, {frame.objects.length} O
      </div>
    </button>
  );
};

export default FrameCard;
