
import React, { useState, useEffect } from 'react';
import { StoryObject, AssetLibraryItem, Frame, LightConfig, StoryCharacter } from '../../types';
import Button from '../ui/Button';
import TextInput from '../ui/TextInput';
import Panel from '../ui/Panel';
import { PlusIcon } from '../../constants';
import IconButton from '../ui/IconButton';
import MiniMap from '../ui/MiniMap.tsx';

interface ObjectFormProps {
  initialData?: StoryObject; // For editing existing object
  selectedAssetForForm?: AssetLibraryItem | null; // For configuring library asset
  onAddObject: (obj: Omit<StoryObject, 'id' | 'threeUUID' | 'assetScale' | 'yOffset'> & { position?: { x: number, y: number, z: number }, modelUrl?: string, assetScale?: {x:number,y:number,z:number}, yOffset?: number }) => void;
  onUpdateObject: (obj: StoryObject) => void;
  availableColors: string[];
  onClearSelectedAsset: () => void;
  onFormSubmitAfterLibraryAssetAdd?: () => void;
  onCancel?: () => void; // To notify parent to switch view
  currentFrame: Frame | undefined;
  allSceneCharacters: StoryCharacter[];
  allSceneLights: LightConfig[];
}

const objectTypes = ['Cube', 'Sphere', 'Cylinder', 'Plane'];


const ObjectForm: React.FC<ObjectFormProps> = ({ 
    initialData,
    selectedAssetForForm,
    onAddObject, 
    onUpdateObject, 
    availableColors,
    onClearSelectedAsset,
    onFormSubmitAfterLibraryAssetAdd,
    onCancel,
    currentFrame,
    allSceneCharacters,
    allSceneLights
}) => {
  const [name, setName] = useState('');
  const [type, setType] = useState('Cube');
  const [color, setColor] = useState(availableColors[0]);
  const [size, setSize] = useState(5); 
  const [position, setPosition] = useState<{ x: string, y: string, z: string }>({ x: '0', y: '0.51', z: '0' });
  
  const [isLibraryAsset, setIsLibraryAsset] = useState<boolean>(false);
  const [currentModelUrl, setCurrentModelUrl] = useState<string | undefined>(undefined);
  const [currentAssetScale, setCurrentAssetScale] = useState<{x:number,y:number,z:number} | undefined>(undefined);
  const [currentYOffset, setCurrentYOffset] = useState<number | undefined>(undefined);

  const isEditing = !!initialData;

  useEffect(() => {
    if (selectedAssetForForm && selectedAssetForForm.type === 'object') {
      setName(selectedAssetForForm.name);
      setType('LibraryModel'); 
      setColor('#CCCCCC'); 
      setSize(1); 
      const assetY = (selectedAssetForForm.yOffset ?? 0).toFixed(2);
      setPosition({ x: '0', y: assetY, z: '0'});
      setCurrentModelUrl(selectedAssetForForm.modelUrl);
      setCurrentAssetScale(selectedAssetForForm.defaultScale);
      setCurrentYOffset(selectedAssetForForm.yOffset);
      setIsLibraryAsset(true);
    } else if (initialData) { // Editing existing object
      setName(initialData.name);
      setType(initialData.modelUrl ? 'LibraryModel' : initialData.type);
      setColor(initialData.color);
      setSize(initialData.size);
      setPosition({
        x: initialData.position?.x.toString() ?? '0',
        y: initialData.position?.y.toString() ?? '0', // Use actual Y
        z: initialData.position?.z.toString() ?? '0',
      });
      setIsLibraryAsset(!!initialData.modelUrl);
      setCurrentModelUrl(initialData.modelUrl);
      setCurrentAssetScale(initialData.assetScale);
      setCurrentYOffset(initialData.yOffset);
    } else {
      // This form is no longer for new primitive creation from scratch.
      setName('Object');
      setType('Cube');
      setColor(availableColors[0]);
      setSize(5);
      const defaultY = ((5 * 0.2) / 2 + 0.01).toFixed(2);
      setPosition({ x: '0', y: defaultY, z: '0' });
      setIsLibraryAsset(false);
      setCurrentModelUrl(undefined);
      setCurrentAssetScale(undefined);
      setCurrentYOffset(undefined);
    }
  }, [initialData, selectedAssetForForm, availableColors]);

  // This useEffect for size-based Y is only for primitives, no longer relevant here.
  // useEffect(() => {
  //   if (!isEditing && !isLibraryAsset) { 
  //       const defaultY = ((size * 0.2) / 2 + 0.01).toFixed(2);
  //       setPosition(prev => ({ ...prev, y: defaultY }));
  //   }
  // }, [size, isEditing, isLibraryAsset]);
  
  const handlePositionChange = (axis: 'x' | 'y' | 'z', value: string) => {
    setPosition(prev => ({ ...prev, [axis]: value }));
  };
  
  const handleMapClick = (sceneX: number, sceneZ: number) => {
    setPosition(prev => ({
      ...prev,
      x: sceneX.toFixed(1),
      z: sceneZ.toFixed(1),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Object name is required.');
      return;
    }
    
    const parsedPosition = {
        x: parseFloat(position.x) || 0,
        y: parseFloat(position.y), 
        z: parseFloat(position.z) || 0,
    };
    if (isNaN(parsedPosition.y)) { 
      parsedPosition.y = isLibraryAsset ? (currentYOffset || 0) : ((size * 0.2) / 2 + 0.01);
    }

    const objectData = { 
        name, 
        type: isLibraryAsset ? 'LibraryModel' : type, 
        color: isLibraryAsset ? '#CCCCCC' : color,
        size: isLibraryAsset ? 1 : size, 
        position: parsedPosition,
        modelUrl: currentModelUrl,
        assetScale: currentAssetScale,
        yOffset: currentYOffset,
    };
    
    if (isEditing && initialData) {
      onUpdateObject({ ...initialData, ...objectData, id: initialData.id, threeUUID: initialData.threeUUID });
    } else if (selectedAssetForForm) { // Adding from library
      onAddObject(objectData as Omit<StoryObject, 'id' | 'threeUUID'>);
       if (onFormSubmitAfterLibraryAssetAdd) {
        onFormSubmitAfterLibraryAssetAdd();
      }
    }
  };
  
  const handleLocalCancel = () => {
    if (onCancel) {
        onCancel();
    }
    onClearSelectedAsset(); // Always clear asset if canceling from this form
  };

  const mapItems = currentFrame ? [
    ...(allSceneCharacters || []).map(c => ({ id: c.id, x: c.position?.x ?? 0, z: c.position?.z ?? 0, type: 'character' as const, name: c.name })),
    ...(currentFrame.objects || []).filter(o => !initialData || o.id !== initialData.id).map(o => ({ id: o.id, x: o.position?.x ?? 0, z: o.position?.z ?? 0, type: 'object' as const, name: o.name })),
    ...(allSceneLights || []).filter(l => l.type !== 'Ambient').map(l => ({ id: l.id, x: l.position.x, z: l.position.z, type: 'light' as const, name: l.name })),
  ] : [];
  
  const title = isEditing ? `Edit: ${initialData?.name}` : (selectedAssetForForm ? `Configure Asset: ${selectedAssetForForm.name}` : "Object Details");

  return (
    <Panel title={title}>
      <form onSubmit={handleSubmit} className="space-y-3">
        
        {selectedAssetForForm && currentModelUrl && (
           <div className="p-2 bg-gray-850 rounded-md border border-indigo-700 mb-3">
            <p className="text-sm text-indigo-300">
                From library: <span className="font-semibold">{selectedAssetForForm.name}</span>
            </p>
            <p className="text-xs text-gray-400 truncate">Model: {currentModelUrl.split('/').pop()}</p>
          </div>
        )}
        
        <TextInput label="Name" id="objName" value={name} onChange={(e) => setName(e.target.value)} required />
        
        {!isLibraryAsset && ( 
          <>
            <div className="grid grid-cols-2 gap-x-3 gap-y-3">
                <div>
                    <label htmlFor="objType" className="block text-sm font-medium text-gray-300 mb-1">Type</label>
                    <select 
                        id="objType" 
                        value={type} 
                        onChange={(e) => setType(e.target.value)}
                        className="block w-full bg-gray-700 border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    >
                        {objectTypes.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Color (Primitive)</label>
                    <div className="flex flex-wrap gap-1.5">
                        {availableColors.slice(0, 5).map(c => ( 
                        <button
                            key={c}
                            type="button"
                            onClick={() => setColor(c)}
                            className={`w-7 h-7 rounded-full border-2 ${color === c ? 'border-white ring-1 ring-indigo-500' : 'border-transparent hover:border-gray-400'}`}
                            style={{ backgroundColor: c }}
                            title={c}
                            aria-label={`Select color ${c}`}
                        />
                        ))}
                    </div>
                </div>
            </div>
            
            <div>
              <label htmlFor="objSize" className="block text-sm font-medium text-gray-300 mb-1">Size (Primitive): {size}</label>
              <input 
                type="range" 
                id="objSize" 
                min="1" 
                max="10" 
                value={size} 
                onChange={(e) => setSize(parseInt(e.target.value))}
                className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-indigo-500"
              />
            </div>
          </>
        )}
        
        {(isEditing || selectedAssetForForm) && currentFrame && (
            <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Initial Position (X, Y, Z)</label>
                <div className="grid grid-cols-3 gap-2">
                    <TextInput label="" id="objPosX" type="number" step="0.1" value={position.x} onChange={(e) => handlePositionChange('x', e.target.value)} />
                    <TextInput label="" id="objPosY" type="number" step="0.1" value={position.y} onChange={(e) => handlePositionChange('y', e.target.value)} />
                    <TextInput label="" id="objPosZ" type="number" step="0.1" value={position.z} onChange={(e) => handlePositionChange('z', e.target.value)} />
                </div>
                {currentFrame && (
                    <div className="mt-3">
                        <MiniMap
                            items={mapItems}
                            bounds={{ minX: -25, maxX: 25, minZ: -25, maxZ: 25 }}
                            pendingX={parseFloat(position.x)}
                            pendingZ={parseFloat(position.z)}
                            onMapClick={handleMapClick}
                        />
                    </div>
                )}
            </div>
        )}


        <div className="flex space-x-2 pt-2">
          <Button type="submit" variant="primary" className="flex-1">
            <PlusIcon className="w-4 h-4 mr-2" /> {isEditing ? 'Save Changes' : 'Add to Scene'}
          </Button>
          {(isEditing || selectedAssetForForm) && onCancel && (
            <Button type="button" variant="secondary" onClick={handleLocalCancel} className="flex-1">
              Cancel
            </Button>
          )}
        </div>
      </form>
    </Panel>
  );
};

export default ObjectForm;