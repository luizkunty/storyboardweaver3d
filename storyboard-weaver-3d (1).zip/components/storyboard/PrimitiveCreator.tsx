
import React, { useState, useEffect } from 'react';
import { Frame, StoryCharacter, StoryObject, LightConfig, PrimitiveType as GlobalPrimitiveType } from '../../types';
import Button from '../ui/Button';
import TextInput from '../ui/TextInput';
import MiniMap from '../ui/MiniMap';
import { PlusIcon, TrashIcon, CubeIcon, UserGroupIcon } from '../../constants';
import IconButton from '../ui/IconButton';

type PrimitiveTypeOption = 'character' | 'object'; // 'wall' and 'room' can be added later

interface PrimitiveCreatorProps {
  currentFrame: Frame;
  availableColors: string[];
  onAddCharacter: (character: Omit<StoryCharacter, 'id' | 'threeUUID'>) => void;
  onRemoveCharacter: (characterId: string) => void;
  onEditCharacter: (characterId: string) => void;
  onAddObject: (obj: Omit<StoryObject, 'id' | 'threeUUID'>) => void;
  onRemoveObject: (objectId: string) => void;
  onEditObject: (objectId: string) => void;
}

const ageBrackets = ["Child", "Adult", "Senior"];
const poseOptions = ["Standing", "Sitting", "Walking", "Running", "Jumping", "Waving", "Idle"];
const objectPrimitiveTypes = ['Cube', 'Sphere', 'Cylinder', 'Plane'];

const calculateNextAvailableNumber = (items: Array<{name: string}>, prefix: string): number => {
  let maxNum = 0;
  const regex = new RegExp(`^${prefix.trim()}\\s*(\\d+)$`, 'i');
  items.forEach(item => {
    const match = item.name.match(regex);
    if (match && match[1]) {
      maxNum = Math.max(maxNum, parseInt(match[1]));
    }
  });
  return maxNum + 1;
};


const PrimitiveCreator: React.FC<PrimitiveCreatorProps> = ({
  currentFrame,
  availableColors,
  onAddCharacter,
  onRemoveCharacter,
  onEditCharacter,
  onAddObject,
  onRemoveObject,
  onEditObject,
}) => {
  const [selectedPrimitiveType, setSelectedPrimitiveType] = useState<PrimitiveTypeOption>('character');
  
  // Character State
  const [charName, setCharName] = useState('');
  const [charAgeBracket, setCharAgeBracket] = useState<string>(ageBrackets[1]);
  const [charPose, setCharPose] = useState(poseOptions[0]);
  const [charColor, setCharColor] = useState(availableColors[0]);
  const [charPosition, setCharPosition] = useState<{ x: string, y: string, z: string }>({ x: '0', y: '0.85', z: '0' });

  // Object State
  const [objName, setObjName] = useState('');
  const [objType, setObjType] = useState(objectPrimitiveTypes[0]);
  const [objColor, setObjColor] = useState(availableColors[0]);
  const [objSize, setObjSize] = useState(5);
  const [objPosition, setObjPosition] = useState<{ x: string, y: string, z: string }>({ x: '0', y: '0.51', z: '0' });

  const resetCharacterForm = () => {
    const nextCharNumber = calculateNextAvailableNumber(currentFrame.characters, "Character");
    setCharName(`Character ${nextCharNumber}`);
    setCharAgeBracket(ageBrackets[1]);
    setCharPose(poseOptions[0]);
    setCharColor(availableColors[0]);
    setCharPosition({ x: '0', y: '0.85', z: '0' });
  };

  const resetObjectForm = () => {
    const nextObjNumber = calculateNextAvailableNumber(currentFrame.objects, "Object");
    setObjName(`Object ${nextObjNumber}`);
    setObjType(objectPrimitiveTypes[0]);
    setObjColor(availableColors[0]);
    setObjSize(5);
    const defaultY = ((5 * 0.2) / 2 + 0.01).toFixed(2);
    setObjPosition({ x: '0', y: defaultY, z: '0' });
  };
  
  useEffect(() => {
    if (selectedPrimitiveType === 'character') {
      resetCharacterForm();
    } else if (selectedPrimitiveType === 'object') {
      resetObjectForm();
    }
  }, [selectedPrimitiveType, currentFrame.characters, currentFrame.objects, availableColors]);

  // Update object Y position if size changes (for primitives)
   useEffect(() => {
    if (selectedPrimitiveType === 'object') {
        const defaultY = ((objSize * 0.2) / 2 + 0.01).toFixed(2);
        setObjPosition(prev => ({ ...prev, y: defaultY }));
    }
  }, [objSize, selectedPrimitiveType]);


  const handleCharPositionChange = (axis: 'x' | 'y' | 'z', value: string) => {
    setCharPosition(prev => ({ ...prev, [axis]: value }));
  };
  const handleCharMapClick = (sceneX: number, sceneZ: number) => {
    setCharPosition(prev => ({ ...prev, x: sceneX.toFixed(1), z: sceneZ.toFixed(1) }));
  };

  const handleObjPositionChange = (axis: 'x' | 'y' | 'z', value: string) => {
    setObjPosition(prev => ({ ...prev, [axis]: value }));
  };
  const handleObjMapClick = (sceneX: number, sceneZ: number) => {
    setObjPosition(prev => ({ ...prev, x: sceneX.toFixed(1), z: sceneZ.toFixed(1) }));
  };

  const handleAddPrimitive = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedPrimitiveType === 'character') {
      if (!charName.trim()) { alert('Character name is required.'); return; }
      const parsedPosition = { x: parseFloat(charPosition.x) || 0, y: parseFloat(charPosition.y) || 0.85, z: parseFloat(charPosition.z) || 0 };
      onAddCharacter({ name: charName, ageBracket: charAgeBracket, pose: charPose, movement: "Idle", color: charColor, position: parsedPosition });
      resetCharacterForm();
    } else if (selectedPrimitiveType === 'object') {
      if (!objName.trim()) { alert('Object name is required.'); return; }
      const parsedPosition = { x: parseFloat(objPosition.x) || 0, y: parseFloat(objPosition.y) || 0.51, z: parseFloat(objPosition.z) || 0 };
      onAddObject({ name: objName, type: objType, color: objColor, size: objSize, position: parsedPosition });
      resetObjectForm();
    }
  };
  
  const mapItems = currentFrame ? [
    ...(currentFrame.characters || []).map(c => ({ id: c.id, x: c.position?.x ?? 0, z: c.position?.z ?? 0, type: 'character' as const, name: c.name })),
    ...(currentFrame.objects || []).map(o => ({ id: o.id, x: o.position?.x ?? 0, z: o.position?.z ?? 0, type: 'object' as const, name: o.name })),
    ...(currentFrame.lights || []).filter(l => l.type !== 'Ambient').map(l => ({ id: l.id, x: l.position.x, z: l.position.z, type: 'light' as const, name: l.name })),
  ] : [];


  return (
    <div className="p-4 space-y-4">
      <div>
        <label htmlFor="primitiveType" className="block text-sm font-medium text-gray-300 mb-1">Primitive Type</label>
        <select
          id="primitiveType"
          value={selectedPrimitiveType}
          onChange={(e) => setSelectedPrimitiveType(e.target.value as PrimitiveTypeOption)}
          className="block w-full bg-gray-700 border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
        >
          <option value="character">Character</option>
          <option value="object">Object</option>
          {/* <option value="wall" disabled>Wall (Coming Soon)</option>
          <option value="room" disabled>Room (Coming Soon)</option> */}
        </select>
      </div>

      <form onSubmit={handleAddPrimitive} className="space-y-3 p-3 bg-gray-800 rounded-md border border-gray-700">
        <h3 className="text-md font-semibold text-indigo-400 border-b border-gray-700 pb-2">
          Add New {selectedPrimitiveType.charAt(0).toUpperCase() + selectedPrimitiveType.slice(1)}
        </h3>
        {selectedPrimitiveType === 'character' && (
          <>
            <TextInput label="Name" id="primCharName" value={charName} onChange={(e) => setCharName(e.target.value)} required />
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="primCharAge" className="block text-xs font-medium text-gray-300 mb-1">Age</label>
                <select id="primCharAge" value={charAgeBracket} onChange={e => setCharAgeBracket(e.target.value)} className="block w-full text-xs bg-gray-700 border-gray-600 rounded py-1.5 px-2 focus:ring-indigo-500 focus:border-indigo-500">
                  {ageBrackets.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="primCharPose" className="block text-xs font-medium text-gray-300 mb-1">Pose</label>
                <select id="primCharPose" value={charPose} onChange={e => setCharPose(e.target.value)} className="block w-full text-xs bg-gray-700 border-gray-600 rounded py-1.5 px-2 focus:ring-indigo-500 focus:border-indigo-500">
                  {poseOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
              </div>
            </div>
             <div>
                <label className="block text-xs font-medium text-gray-300 mb-1">Color</label>
                <div className="flex flex-wrap gap-1.5">
                    {availableColors.slice(0, 7).map(c => (
                    <button type="button" key={c} onClick={() => setCharColor(c)} className={`w-6 h-6 rounded-full border-2 ${charColor === c ? 'border-white ring-1 ring-indigo-500' : 'border-transparent hover:border-gray-400'}`} style={{ backgroundColor: c }}/>
                    ))}
                </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-300 mb-1">Position (X,Y,Z)</label>
              <div className="grid grid-cols-3 gap-2 mb-2">
                <TextInput label="" id="primCharPosX" type="number" step="0.1" value={charPosition.x} onChange={e => handleCharPositionChange('x', e.target.value)} placeholder="X" className="text-xs py-1.5"/>
                <TextInput label="" id="primCharPosY" type="number" step="0.1" value={charPosition.y} onChange={e => handleCharPositionChange('y', e.target.value)} placeholder="Y" className="text-xs py-1.5"/>
                <TextInput label="" id="primCharPosZ" type="number" step="0.1" value={charPosition.z} onChange={e => handleCharPositionChange('z', e.target.value)} placeholder="Z" className="text-xs py-1.5"/>
              </div>
              <MiniMap items={mapItems} bounds={{ minX: -25, maxX: 25, minZ: -25, maxZ: 25 }} pendingX={parseFloat(charPosition.x)} pendingZ={parseFloat(charPosition.z)} onMapClick={handleCharMapClick} mapPixelDimensions={{width: 180, height:180}}/>
            </div>
          </>
        )}

        {selectedPrimitiveType === 'object' && (
          <>
            <TextInput label="Name" id="primObjName" value={objName} onChange={(e) => setObjName(e.target.value)} required />
            <div className="grid grid-cols-2 gap-3">
                <div>
                    <label htmlFor="primObjType" className="block text-xs font-medium text-gray-300 mb-1">Type</label>
                    <select id="primObjType" value={objType} onChange={e => setObjType(e.target.value)} className="block w-full text-xs bg-gray-700 border-gray-600 rounded py-1.5 px-2 focus:ring-indigo-500 focus:border-indigo-500">
                    {objectPrimitiveTypes.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                    </select>
                </div>
                 <div>
                    <label className="block text-xs font-medium text-gray-300 mb-1">Color</label>
                    <div className="flex flex-wrap gap-1.5">
                        {availableColors.slice(0,7).map(c => (
                        <button type="button" key={c} onClick={() => setObjColor(c)} className={`w-6 h-6 rounded-full border-2 ${objColor === c ? 'border-white ring-1 ring-indigo-500' : 'border-transparent hover:border-gray-400'}`} style={{ backgroundColor: c }}/>
                        ))}
                    </div>
                </div>
            </div>
            <div>
                <label htmlFor="primObjSize" className="block text-xs font-medium text-gray-300 mb-1">Size: {objSize}</label>
                <input type="range" id="primObjSize" min="1" max="10" value={objSize} onChange={e => setObjSize(parseInt(e.target.value))} className="w-full h-1.5 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-indigo-500"/>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-300 mb-1">Position (X,Y,Z)</label>
              <div className="grid grid-cols-3 gap-2 mb-2">
                <TextInput label="" id="primObjPosX" type="number" step="0.1" value={objPosition.x} onChange={e => handleObjPositionChange('x', e.target.value)} placeholder="X" className="text-xs py-1.5"/>
                <TextInput label="" id="primObjPosY" type="number" step="0.1" value={objPosition.y} onChange={e => handleObjPositionChange('y', e.target.value)} placeholder="Y" className="text-xs py-1.5"/>
                <TextInput label="" id="primObjPosZ" type="number" step="0.1" value={objPosition.z} onChange={e => handleObjPositionChange('z', e.target.value)} placeholder="Z" className="text-xs py-1.5"/>
              </div>
              <MiniMap items={mapItems} bounds={{ minX: -25, maxX: 25, minZ: -25, maxZ: 25 }} pendingX={parseFloat(objPosition.x)} pendingZ={parseFloat(objPosition.z)} onMapClick={handleObjMapClick} mapPixelDimensions={{width: 180, height:180}}/>
            </div>
          </>
        )}
        <Button type="submit" variant="primary" className="w-full">
          <PlusIcon className="w-4 h-4 mr-2" /> Add Primitive
        </Button>
      </form>

      {/* List existing items */}
      <div className="mt-6">
        <h4 className="text-md font-semibold text-gray-300 mb-2">
          Scene {selectedPrimitiveType === 'character' ? 'Characters' : 'Objects'} ({selectedPrimitiveType === 'character' ? currentFrame.characters.length : currentFrame.objects.length})
        </h4>
        <ul className="space-y-1.5 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
          {(selectedPrimitiveType === 'character' ? currentFrame.characters : currentFrame.objects).map((item: StoryCharacter | StoryObject) => (
            <li key={item.id} className="flex items-center justify-between bg-gray-700 p-1.5 rounded hover:bg-gray-600">
              <div className="flex items-center overflow-hidden mr-2">
                {item.modelUrl ? (
                  <CubeIcon className="w-3.5 h-3.5 mr-1.5 flex-shrink-0 text-indigo-400" />
                ) : (
                  <div className="w-3 h-3 rounded-sm mr-1.5 flex-shrink-0" style={{backgroundColor: item.color}}></div>
                )}
                <span className="text-xs truncate" title={item.name}>{item.name}</span>
              </div>
              <div className="space-x-1 flex-shrink-0">
                <Button size="sm" variant="ghost" onClick={() => selectedPrimitiveType === 'character' ? onEditCharacter(item.id) : onEditObject(item.id)} className="px-1.5 py-0.5 text-xxs">Edit</Button>
                <IconButton onClick={() => selectedPrimitiveType === 'character' ? onRemoveCharacter(item.id) : onRemoveObject(item.id)} tooltip="Remove" className="p-0.5">
                  <TrashIcon className="w-3 h-3 text-red-400 hover:text-red-300" />
                </IconButton>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default PrimitiveCreator;
