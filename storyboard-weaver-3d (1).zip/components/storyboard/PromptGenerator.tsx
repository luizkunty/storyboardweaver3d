
import React, { useState, useEffect } from 'react';
import { generateSceneIdeas } from '../../services/geminiService';
import Button from '../ui/Button';
import Panel from '../ui/Panel';
import { SparklesIcon } from '../../constants';

interface PromptGeneratorProps {
  onApplyPrompt: (sceneDescription: string) => void;
}

const PromptGenerator: React.FC<PromptGeneratorProps> = ({ onApplyPrompt }) => {
  const [prompt, setPrompt] = useState<string>('');
  const [numScenes, setNumScenes] = useState<number>(3);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedIdeas, setGeneratedIdeas] = useState<string | null>(null);
  const [editableGeneratedIdeas, setEditableGeneratedIdeas] = useState<string>('');

  useEffect(() => {
    if (generatedIdeas) {
      setEditableGeneratedIdeas(generatedIdeas);
    }
  }, [generatedIdeas]);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!prompt.trim()) {
      setError("Please enter a prompt.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedIdeas(null);
    setEditableGeneratedIdeas('');

    try {
      const ideas = await generateSceneIdeas(prompt, numScenes);
      setGeneratedIdeas(ideas);
    } catch (err: any) {
      setError(err.message || "Failed to generate ideas. Check console for details.");
      console.error("Gemini API error in component:", err);
       if (err.message && err.message.includes("API_KEY")) {
        setError("Gemini API Key is not configured correctly. AI features are unavailable. Please check your environment setup.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.key === 'Enter' && !e.shiftKey) || (e.key === 'Enter' && e.ctrlKey)) {
      e.preventDefault(); 
      handleSubmit();
    }
  };
  
  const handleApply = () => {
    if (editableGeneratedIdeas) {
      onApplyPrompt(editableGeneratedIdeas);
      setGeneratedIdeas(null); 
      setEditableGeneratedIdeas('');
      // setPrompt(''); // Optionally clear prompt after applying
    }
  };

  return (
    <Panel title="AI Scene Idea Generator">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="scenePrompt" className="block text-sm font-medium text-gray-300 mb-1">
            Describe your scene or story idea:
          </label>
          <textarea
            id="scenePrompt"
            rows={4}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={handleKeyDown}
            className="block w-full bg-gray-700 border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="e.g., A detective investigates a mysterious signal in a cyberpunk city."
          />
        </div>
        <div>
          <label htmlFor="numScenes" className="block text-sm font-medium text-gray-300 mb-1">
            Number of Scenes to Generate (1-5):
          </label>
          <input
            type="number"
            id="numScenes"
            value={numScenes}
            onChange={(e) => setNumScenes(Math.max(1, Math.min(5, parseInt(e.target.value) || 1)))}
            min="1"
            max="5"
            className="block w-24 bg-gray-700 border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          />
        </div>
        <Button type="submit" isLoading={isLoading} disabled={isLoading || !prompt.trim()} className="w-full">
          <SparklesIcon className="w-5 h-5 mr-2" />
          Generate Ideas
        </Button>
      </form>

      {error && (
        <div className="mt-4 p-3 bg-red-900 bg-opacity-50 text-red-300 border border-red-700 rounded-md text-sm">
          <p className="font-semibold">Error:</p>
          <p>{error}</p>
        </div>
      )}

      {generatedIdeas && (
        <div className="mt-6 space-y-3">
          <h4 className="text-md font-semibold text-gray-200">Generated Ideas (Editable):</h4>
          <textarea
            rows={10}
            value={editableGeneratedIdeas}
            onChange={(e) => setEditableGeneratedIdeas(e.target.value)}
            className="block w-full bg-gray-700 border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm max-h-80 overflow-y-auto custom-scrollbar"
            aria-label="Editable generated ideas"
          />
          <Button onClick={handleApply} variant="secondary" className="w-full" disabled={!editableGeneratedIdeas.trim()}>
            Apply Ideas
          </Button>
        </div>
      )}
       {!process.env.API_KEY && (
         <div className="mt-4 p-3 bg-yellow-900 bg-opacity-50 text-yellow-300 border border-yellow-700 rounded-md text-sm">
            <p className="font-semibold">Note:</p>
            <p>Gemini API key (API_KEY) is not detected in the environment. AI scene generation is disabled. Please set it up to use this feature.</p>
        </div>
       )}
    </Panel>
  );
};

export default PromptGenerator;
