
import React, { useState, useEffect } from 'react';
import { StoryCharacter, AssetLibraryItem, Frame, StoryObject, LightConfig } from '../../types';
import Button from '../ui/Button';
import TextInput from '../ui/TextInput';
import Panel from '../ui/Panel';
import { PlusIcon } from '../../constants'; 
import IconButton from '../ui/IconButton';
import MiniMap from '../ui/MiniMap.tsx';

interface CharacterFormProps {
  initialData?: StoryCharacter; // For editing existing character
  selectedAssetForForm?: AssetLibraryItem | null; // For configuring library asset
  onAddCharacter: (character: Omit<StoryCharacter, 'id' | 'threeUUID' | 'assetScale' | 'yOffset'> & { modelUrl?: string, assetScale?: {x:number,y:number,z:number}, yOffset?: number, position?: {x: number, y: number, z: number} }) => void;
  onUpdateCharacter: (character: StoryCharacter) => void;
  availableColors: string[]; // Still needed for primitive fallback if asset has no color
  onClearSelectedAsset: () => void; // To clear asset after submission/cancel
  onFormSubmitAfterLibraryAssetAdd?: () => void; // To notify parent (ElementsPanel)
  onCancel?: () => void; // To notify parent to switch view
  currentFrame: Frame | undefined; 
  allSceneObjects: StoryObject[]; 
  allSceneLights: LightConfig[]; 
}

const ageBrackets = ["Child", "Adult", "Senior"];
const poseOptions = ["Standing", "Sitting", "Walking", "Running", "Jumping", "Waving", "Idle"];
const movementOptions = ["None", "Idle", "Walking Forward", "Running Fast"];


const CharacterForm: React.FC<CharacterFormProps> = ({ 
  initialData,
  selectedAssetForForm,
  onAddCharacter, 
  onUpdateCharacter, 
  availableColors,
  onClearSelectedAsset,
  onFormSubmitAfterLibraryAssetAdd,
  onCancel,
  currentFrame,
  allSceneObjects,
  allSceneLights
}) => {
  const [name, setName] = useState('');
  const [ageBracket, setAgeBracket] = useState<string>(ageBrackets[1]);
  const [pose, setPose] = useState(poseOptions[0]);
  const [movement, setMovement] = useState(movementOptions[0]);
  const [color, setColor] = useState(availableColors[0]);
  const [position, setPosition] = useState<{ x: string, y: string, z: string }>({ x: '0', y: '0.85', z: '0' });
  
  const [isLibraryAsset, setIsLibraryAsset] = useState<boolean>(false);
  const [currentModelUrl, setCurrentModelUrl] = useState<string | undefined>(undefined);
  const [currentAssetScale, setCurrentAssetScale] = useState<{x:number,y:number,z:number} | undefined>(undefined);
  const [currentYOffset, setCurrentYOffset] = useState<number | undefined>(undefined);

  const isEditing = !!initialData;

  useEffect(() => {
    if (selectedAssetForForm && selectedAssetForForm.type === 'character') {
      setName(selectedAssetForForm.name);
      setAgeBracket(selectedAssetForForm.category?.includes('Child') ? 'Child' : selectedAssetForForm.category?.includes('Senior') ? 'Senior' : 'Adult');
      setPose('Imported'); 
      setMovement('Imported');
      setColor('#CCCCCC'); 
      const assetY = (selectedAssetForForm.yOffset ?? 0).toFixed(2);
      setPosition({ x: '0', y: assetY, z: '0'});
      setCurrentModelUrl(selectedAssetForForm.modelUrl);
      setCurrentAssetScale(selectedAssetForForm.defaultScale);
      setCurrentYOffset(selectedAssetForForm.yOffset);
      setIsLibraryAsset(true);
    } else if (initialData) { // Editing existing character
      setName(initialData.name);
      setAgeBracket(initialData.ageBracket || ageBrackets[1]);
      setPose(initialData.pose);
      setMovement(initialData.movement);
      setColor(initialData.color);
      setPosition({
        x: initialData.position?.x.toString() ?? '0',
        y: initialData.position?.y.toString() ?? '0.85',
        z: initialData.position?.z.toString() ?? '0',
      });
      setIsLibraryAsset(!!initialData.modelUrl);
      setCurrentModelUrl(initialData.modelUrl);
      setCurrentAssetScale(initialData.assetScale);
      setCurrentYOffset(initialData.yOffset);
    } else {
      // This form is no longer for new primitive creation from scratch.
      // Reset to some baseline if no data is provided (should not happen if logic is correct)
      setName('Character');
      setAgeBracket(ageBrackets[1]);
      setPose(poseOptions[0]);
      setMovement(movementOptions[0]);
      setColor(availableColors[0]);
      setPosition({ x: '0', y: '0.85', z: '0' });
      setIsLibraryAsset(false);
      setCurrentModelUrl(undefined);
      setCurrentAssetScale(undefined);
      setCurrentYOffset(undefined);
    }
  }, [initialData, selectedAssetForForm, availableColors]);


  const handlePositionChange = (axis: 'x' | 'y' | 'z', value: string) => {
    setPosition(prev => ({ ...prev, [axis]: value }));
  };

  const handleMapClick = (sceneX: number, sceneZ: number) => {
    setPosition(prev => ({
      ...prev,
      x: sceneX.toFixed(1),
      z: sceneZ.toFixed(1),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Character name is required.');
      return;
    }

    const parsedPosition = {
        x: parseFloat(position.x) || 0,
        y: parseFloat(position.y), 
        z: parseFloat(position.z) || 0,
    };
     if (isNaN(parsedPosition.y)) { 
      parsedPosition.y = isLibraryAsset ? (currentYOffset || 0) : 0.85;
    }

    const characterData = { 
        name, 
        ageBracket: isLibraryAsset ? ageBracket : ageBracket, 
        pose: isLibraryAsset ? 'Imported' : pose, 
        movement: isLibraryAsset ? 'Imported' : movement,
        color: isLibraryAsset ? '#CCCCCC' : color, 
        modelUrl: currentModelUrl,
        assetScale: currentAssetScale,
        yOffset: currentYOffset,
        position: parsedPosition,
    };

    if (isEditing && initialData) {
      onUpdateCharacter({ ...initialData, ...characterData, id: initialData.id, threeUUID: initialData.threeUUID });
    } else if (selectedAssetForForm) { // Adding from library
      onAddCharacter(characterData as Omit<StoryCharacter, 'id' | 'threeUUID'>);
      if (onFormSubmitAfterLibraryAssetAdd) {
        onFormSubmitAfterLibraryAssetAdd();
      }
    }
    // This form doesn't reset itself; parent (ElementsPanel) controls view change.
  };
  
  const handleLocalCancel = () => {
    if (onCancel) {
      onCancel();
    }
    onClearSelectedAsset(); // Always clear asset if canceling from this form
  };
  
  const mapItems = currentFrame ? [
    ...(currentFrame.characters || []).filter(c => !initialData || c.id !== initialData.id).map(c => ({ id: c.id, x: c.position?.x ?? 0, z: c.position?.z ?? 0, type: 'character' as const, name: c.name })),
    ...(allSceneObjects || []).map(o => ({ id: o.id, x: o.position?.x ?? 0, z: o.position?.z ?? 0, type: 'object' as const, name: o.name })),
    ...(allSceneLights || []).filter(l => l.type !== 'Ambient').map(l => ({ id: l.id, x: l.position.x, z: l.position.z, type: 'light' as const, name: l.name })),
  ] : [];


  const title = isEditing ? `Edit: ${initialData?.name}` : (selectedAssetForForm ? `Configure Asset: ${selectedAssetForForm.name}` : "Character Details");

  return (
    <Panel title={title}>
      <form onSubmit={handleSubmit} className="space-y-3">
        
        {selectedAssetForForm && currentModelUrl && (
          <div className="p-2 bg-gray-850 rounded-md border border-indigo-700 mb-3">
            <p className="text-sm text-indigo-300">
              From library: <span className="font-semibold">{selectedAssetForForm.name}</span>
            </p>
            <p className="text-xs text-gray-400 truncate">Model: {currentModelUrl.split('/').pop()}</p>
          </div>
        )}

        <TextInput label="Name" id="charName" value={name} onChange={(e) => setName(e.target.value)} required />
        
        <div className={`grid ${!isLibraryAsset ? 'grid-cols-2 gap-x-3' : 'grid-cols-1'} gap-y-3`}>
            <div>
                <label htmlFor="charAgeBracket" className="block text-sm font-medium text-gray-300 mb-1">Age</label>
                <select 
                id="charAgeBracket" 
                value={ageBracket} 
                onChange={(e) => setAgeBracket(e.target.value)}
                className="block w-full bg-gray-700 border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                disabled={isLibraryAsset && !isEditing} 
                >
                {ageBrackets.map(bracket => <option key={bracket} value={bracket}>{bracket}</option>)}
                </select>
            </div>

            {!isLibraryAsset && (
                <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Color (Primitive)</label>
                    <div className="flex flex-wrap gap-1.5">
                        {availableColors.slice(0, 5).map(c => (
                        <button
                            key={c}
                            type="button"
                            onClick={() => setColor(c)}
                            className={`w-7 h-7 rounded-full border-2 ${color === c ? 'border-white ring-1 ring-indigo-500' : 'border-transparent hover:border-gray-400'}`}
                            style={{ backgroundColor: c }}
                            title={c}
                            aria-label={`Select color ${c}`}
                        />
                        ))}
                    </div>
                </div>
            )}
        </div>


        {!isLibraryAsset && ( 
          <>
            <div>
              <label htmlFor="charPose" className="block text-sm font-medium text-gray-300 mb-1">Pose</label>
              <select 
                id="charPose" 
                value={pose} 
                onChange={(e) => setPose(e.target.value)}
                className="block w-full bg-gray-700 border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              >
                {poseOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
              </select>
            </div>

            <div>
              <label htmlFor="charMovement" className="block text-sm font-medium text-gray-300 mb-1">Movement</label>
              <select 
                id="charMovement" 
                value={movement} 
                onChange={(e) => setMovement(e.target.value)}
                className="block w-full bg-gray-700 border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              >
                {movementOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
              </select>
            </div>
          </>
        )}

        {(isEditing || selectedAssetForForm) && currentFrame && (
          <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Initial Position (X, Y, Z)</label>
              <div className="grid grid-cols-3 gap-2">
                  <TextInput label="" id="charPosX" type="number" step="0.1" value={position.x} onChange={(e) => handlePositionChange('x', e.target.value)} />
                  <TextInput label="" id="charPosY" type="number" step="0.1" value={position.y} onChange={(e) => handlePositionChange('y', e.target.value)} />
                  <TextInput label="" id="charPosZ" type="number" step="0.1" value={position.z} onChange={(e) => handlePositionChange('z', e.target.value)} />
              </div>
              {currentFrame && (
                <div className="mt-3">
                  <MiniMap
                    items={mapItems}
                    bounds={{ minX: -25, maxX: 25, minZ: -25, maxZ: 25 }}
                    pendingX={parseFloat(position.x)}
                    pendingZ={parseFloat(position.z)}
                    onMapClick={handleMapClick}
                  />
                </div>
              )}
          </div>
        )}


        <div className="flex space-x-2 pt-2">
          <Button type="submit" variant="primary" className="flex-1">
            <PlusIcon className="w-4 h-4 mr-2" /> {isEditing ? 'Save Changes' : 'Add to Scene'}
          </Button>
          {(isEditing || selectedAssetForForm) && onCancel && (
            <Button type="button" variant="secondary" onClick={handleLocalCancel} className="flex-1">
              Cancel
            </Button>
          )}
        </div>
      </form>
    </Panel>
  );
};

export default CharacterForm;