
import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import { ASSET_LIBRARY } from '../../assetLibrary';
import { AssetLibraryItem } from '../../types';
import Panel from '../ui/Panel';
import Button from '../ui/Button';
import { 
  CubeIcon, 
  UserGroupIcon, 
  MagnifyingGlassIcon,
  FunnelIcon,
  ViewColumnsIcon,
  ListBulletIcon,
  StarIcon,
  TagIcon,
  ClockIcon, // Changed from ArrowPathIcon for "Recent"
  EyeIcon,
  HeartIcon,
  ArrowPathIcon // Retained for the loading spinner, or if another specific use case exists
} from '../../constants';

interface AssetLibraryPanelProps {
  onSelectAsset: (asset: AssetLibraryItem) => void;
  favorites?: string[];
  onToggleFavorite?: (assetId: string) => void;
  recentlyUsed?: string[];
  onAssetPreview?: (asset: AssetLibraryItem) => void;
}

type ViewMode = 'list' | 'grid' | 'compact';
type SortOption = 'name' | 'category' | 'type' | 'recent' | 'favorites';
type FilterType = 'all' | 'character' | 'object' | 'favorites' | 'recent';

const AssetLibraryPanel: React.FC<AssetLibraryPanelProps> = ({ 
  onSelectAsset,
  favorites = [],
  onToggleFavorite,
  recentlyUsed = [],
  onAssetPreview
}) => {
  const [filterType, setFilterType] = useState<FilterType>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [sortBy, setSortBy] = useState<SortOption>('name');
  const [isLoading, setIsLoading] = useState<boolean>(false); // For future async loading
  const [selectedAssets, setSelectedAssets] = useState<Set<string>>(new Set());
  const [showFilters, setShowFilters] = useState<boolean>(false);
  
  const searchInputRef = useRef<HTMLInputElement>(null);
  const virtualListRef = useRef<HTMLDivElement>(null); // For future virtualization

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key.toLowerCase()) { // Use toLowerCase for consistency
          case 'f':
            e.preventDefault();
            searchInputRef.current?.focus();
            break;
          case '1':
            e.preventDefault();
            setViewMode('list');
            break;
          case '2':
            e.preventDefault();
            setViewMode('grid');
            break;
          case '3':
            e.preventDefault();
            setViewMode('compact');
            break;
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Enhanced categories with metadata
  const categories = useMemo(() => {
    const catMap = new Map<string, { count: number; types: Set<string> }>();
    
    ASSET_LIBRARY.forEach(asset => {
      if (asset.category) {
        const existing = catMap.get(asset.category) || { count: 0, types: new Set() };
        existing.count++;
        existing.types.add(asset.type);
        catMap.set(asset.category, existing);
      }
    });
    
    return [
      { name: 'all', count: ASSET_LIBRARY.length, types: new Set(['character', 'object']) },
      ...Array.from(catMap.entries())
        .map(([name, data]) => ({ name, ...data }))
        .sort((a, b) => a.name.localeCompare(b.name))
    ];
  }, []);

  // Advanced filtering and sorting
  const processedAssets = useMemo(() => {
    // Simulate loading for demo
    // setIsLoading(true);
    // setTimeout(() => setIsLoading(false), 500);


    let filtered = ASSET_LIBRARY.filter(asset => {
      // Type filtering
      const typeMatch = (() => {
        switch (filterType) {
          case 'all': return true;
          case 'favorites': return favorites.includes(asset.id);
          case 'recent': return recentlyUsed.includes(asset.id);
          default: return asset.type === filterType;
        }
      })();

      // Category filtering
      const categoryMatch = filterCategory === 'all' || asset.category === filterCategory;
      
      // Search filtering
      const lowerSearchTerm = searchTerm.toLowerCase();
      const searchMatch = searchTerm === '' || 
        asset.name.toLowerCase().includes(lowerSearchTerm) ||
        (asset.description && asset.description.toLowerCase().includes(lowerSearchTerm)) ||
        (asset.category && asset.category.toLowerCase().includes(lowerSearchTerm)) ||
        (asset.tags && asset.tags.some(tag => tag.toLowerCase().includes(lowerSearchTerm)));


      return typeMatch && categoryMatch && searchMatch;
    });

    // Sorting
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'category':
          return (a.category || '').localeCompare(b.category || '');
        case 'type':
          return a.type.localeCompare(b.type);
        case 'recent':
          const aRecentIndex = recentlyUsed.indexOf(a.id);
          const bRecentIndex = recentlyUsed.indexOf(b.id);
          if (aRecentIndex === -1 && bRecentIndex === -1) return a.name.localeCompare(b.name); // Both not recent, sort by name
          if (aRecentIndex === -1) return 1;  // a is not recent, b is -> b comes first
          if (bRecentIndex === -1) return -1; // b is not recent, a is -> a comes first
          return aRecentIndex - bRecentIndex; // Both recent, sort by index (lower index is more recent)
        case 'favorites':
          const aFav = favorites.includes(a.id);
          const bFav = favorites.includes(b.id);
          if (aFav === bFav) return a.name.localeCompare(b.name); // Both fav or not fav, sort by name
          return bFav ? 1 : -1; // If b is fav, it comes first
        default:
          return 0;
      }
    });

    return filtered;
  }, [filterType, filterCategory, searchTerm, sortBy, favorites, recentlyUsed]);

  // Asset selection handlers
  const handleAssetClick = useCallback((asset: AssetLibraryItem, e: React.MouseEvent) => {
    if (e.ctrlKey || e.metaKey) {
      // Multi-select
      const newSelected = new Set(selectedAssets);
      if (newSelected.has(asset.id)) {
        newSelected.delete(asset.id);
      } else {
        newSelected.add(asset.id);
      }
      setSelectedAssets(newSelected);
    } else {
      // Single select: clear previous multi-selection and select current
      setSelectedAssets(new Set([asset.id])); 
      onSelectAsset(asset); // Original behavior for single select
    }
  }, [selectedAssets, onSelectAsset]);

  const handlePreview = useCallback((asset: AssetLibraryItem, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering asset selection
    onAssetPreview?.(asset);
  }, [onAssetPreview]);

  const handleToggleFavorite = useCallback((assetId: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering asset selection
    onToggleFavorite?.(assetId);
  }, [onToggleFavorite]);

  // Clear filters
  const clearFilters = useCallback(() => {
    setFilterType('all');
    setFilterCategory('all');
    setSearchTerm('');
    // setSelectedAssets(new Set()); // Optionally clear selection when filters are cleared
  }, []);

  // Render asset item based on view mode
  const renderAssetItem = useCallback((asset: AssetLibraryItem) => {
    const isSelected = selectedAssets.has(asset.id);
    const isFavorite = favorites.includes(asset.id);
    const isRecent = recentlyUsed.includes(asset.id);

    const baseClasses = `
      relative transition-all duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-offset-gray-700 focus:ring-indigo-500 
      ${isSelected ? 'ring-2 ring-indigo-400 bg-indigo-900/30' : 'hover:bg-gray-600/70'}
    `;

    if (viewMode === 'grid') {
      return (
        <div
          key={asset.id}
          className={`${baseClasses} bg-gray-700 border border-gray-600 rounded-lg p-2.5 flex flex-col items-center text-center group cursor-pointer`}
          onClick={(e) => handleAssetClick(asset, e)}
          tabIndex={0}
          role="button"
          aria-label={`Select ${asset.name}`}
          aria-pressed={isSelected}
        >
          <div className="relative w-full aspect-square mb-2"> {/* Ensures square thumbnails */}
            {asset.thumbnailUrl ? (
              <img 
                src={asset.thumbnailUrl} 
                alt={asset.name} 
                className="w-full h-full object-cover rounded-md border border-gray-500" 
                loading="lazy"
              />
            ) : (
              <div className="w-full h-full bg-gray-600 rounded-md flex items-center justify-center border border-gray-500">
                {asset.type === 'character' ? 
                  <UserGroupIcon className="w-8 h-8 text-indigo-300" /> : 
                  <CubeIcon className="w-8 h-8 text-teal-300" />
                }
              </div>
            )}
            
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-md flex items-center justify-center space-x-1.5 p-1">
              {onAssetPreview && (
                <button
                  onClick={(e) => handlePreview(asset, e)}
                  className="p-1.5 bg-white/20 rounded-full hover:bg-white/30 transition-colors"
                  title="Preview Asset"
                  aria-label="Preview asset"
                >
                  <EyeIcon className="w-3.5 h-3.5 text-white" />
                </button>
              )}
              {onToggleFavorite && (
                <button
                  onClick={(e) => handleToggleFavorite(asset.id, e)}
                  className="p-1.5 bg-white/20 rounded-full hover:bg-white/30 transition-colors"
                  title={isFavorite ? "Remove from favorites" : "Add to favorites"}
                  aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
                >
                  <HeartIcon className={`w-3.5 h-3.5 ${isFavorite ? 'text-red-400 fill-current' : 'text-white'}`} />
                </button>
              )}
            </div>

            <div className="absolute top-1.5 right-1.5 flex flex-col space-y-1">
              {/* Fix: Removed invalid 'title' prop from SVG icon components */}
              {isFavorite && <StarIcon className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />}
              {/* Fix: Removed invalid 'title' prop from SVG icon components */}
              {isRecent && <ClockIcon className="w-3.5 h-3.5 text-sky-400" />}
            </div>
          </div>

          <p className="text-xs font-semibold text-gray-200 truncate w-full mt-1">{asset.name}</p>
          <p className="text-xxs text-gray-400 truncate w-full">{asset.category || asset.type}</p>
          
          {asset.tags && asset.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5 justify-center">
              {asset.tags.slice(0, 2).map(tag => (
                <span key={tag} className="text-xxs bg-gray-600 text-gray-300 px-1.5 py-0.5 rounded-sm">
                  {tag}
                </span>
              ))}
              {asset.tags.length > 2 && (
                <span className="text-xxs text-gray-400" title={asset.tags.slice(2).join(', ')}>+{asset.tags.length - 2}</span>
              )}
            </div>
          )}
        </div>
      );
    }

    if (viewMode === 'compact') {
      return (
        <div
          key={asset.id}
          className={`${baseClasses} bg-gray-700 border-l-2 ${isSelected ? 'border-l-indigo-500' : 'border-l-transparent'} hover:border-l-indigo-400 p-2 flex items-center space-x-2 cursor-pointer`}
          onClick={(e) => handleAssetClick(asset, e)}
          tabIndex={0}
          role="button"
          aria-pressed={isSelected}
        >
          {asset.type === 'character' ? 
            <UserGroupIcon className="w-4 h-4 flex-shrink-0 text-indigo-400" /> : 
            <CubeIcon className="w-4 h-4 flex-shrink-0 text-teal-400" />
          }
          <span className="text-sm text-gray-200 truncate flex-1">{asset.name}</span>
          <div className="flex items-center space-x-1.5">
            {/* Fix: Removed invalid 'title' prop from SVG icon components */}
            {isFavorite && <StarIcon className="w-3.5 h-3.5 text-yellow-400 fill-current" />}
            {/* Fix: Removed invalid 'title' prop from SVG icon components */}
            {isRecent && <ClockIcon className="w-3.5 h-3.5 text-sky-400" />}
            {onToggleFavorite && (
               <button
                  onClick={(e) => handleToggleFavorite(asset.id, e)}
                  className="p-0.5 rounded-full hover:bg-gray-600 transition-colors opacity-50 hover:opacity-100"
                  title={isFavorite ? "Unfavorite" : "Favorite"}
                >
                  <HeartIcon className={`w-3 h-3 ${isFavorite ? 'text-red-400 fill-current' : 'text-gray-400'}`} />
                </button>
            )}
          </div>
        </div>
      );
    }

    // List view (default)
    return (
      <div
        key={asset.id}
        className={`${baseClasses} bg-gray-700 border border-transparent hover:border-gray-500/50 rounded-md p-2.5 flex items-start space-x-3 cursor-pointer`}
        onClick={(e) => handleAssetClick(asset, e)}
        tabIndex={0}
        role="button"
        aria-pressed={isSelected}
      >
        <div className="flex-shrink-0">
          {asset.thumbnailUrl ? (
            <img 
              src={asset.thumbnailUrl} 
              alt={asset.name} 
              className="w-12 h-12 object-cover rounded border border-gray-500" 
              loading="lazy"
            />
          ) : (
            <div className="w-12 h-12 bg-gray-600 rounded flex items-center justify-center border border-gray-500">
              {asset.type === 'character' ? 
                <UserGroupIcon className="w-6 h-6 text-indigo-300" /> : 
                <CubeIcon className="w-6 h-6 text-teal-300" />
              }
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-gray-100 truncate">{asset.name}</p>
              <p className="text-xs text-gray-400">{asset.category || asset.type}</p>
            </div>
            <div className="flex items-center space-x-1.5 ml-2 flex-shrink-0">
              {/* Fix: Removed invalid 'title' prop from SVG icon components */}
              {isFavorite && <StarIcon className="w-3.5 h-3.5 text-yellow-400 fill-current" />}
              {/* Fix: Removed invalid 'title' prop from SVG icon components */}
              {isRecent && <ClockIcon className="w-3.5 h-3.5 text-sky-400" />}
              {onToggleFavorite && (
                 <button
                  onClick={(e) => handleToggleFavorite(asset.id, e)}
                  className="p-1 rounded-full hover:bg-gray-600 transition-colors opacity-50 hover:opacity-100"
                  title={isFavorite ? "Unfavorite" : "Favorite"}
                >
                  <HeartIcon className={`w-4 h-4 ${isFavorite ? 'text-red-400 fill-current' : 'text-gray-400'}`} />
                </button>
              )}
            </div>
          </div>
          
          {asset.description && (
            <p className="text-xs text-gray-400 mt-1 line-clamp-2">{asset.description}</p>
          )}
          
          {asset.tags && asset.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5">
              {asset.tags.map(tag => (
                <span key={tag} className="text-xxs bg-gray-600 text-gray-300 px-1.5 py-0.5 rounded-sm">
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }, [viewMode, selectedAssets, favorites, recentlyUsed, handleAssetClick, handlePreview, handleToggleFavorite, onAssetPreview, onToggleFavorite]);

  return (
    <Panel title="Asset Library" className="flex flex-col h-full bg-gray-800">
      <div className="p-3 border-b border-gray-700 space-y-2.5">
        <div className="flex items-center space-x-2">
          <div className="flex-1 relative">
            <MagnifyingGlassIcon className="absolute left-2.5 top-1/2 transform -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" />
            <input
              ref={searchInputRef}
              type="text"
              placeholder="Search (Ctrl+F)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-gray-700 border-gray-600 text-gray-200 rounded-md py-1.5 pl-8 pr-2.5 text-sm focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
          
          <Button
            onClick={() => setShowFilters(!showFilters)}
            variant="secondary"
            size="sm"
            className={`p-1.5 ${showFilters ? 'bg-indigo-600 text-white' : 'bg-gray-600'}`}
            title={showFilters ? "Hide Filters" : "Show Filters"}
            aria-pressed={showFilters}
          >
            <FunnelIcon className="w-4 h-4" />
          </Button>

          <div className="flex bg-gray-600 rounded-md p-0.5">
            {[
              { mode: 'list' as ViewMode, icon: ListBulletIcon, title: 'List view (Ctrl+1)' },
              { mode: 'grid' as ViewMode, icon: ViewColumnsIcon, title: 'Grid view (Ctrl+2)' },
              { mode: 'compact' as ViewMode, icon: CubeIcon, title: 'Compact view (Ctrl+3)' } 
            ].map(({ mode, icon: Icon, title }) => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={`p-1 rounded-sm transition-colors ${
                  viewMode === mode ? 'bg-indigo-600 text-white' : 'text-gray-300 hover:text-white hover:bg-gray-500'
                }`}
                title={title}
                aria-pressed={viewMode === mode}
              >
                <Icon className="w-4 h-4" />
              </button>
            ))}
          </div>
        </div>

        {showFilters && (
          <div className="space-y-2 p-2.5 bg-gray-900/30 rounded-md mt-1.5 border border-gray-700/50">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-medium text-gray-400 block mb-0.5">Type</label>
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value as FilterType)}
                  className="w-full bg-gray-700 border-gray-600 text-gray-200 rounded-md py-1 px-2 text-xs focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                >
                  <option value="all">All Types</option>
                  <option value="character">Characters</option>
                  <option value="object">Objects</option>
                  <option value="favorites">Favorites ({favorites.length})</option>
                  <option value="recent">Recent ({recentlyUsed.length})</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-gray-400 block mb-0.5">Category</label>
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="w-full bg-gray-700 border-gray-600 text-gray-200 rounded-md py-1 px-2 text-xs focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                >
                  {categories.map(cat => (
                    <option key={cat.name} value={cat.name}>
                      {cat.name === 'all' ? `All Categories (${cat.count})` : `${cat.name} (${cat.count})`}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <div>
                <label className="text-xs font-medium text-gray-400 block mb-0.5">Sort by</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortOption)}
                  className="bg-gray-700 border-gray-600 text-gray-200 rounded-md py-1 px-2 text-xs focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                >
                  <option value="name">Name</option>
                  <option value="category">Category</option>
                  <option value="type">Type</option>
                  <option value="recent">Recent</option>
                  <option value="favorites">Favorites</option>
                </select>
              </div>
              
              <Button
                onClick={clearFilters}
                variant="secondary"
                size="sm"
                className="text-xs px-2.5 py-1"
              >
                Clear Filters
              </Button>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between text-xs text-gray-400 pt-1">
          <span>Showing: {processedAssets.length} asset(s)</span>
          {selectedAssets.size > 0 && (
            <span>{selectedAssets.size} selected</span>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 custom-scrollbar" ref={virtualListRef}>
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500">
            <ArrowPathIcon className="w-8 h-8 animate-spin text-indigo-400 mb-2" />
            <p>Loading assets...</p>
          </div>
        ) : processedAssets.length > 0 ? (
          <div className={`
            ${viewMode === 'grid' ? 'grid grid-cols-2 sm:grid-cols-3 gap-2.5' : 
              viewMode === 'compact' ? 'space-y-1' : 'space-y-1.5'}
          `}>
            {processedAssets.map((asset) => renderAssetItem(asset))}
          </div>
        ) : (
          <div className="text-center text-gray-500 py-10 flex flex-col items-center">
            <CubeIcon className="w-12 h-12 mb-3 text-gray-600" />
            <p className="text-sm mb-2">No assets match your filters.</p>
            <Button
              onClick={clearFilters}
              variant="primary"
              size="sm"
              className="text-xs"
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>

      {selectedAssets.size > 0 && (
        <div className="border-t border-gray-700 p-2.5 bg-gray-850">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-300">
              {selectedAssets.size} asset{selectedAssets.size > 1 ? 's' : ''} selected
            </span>
            <div className="flex space-x-2">
              <Button
                onClick={() => {
                  selectedAssets.forEach(id => {
                    const asset = ASSET_LIBRARY.find(a => a.id === id);
                    if (asset) onSelectAsset(asset); // This will trigger the `onAssetUsed` in ElementsPanel
                  });
                  setSelectedAssets(new Set());
                }}
                variant="primary"
                size="sm"
                className="text-xs px-3 py-1"
              >
                Add to Scene
              </Button>
              <Button
                onClick={() => setSelectedAssets(new Set())}
                variant="secondary"
                size="sm"
                className="text-xs px-3 py-1"
              >
                Clear Selection
              </Button>
            </div>
          </div>
        </div>
      )}
    </Panel>
  );
};

export default AssetLibraryPanel;
{/* Fix: Removed extraneous text from the end of the file. */}
