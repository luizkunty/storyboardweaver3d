
import React from 'react';

interface PanelProps {
  title: string;
  children: React.ReactNode;
  className?: string;
}

const Panel: React.FC<PanelProps> = ({ title, children, className = '' }) => {
  return (
    <div className={`bg-gray-800 text-gray-100 rounded-lg ${className}`}>
      <h3 className="text-lg font-semibold text-indigo-400 p-4 border-b border-gray-700">{title}</h3>
      <div className="p-4 space-y-4">
        {children}
      </div>
    </div>
  );
};

export default Panel;
