
import React, { useRef, useEffect, useMemo } from 'react';
import * as THREE from 'three';
import { CameraConfig } from '../../types'; // Assuming types.ts is in the parent of parent directory

const SCALE_FACTOR = 0.15; // Adjust to fit main scene coords into indicator plane
const INDICATOR_PLANE_SIZE = 10; // Visual size of the reference plane in the indicator

interface CameraPositionIndicatorProps {
  cameraConfig?: CameraConfig; // Make optional for when no frame is active
}

const CameraPositionIndicator: React.FC<CameraPositionIndicatorProps> = ({ cameraConfig }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const indicatorSceneCameraRef = useRef<THREE.PerspectiveCamera | null>(null); // Changed to PerspectiveCamera
  const indicatorCameraMeshRef = useRef<THREE.Mesh | null>(null); // Cone representing the main camera
  const referencePlaneRef = useRef<THREE.Mesh | null>(null);
  const animationFrameIdRef = useRef<number | null>(null);

  const gridTexture = useMemo(() => {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    const canvasSize = 128; // Texture resolution
    canvas.width = canvasSize;
    canvas.height = canvasSize;

    if (context) {
      context.fillStyle = '#4A5568'; // gray-600
      context.fillRect(0, 0, canvasSize, canvasSize);
      context.strokeStyle = '#A0AEC0'; // gray-400
      context.lineWidth = 1;
      const divisions = 8;
      for (let i = 0; i <= divisions; i++) {
        const pos = (i / divisions) * canvasSize;
        // Thin lines
        context.globalAlpha = 0.5;
        context.beginPath();
        context.moveTo(pos, 0);
        context.lineTo(pos, canvasSize);
        context.stroke();
        context.beginPath();
        context.moveTo(0, pos);
        context.lineTo(canvasSize, pos);
        context.stroke();
        // Thick center lines
        if (i === divisions / 2) {
            context.globalAlpha = 1.0;
            context.lineWidth = 2;
            context.beginPath();
            context.moveTo(pos, 0);
            context.lineTo(pos, canvasSize);
            context.stroke();
            context.beginPath();
            context.moveTo(0, pos);
            context.lineTo(canvasSize, pos);
            context.stroke();
            context.lineWidth = 1; // Reset for other lines
        }
      }
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(2,2); // Tile the texture
    return texture;
  }, []);

  useEffect(() => {
    if (!mountRef.current) return;
    const mountElement = mountRef.current;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Indicator's own camera (Perspective View)
    const aspect = mountElement.clientWidth / mountElement.clientHeight;
    const indicatorSceneCamera = new THREE.PerspectiveCamera(
      35, // FOV
      aspect, // Aspect Ratio
      0.1, // Near plane
      1000 // Far plane
    );
    // Position for a 3/4 side view, slightly elevated
    indicatorSceneCamera.position.set(
      INDICATOR_PLANE_SIZE * 0.7, // Sideways
      INDICATOR_PLANE_SIZE * 0.5, // Upwards
      INDICATOR_PLANE_SIZE * 1.3  // Backwards (closer than original ortho for perspective)
    );
    indicatorSceneCamera.lookAt(0, 0, 0); // Look at the center of the plane
    indicatorSceneCameraRef.current = indicatorSceneCamera;


    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(mountElement.clientWidth, mountElement.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    mountElement.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8); // Slightly brighter ambient
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1.0); // Slightly brighter directional
    directionalLight.position.set(8, 12, 10); // Adjusted light position for better perspective illumination
    scene.add(directionalLight);

    // Reference Plane (XZ plane)
    const planeGeometry = new THREE.PlaneGeometry(INDICATOR_PLANE_SIZE, INDICATOR_PLANE_SIZE);
    const planeMaterial = new THREE.MeshStandardMaterial({
      map: gridTexture,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.8,
      roughness: 0.7,
      metalness: 0.1,
    });
    const referencePlane = new THREE.Mesh(planeGeometry, planeMaterial);
    referencePlane.rotation.x = -Math.PI / 2; // Orient to be flat on XZ
    scene.add(referencePlane);
    referencePlaneRef.current = referencePlane;

    // Indicator Camera Mesh (Cone)
    const coneRadius = INDICATOR_PLANE_SIZE * 0.05; // Slightly larger radius
    const coneHeight = INDICATOR_PLANE_SIZE * 0.15; // Slightly taller cone
    const coneGeometry = new THREE.ConeGeometry(coneRadius, coneHeight, 16);
    // Translate geometry so the cone's tip is at its local origin (0,0,0) and it points along its local +Z axis
    coneGeometry.translate(0, -coneHeight / 2, 0); // Center base at origin
    coneGeometry.rotateX(Math.PI / 2); // Rotate to point along local +Z
    
    const coneMaterial = new THREE.MeshStandardMaterial({ color: 0x3b82f6, emissive: 0x2563eb, roughness: 0.4, metalness: 0.2 }); // Adjusted colors
    const indicatorCameraMesh = new THREE.Mesh(coneGeometry, coneMaterial);
    scene.add(indicatorCameraMesh);
    indicatorCameraMeshRef.current = indicatorCameraMesh;
    
    // Initial visibility based on cameraConfig
    if (indicatorCameraMeshRef.current) {
        indicatorCameraMeshRef.current.visible = !!cameraConfig;
    }
    if(referencePlaneRef.current) {
        referencePlaneRef.current.visible = !!cameraConfig; // Also hide plane if no camera
    }


    // Animation loop
    const animate = () => {
      animationFrameIdRef.current = requestAnimationFrame(animate);
      if (rendererRef.current && sceneRef.current && indicatorSceneCameraRef.current) {
        rendererRef.current.render(sceneRef.current, indicatorSceneCameraRef.current);
      }
    };
    animate();

    // Resize handler
    const handleResize = () => {
      if (mountElement && rendererRef.current && indicatorSceneCameraRef.current) {
        const cam = indicatorSceneCameraRef.current as THREE.PerspectiveCamera; // Cast to PerspectiveCamera
        cam.aspect = mountElement.clientWidth / mountElement.clientHeight;
        cam.updateProjectionMatrix();
        rendererRef.current.setSize(mountElement.clientWidth, mountElement.clientHeight);
      }
    };
    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(mountElement);


    return () => {
      if (animationFrameIdRef.current) cancelAnimationFrame(animationFrameIdRef.current);
      resizeObserver.disconnect();
      mountElement.removeChild(renderer.domElement);
      renderer.dispose();
      coneGeometry.dispose();
      coneMaterial.dispose();
      planeGeometry.dispose();
      planeMaterial.dispose();
      gridTexture.dispose();
      sceneRef.current?.clear();
    };
  }, [gridTexture, cameraConfig]); // Added cameraConfig to dependencies to re-evaluate visibility on initial load

  // Update indicator mesh based on cameraConfig prop
  useEffect(() => {
    if (indicatorCameraMeshRef.current && referencePlaneRef.current) {
      if (cameraConfig) {
        indicatorCameraMeshRef.current.visible = true;
        referencePlaneRef.current.visible = true;

        // Update position (scaled)
        indicatorCameraMeshRef.current.position.set(
          cameraConfig.position.x * SCALE_FACTOR,
          cameraConfig.position.y * SCALE_FACTOR, // Y position will determine height above indicator plane
          cameraConfig.position.z * SCALE_FACTOR
        );

        // Update rotation
        const euler = new THREE.Euler(
          THREE.MathUtils.degToRad(cameraConfig.rotation.x),
          THREE.MathUtils.degToRad(cameraConfig.rotation.y),
          THREE.MathUtils.degToRad(cameraConfig.rotation.z),
          'YXZ' // Order to match main camera's likely interpretation
        );
        indicatorCameraMeshRef.current.quaternion.setFromEuler(euler);
      } else {
        indicatorCameraMeshRef.current.visible = false;
        referencePlaneRef.current.visible = false;
      }
    }
  }, [cameraConfig]);

  return (
    <div
      ref={mountRef}
      className="absolute top-4 right-4 w-28 h-28 md:w-32 md:h-32 bg-gray-800 bg-opacity-70 border border-gray-600 rounded-md shadow-lg overflow-hidden"
      aria-label="Camera position indicator"
    ></div>
  );
};

export default CameraPositionIndicator;
