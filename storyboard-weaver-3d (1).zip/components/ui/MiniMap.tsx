
import React from 'react';

interface MapItem {
  id: string;
  x: number;
  z: number;
  type: 'character' | 'object' | 'light';
  name: string;
}

interface SceneBounds {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

interface MiniMapProps {
  items: MapItem[];
  bounds: SceneBounds;
  pendingX?: number;
  pendingZ?: number;
  onMapClick: (x: number, z: number) => void;
  mapPixelDimensions?: { width: number; height: number };
  lightSourcePosition?: { x: number; z: number }; // For showing light's own position when targeting
  drawDirectionLine?: boolean; // To draw a line from light source to target
}

const MiniMap: React.FC<MiniMapProps> = ({
  items,
  bounds,
  pendingX,
  pendingZ,
  onMapClick,
  mapPixelDimensions = { width: 200, height: 200 },
  lightSourcePosition,
  drawDirectionLine,
}) => {
  const { width: mapWidth, height: mapHeight } = mapPixelDimensions;
  const { minX, maxX, minZ, maxZ } = bounds;

  const sceneWidth = maxX - minX;
  const sceneDepth = maxZ - minZ;

  const toSvgX = (sceneX: number): number => {
    return ((sceneX - minX) / sceneWidth) * mapWidth;
  };

  const toSvgY = (sceneZ: number): number => {
    return ((sceneZ - minZ) / sceneDepth) * mapHeight;
  };
  
  const toSceneCoords = (svgX: number, svgY: number): { x: number; z: number } => {
    const sceneX = (svgX / mapWidth) * sceneWidth + minX;
    const sceneZ = (svgY / mapHeight) * sceneDepth + minZ;
    return { x: sceneX, z: sceneZ };
  };

  const handleSvgClick = (event: React.MouseEvent<SVGSVGElement>) => {
    const svgRect = event.currentTarget.getBoundingClientRect();
    const svgX = event.clientX - svgRect.left;
    const svgY = event.clientY - svgRect.top;
    const { x, z } = toSceneCoords(svgX, svgY);
    onMapClick(x, z);
  };

  const getItemColor = (type: MapItem['type']): string => {
    switch (type) {
      case 'character': return '#60A5FA'; // blue-400
      case 'object': return '#34D399';    // emerald-400
      case 'light': return '#FBBF24';     // amber-400
      default: return '#9CA3AF';         // gray-400
    }
  };
  
  const lightSourceColor = '#F472B6'; // pink-400

  const gridLines = [];
  const numGridLines = 10;
  for (let i = 0; i <= numGridLines; i++) {
    const sceneX = minX + (sceneWidth / numGridLines) * i;
    const x1 = toSvgX(sceneX);
    gridLines.push(<line key={`vline-${i}`} x1={x1} y1="0" x2={x1} y2={mapHeight} stroke="#4A5568" strokeWidth="0.5" />);
    const sceneZ = minZ + (sceneDepth / numGridLines) * i;
    const y1 = toSvgY(sceneZ);
    gridLines.push(<line key={`hline-${i}`} x1="0" y1={y1} x2={mapWidth} y2={y1} stroke="#4A5568" strokeWidth="0.5" />);
  }
  const centerXSvg = toSvgX(0);
  const centerZSvg = toSvgY(0);
  gridLines.push(<line key="center-vline" x1={centerXSvg} y1="0" x2={centerXSvg} y2={mapHeight} stroke="#6B7280" strokeWidth="0.7" />);
  gridLines.push(<line key="center-hline" x1="0" y1={centerZSvg} x2={mapWidth} y2={centerZSvg} stroke="#6B7280" strokeWidth="0.7" />);

  return (
    <div className="bg-gray-700 p-1 rounded-md border border-gray-600 select-none">
      <svg
        width={mapWidth}
        height={mapHeight}
        viewBox={`0 0 ${mapWidth} ${mapHeight}`}
        onClick={handleSvgClick}
        className="cursor-pointer bg-gray-800 rounded"
      >
        <rect width={mapWidth} height={mapHeight} fill="#374151" /> {/* gray-700 */}
        {gridLines}

        {items.map(item => (
          <circle
            key={item.id}
            cx={toSvgX(item.x)}
            cy={toSvgY(item.z)}
            r="3"
            fill={getItemColor(item.type)}
            stroke="#FFFFFF"
            strokeWidth="0.5"
          >
            <title>{`${item.name} (${item.type}) X:${item.x.toFixed(1)}, Z:${item.z.toFixed(1)}`}</title>
          </circle>
        ))}

        {/* Light Source Position Marker (if editing target) */}
        {lightSourcePosition && (
            <rect 
                x={toSvgX(lightSourcePosition.x) - 2.5} 
                y={toSvgY(lightSourcePosition.z) - 2.5} 
                width="5" 
                height="5" 
                fill={lightSourceColor}
                stroke="#FFFFFF"
                strokeWidth="0.5"
            >
                 <title>{`Light Source X:${lightSourcePosition.x.toFixed(1)}, Z:${lightSourcePosition.z.toFixed(1)}`}</title>
            </rect>
        )}
        
        {/* Direction Line (if editing target) */}
        {drawDirectionLine && lightSourcePosition && pendingX !== undefined && pendingZ !== undefined && (
            <line
                x1={toSvgX(lightSourcePosition.x)}
                y1={toSvgY(lightSourcePosition.z)}
                x2={toSvgX(pendingX)}
                y2={toSvgY(pendingZ)}
                stroke={lightSourceColor}
                strokeWidth="1"
                strokeDasharray="2 2"
            />
        )}

        {/* Pending Placement / Target Marker (Crosshair) */}
        {pendingX !== undefined && pendingZ !== undefined && (
          <>
            <line
              x1={toSvgX(pendingX) - 5} y1={toSvgY(pendingZ)}
              x2={toSvgX(pendingX) + 5} y2={toSvgY(pendingZ)}
              stroke="#FCD34D" strokeWidth="1.5" // amber-300
            />
            <line
              x1={toSvgX(pendingX)} y1={toSvgY(pendingZ) - 5}
              x2={toSvgX(pendingX)} y2={toSvgY(pendingZ) + 5}
              stroke="#FCD34D" strokeWidth="1.5" // amber-300
            />
            <circle 
                cx={toSvgX(pendingX)} 
                cy={toSvgY(pendingZ)} 
                r="2" 
                fill="none" 
                stroke="#FCD34D" // amber-300
                strokeWidth="1" 
            />
          </>
        )}
      </svg>
       <p className="text-xs text-center text-gray-400 mt-1">Click on map to set X, Z. Bounds: X/Z from {minX} to {maxX}.</p>
    </div>
  );
};

export default MiniMap;