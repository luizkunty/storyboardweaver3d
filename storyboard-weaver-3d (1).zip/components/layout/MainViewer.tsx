
import React, { useRef, useEffect, useCallback, MutableRefObject, useMemo } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { Frame, CameraConfig, StoryObject, StoryCharacter, LightConfig } from '../../types';
import { CubeIcon, PlusIcon } from '../../constants';
import CameraPositionIndicator from '../ui/CameraPositionIndicator.tsx';
import { CameraSyncManager } from '../../utils/cameraSyncManager';

interface MainViewerProps {
  frame?: Frame;
  isExporting?: boolean;
  onUpdateCamera: (cameraConfig: CameraConfig) => void;
  isTimelineSidebarOpen?: boolean;
  appRendererRef: MutableRefObject<THREE.WebGLRenderer | null>;
  onAddFrame: () => void;
  isCameraDampingEnabled?: boolean;
  showGrid?: boolean; // New prop
  showGroundPlane?: boolean; // New prop
  showOrientationGizmo?: boolean; // New prop
}

interface CreateTextSpriteParams {
  fontface?: string;
  fontsize?: number;
  textColor?: { r: number; g: number; b: number; a: number };
}

const EULER_ORDER: THREE.EulerOrder = 'YXZ';
const DEFAULT_TARGET_DISTANCE = 10;
const ORBIT_CONTROLS_TIME_THROTTLE_MS = 16; // Approx 60 FPS for primary throttle
const WHEEL_ZOOM_TIME_THROTTLE_MS = 50; // Approx 20 FPS for zoom events

type CameraSyncStateType = 'idle' | 'updating-from-ui' | 'updating-from-orbit';

function createTextSprite(message: string, parameters: CreateTextSpriteParams = {}) {
  const { fontface = 'Arial', fontsize = 48, textColor = { r:255, g:255, b:255, a:1.0 } } = parameters;
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  if (!context) return new THREE.Sprite();
  context.font = `Bold ${fontsize}px ${fontface}`;
  const metrics = context.measureText(message);
  const textWidth = metrics.width;
  canvas.width = textWidth > 0 ? textWidth : 1;
  canvas.height = fontsize * 1.2 > 0 ? fontsize * 1.2 : 1;
  context.font = `Bold ${fontsize}px ${fontface}`;
  context.textAlign = 'center';
  context.textBaseline = 'middle';
  context.fillStyle = `rgba(${textColor.r}, ${textColor.g}, ${textColor.b}, ${textColor.a})`;
  context.fillText(message, canvas.width / 2, canvas.height / 2);
  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  const spriteMaterial = new THREE.SpriteMaterial({ map: texture, depthTest: false, depthWrite: false, transparent: true });
  const sprite = new THREE.Sprite(spriteMaterial);
  return sprite;
}

const MainViewer: React.FC<MainViewerProps> = ({
    frame,
    isExporting = false,
    onUpdateCamera,
    isTimelineSidebarOpen,
    appRendererRef,
    onAddFrame,
    isCameraDampingEnabled = false,
    showGrid = true, // Default to true
    showGroundPlane = true, // Default to true
    showOrientationGizmo = true, // Default to true
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const animationFrameIdRef = useRef<number | null>(null);
  
  const syncManager = CameraSyncManager.getInstance();

  const characterMeshesRef = useRef<Map<string, THREE.Object3D>>(new Map());
  const objectMeshesRef = useRef<Map<string, THREE.Object3D>>(new Map());
  const lightMeshesRef = useRef<Map<string, THREE.Light>>(new Map());
  const gltfLoaderRef = useRef<GLTFLoader | null>(null);
  const modelCacheRef = useRef<Map<string, THREE.Group>>(new Map());
  const geometryPoolRef = useRef<Map<string, THREE.BufferGeometry>>(new Map());
  const materialPoolRef = useRef<Map<string, THREE.Material>>(new Map());

  const gizmoSceneRef = useRef<THREE.Scene | null>(null);
  const gizmoCameraRef = useRef<THREE.OrthographicCamera | null>(null);
  const gizmoSize = 70;

  const gridHelperRef = useRef<THREE.GridHelper | null>(null);
  const groundPlaneRef = useRef<THREE.Mesh | null>(null);
  const prevGroundStateRef = useRef<{transparent: boolean, opacity: number} | null>(null);

  const isUpdatingFromPropsRef = useRef(false);
  const lastAppliedUpdateIdRef = useRef<string | null>(null);
  
  const lastOrbitUpdateTimeRef = useRef<number>(0);
  const throttledOrbitUpdateRafRef = useRef<number | null>(null); 
  const lastWheelUpdateTimeRef = useRef<number>(0);

  const cameraSyncStateRef = useRef<CameraSyncStateType>('idle');


  const onUpdateCameraRef = useRef(onUpdateCamera);
  useEffect(() => { onUpdateCameraRef.current = onUpdateCamera; }, [onUpdateCamera]);

  const prevFrameElementsRef = useRef<{
    lights?: LightConfig[];
    characters?: StoryCharacter[];
    objects?: StoryObject[];
    backgroundColor?: string;
  }>({});

  const setUpdatingFlag = useCallback(() => {
    isUpdatingFromPropsRef.current = true;
    requestAnimationFrame(() => { 
      requestAnimationFrame(() => { 
        isUpdatingFromPropsRef.current = false;
      });
    });
  }, []);

  const disposeObject3D = (obj: THREE.Object3D) => {
      obj.traverse(child => {
          if (child instanceof THREE.Mesh) {
              const isGltfPart = !(child.geometry && geometryPoolRef.current.has((child.geometry as any)._poolKey)) &&
                                 !(child.material && materialPoolRef.current.has((child.material as any)._poolKey));
              if (isGltfPart) {
                  if (child.geometry) child.geometry.dispose();
                  if (child.material) {
                      if (Array.isArray(child.material)) {
                          child.material.forEach(material => material.dispose());
                      } else {
                          (child.material as THREE.Material).dispose();
                      }
                  }
              }
          }
      });
  };

  const handleOrbitControlsChange = useCallback(() => {
    const cam = cameraRef.current;
    const controls = controlsRef.current;

    if (!cam || !controls || isUpdatingFromPropsRef.current || cameraSyncStateRef.current !== 'idle') {
      return;
    }
    
    const now = performance.now();
    if (now - lastOrbitUpdateTimeRef.current < ORBIT_CONTROLS_TIME_THROTTLE_MS) {
      return; 
    }

    if (throttledOrbitUpdateRafRef.current) {
        cancelAnimationFrame(throttledOrbitUpdateRafRef.current);
    }

    throttledOrbitUpdateRafRef.current = requestAnimationFrame(() => {
        cameraSyncStateRef.current = 'updating-from-orbit';
        lastOrbitUpdateTimeRef.current = performance.now(); 

        const euler = new THREE.Euler().setFromQuaternion(cam.quaternion, EULER_ORDER);
        const cameraUpdate: CameraConfig = {
            position: {
                x: parseFloat(cam.position.x.toFixed(3)),
                y: parseFloat(cam.position.y.toFixed(3)),
                z: parseFloat(cam.position.z.toFixed(3))
            },
            rotation: {
                x: parseFloat(THREE.MathUtils.radToDeg(euler.x).toFixed(2)),
                y: parseFloat(THREE.MathUtils.radToDeg(euler.y).toFixed(2)),
                z: parseFloat(THREE.MathUtils.radToDeg(euler.z).toFixed(2)),
            },
            fov: parseFloat(cam.fov.toFixed(1)),
            zoom: parseFloat(cam.zoom.toFixed(2)),
            timestamp: Date.now(),
            source: 'orbitControls',
            updateId: syncManager.generateUpdateId(),
        };
        onUpdateCameraRef.current(cameraUpdate);
        
        requestAnimationFrame(() => { 
            cameraSyncStateRef.current = 'idle';
            throttledOrbitUpdateRafRef.current = null;
        });
    });
  }, [syncManager, onUpdateCameraRef]); 

  const handleWheelZoom = useCallback((event: WheelEvent) => {
    const cam = cameraRef.current;
    if (!cam || cameraSyncStateRef.current === 'updating-from-ui') return;

    event.preventDefault();
    event.stopPropagation();
    
    const now = performance.now();
    if (now - lastWheelUpdateTimeRef.current < WHEEL_ZOOM_TIME_THROTTLE_MS) {
        return;
    }
    lastWheelUpdateTimeRef.current = now;

    cameraSyncStateRef.current = 'updating-from-orbit';

    const zoomSpeedFactor = 0.05;
    let delta = event.deltaY > 0 ? -1 : 1; 
    const newZoom = Math.max(0.1, Math.min(20, cam.zoom * (1 + delta * zoomSpeedFactor)));

    const euler = new THREE.Euler().setFromQuaternion(cam.quaternion, EULER_ORDER);
    const cameraUpdate: CameraConfig = {
        position: {
            x: parseFloat(cam.position.x.toFixed(3)),
            y: parseFloat(cam.position.y.toFixed(3)),
            z: parseFloat(cam.position.z.toFixed(3))
        },
        rotation: {
            x: parseFloat(THREE.MathUtils.radToDeg(euler.x).toFixed(2)),
            y: parseFloat(THREE.MathUtils.radToDeg(euler.y).toFixed(2)),
            z: parseFloat(THREE.MathUtils.radToDeg(euler.z).toFixed(2)),
        },
        fov: parseFloat(cam.fov.toFixed(1)),
        zoom: newZoom, 
        timestamp: Date.now(),
        source: 'orbitControlsScroll',
        updateId: syncManager.generateUpdateId(),
    };
    onUpdateCameraRef.current(cameraUpdate);
    
    requestAnimationFrame(() => { 
        cameraSyncStateRef.current = 'idle';
    });
  }, [syncManager, onUpdateCameraRef]); 
  
  const applyCameraConfig = useCallback((cameraConfig: CameraConfig | undefined) => {
    const threeCam = cameraRef.current;
    const controls = controlsRef.current;
    if (!threeCam || !controls) return;

    if (!cameraConfig) { /* ... handle default config ... */ return; }

    if (cameraSyncStateRef.current === 'updating-from-orbit' && 
        (cameraConfig.source === 'orbitControls' || cameraConfig.source === 'orbitControlsScroll')) {
      return;
    }
    
    if (cameraConfig.updateId && cameraConfig.updateId === lastAppliedUpdateIdRef.current) {
      return;
    }

    cameraSyncStateRef.current = 'updating-from-ui';
    setUpdatingFlag(); 

    try {
      threeCam.position.set(cameraConfig.position.x, cameraConfig.position.y, cameraConfig.position.z);
      const euler = new THREE.Euler(
        THREE.MathUtils.degToRad(cameraConfig.rotation.x),
        THREE.MathUtils.degToRad(cameraConfig.rotation.y),
        THREE.MathUtils.degToRad(cameraConfig.rotation.z), EULER_ORDER);
      threeCam.quaternion.setFromEuler(euler);
      threeCam.fov = cameraConfig.fov;
      threeCam.zoom = cameraConfig.zoom;
      threeCam.updateProjectionMatrix();

      const lookDirection = new THREE.Vector3();
      threeCam.getWorldDirection(lookDirection);
      let currentTargetDistance = controls.getDistance();
      if (isNaN(currentTargetDistance) || currentTargetDistance < controls.minDistance || currentTargetDistance > controls.maxDistance * 0.95 || currentTargetDistance < 0.001 * 10) {
           currentTargetDistance = DEFAULT_TARGET_DISTANCE;
      }
      const newControlsTarget = new THREE.Vector3().copy(threeCam.position).addScaledVector(lookDirection, currentTargetDistance);
      controls.target.copy(newControlsTarget);
      controls.update();
      
      lastAppliedUpdateIdRef.current = cameraConfig.updateId || null;

    } catch (error) {
      console.error('Error applying camera config:', error);
    } finally {
      requestAnimationFrame(() => { 
         cameraSyncStateRef.current = 'idle';
      });
    }
  }, [setUpdatingFlag]);

  // Initialization Effect (runs once)
  useEffect(() => {
    if (!mountRef.current) return;
    const mountElement = mountRef.current;
    gltfLoaderRef.current = new GLTFLoader();
    const scene = new THREE.Scene(); sceneRef.current = scene;

    const initialFrameState = frame; 
    const initialCameraConfig = initialFrameState?.camera || { position: { x: 0, y: 1.6, z: 7 }, rotation: { x: -10, y: 0, z: 0 }, fov: 50, zoom: 1, source:'appInternal', updateId: syncManager.generateUpdateId(), timestamp:Date.now() };
    
    const camera = new THREE.PerspectiveCamera(initialCameraConfig.fov, mountElement.clientWidth / mountElement.clientHeight, 0.1, 1000);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
    rendererRef.current = renderer;
    if (appRendererRef) appRendererRef.current = renderer;
    renderer.setSize(mountElement.clientWidth, mountElement.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mountElement.appendChild(renderer.domElement);

    const createdGridHelper = new THREE.GridHelper(50, 50, 0x555555, 0x333333); 
    createdGridHelper.position.y = -0.01; 
    createdGridHelper.visible = showGrid; // Initial visibility based on prop
    scene.add(createdGridHelper);
    gridHelperRef.current = createdGridHelper;

    const groundGeom = new THREE.PlaneGeometry(100, 100); const groundMat = new THREE.MeshStandardMaterial({ color: 0x222222, side: THREE.DoubleSide, roughness: 0.8, metalness: 0.2 });
    const createdGroundPlane = new THREE.Mesh(groundGeom, groundMat); 
    createdGroundPlane.rotation.x = -Math.PI / 2; 
    createdGroundPlane.position.y = -0.05; 
    createdGroundPlane.receiveShadow = true; 
    createdGroundPlane.visible = showGroundPlane; // Initial visibility based on prop
    scene.add(createdGroundPlane);
    groundPlaneRef.current = createdGroundPlane;

    const controls = new OrbitControls(camera, renderer.domElement); controlsRef.current = controls;
    controls.enableDamping = isCameraDampingEnabled; 
    controls.dampingFactor = 0.05; controls.screenSpacePanning = true;
    controls.minDistance = 0.1; controls.maxDistance = 200; controls.enableZoom = true; 
    controls.addEventListener('change', handleOrbitControlsChange);
    
    const createdGizmoScene = new THREE.Scene();
    gizmoSceneRef.current = createdGizmoScene;
    const createdGizmoCamera = new THREE.OrthographicCamera(gizmoSize * (mountElement.clientWidth/mountElement.clientHeight) / -2, gizmoSize * (mountElement.clientWidth/mountElement.clientHeight) / 2, gizmoSize / 2, gizmoSize / -2, 0.1, 100 );
    gizmoCameraRef.current = createdGizmoCamera;
    createdGizmoCamera.position.z = 5;
    
    const arrowX = new THREE.ArrowHelper(new THREE.Vector3(1,0,0), new THREE.Vector3(0,0,0), gizmoSize*0.07, 0xff0000); createdGizmoScene.add(arrowX);
    const arrowY = new THREE.ArrowHelper(new THREE.Vector3(0,1,0), new THREE.Vector3(0,0,0), gizmoSize*0.07, 0x00ff00); createdGizmoScene.add(arrowY);
    const arrowZ = new THREE.ArrowHelper(new THREE.Vector3(0,0,1), new THREE.Vector3(0,0,0), gizmoSize*0.07, 0x0000ff); createdGizmoScene.add(arrowZ);
    const spriteX = createTextSprite('X', {fontsize: 24, textColor:{r:255,g:70,b:70,a:1}}); spriteX.position.set(gizmoSize*0.08,0,0); spriteX.scale.set(5,2.5,1); createdGizmoScene.add(spriteX);
    const spriteY = createTextSprite('Y', {fontsize: 24, textColor:{r:70,g:255,b:70,a:1}}); spriteY.position.set(0,gizmoSize*0.08,0); spriteY.scale.set(5,2.5,1); createdGizmoScene.add(spriteY);
    const spriteZ = createTextSprite('Z', {fontsize: 24, textColor:{r:70,g:70,b:255,a:1}}); spriteZ.position.set(0,0,gizmoSize*0.08); spriteZ.scale.set(5,2.5,1); createdGizmoScene.add(spriteZ);

    const animate = () => {
      animationFrameIdRef.current = requestAnimationFrame(animate);
      const currentRenderer = rendererRef.current;
      const currentScene = sceneRef.current;
      const currentCamera = cameraRef.current;
      const currentControls = controlsRef.current;
      const currentGroundPlane = groundPlaneRef.current;

      if (currentRenderer && currentScene && currentCamera && currentControls && currentGroundPlane) {
        if (currentControls.enabled) currentControls.update();
        
        const groundMaterial = currentGroundPlane.material as THREE.MeshStandardMaterial;
        const camY = currentCamera.position.y;
        const groundYPos = currentGroundPlane.position.y;
        const newIsTransparent = camY < (groundYPos + 0.15);
        const newOpacity = newIsTransparent ? 0.2 : 1.0;

        const prevGround = prevGroundStateRef.current;
        if (!prevGround || prevGround.transparent !== newIsTransparent || prevGround.opacity !== newOpacity) {
            groundMaterial.transparent = newIsTransparent;
            groundMaterial.opacity = newOpacity;
            groundMaterial.needsUpdate = true;
            prevGroundStateRef.current = { transparent: newIsTransparent, opacity: newOpacity };
        }

        currentRenderer.render(currentScene, currentCamera);
        
        if (showOrientationGizmo && gizmoSceneRef.current && gizmoCameraRef.current) { // Gizmo visibility
            const currentAutoClear = currentRenderer.autoClear; currentRenderer.autoClear = false; currentRenderer.clearDepth();
            const SISSOR_OFFSET = 10;
            currentRenderer.setScissorTest(true);
            currentRenderer.setScissor(SISSOR_OFFSET, SISSOR_OFFSET, gizmoSize, gizmoSize);
            currentRenderer.setViewport(SISSOR_OFFSET, SISSOR_OFFSET, gizmoSize, gizmoSize);
            gizmoCameraRef.current.quaternion.copy(currentCamera.quaternion);
            currentRenderer.render(gizmoSceneRef.current, gizmoCameraRef.current);
            currentRenderer.setScissorTest(false); currentRenderer.autoClear = currentAutoClear;
             if(mountRef.current) currentRenderer.setViewport(0,0,mountRef.current.clientWidth, mountRef.current.clientHeight);
        }
      }
    };
    animate();

    const handleResize = () => { /* ... */ }; window.addEventListener('resize', handleResize);
    const handleContextMenu = (e: MouseEvent) => e.preventDefault(); mountElement.addEventListener('contextmenu', handleContextMenu);
    mountElement.addEventListener('wheel', handleWheelZoom, { passive: false });

    return () => {
      if (animationFrameIdRef.current) cancelAnimationFrame(animationFrameIdRef.current);
      if (throttledOrbitUpdateRafRef.current) cancelAnimationFrame(throttledOrbitUpdateRafRef.current); 
      controlsRef.current?.removeEventListener('change', handleOrbitControlsChange);
      controlsRef.current?.dispose();
      window.removeEventListener('resize', handleResize);
      mountElement.removeEventListener('contextmenu', handleContextMenu);
      mountElement.removeEventListener('wheel', handleWheelZoom);
      
      objectMeshesRef.current.forEach(obj => { sceneRef.current?.remove(obj); disposeObject3D(obj); }); objectMeshesRef.current.clear();
      characterMeshesRef.current.forEach(obj => { sceneRef.current?.remove(obj); disposeObject3D(obj); }); characterMeshesRef.current.clear();
      lightMeshesRef.current.forEach(light => { sceneRef.current?.remove(light); light.dispose(); }); lightMeshesRef.current.clear();
      
      gizmoSceneRef.current?.traverse(obj => disposeObject3D(obj as THREE.Mesh)); gizmoSceneRef.current?.clear();
      modelCacheRef.current.forEach(group => disposeObject3D(group)); modelCacheRef.current.clear();

      geometryPoolRef.current.forEach(geometry => geometry.dispose()); geometryPoolRef.current.clear();
      materialPoolRef.current.forEach(material => material.dispose()); materialPoolRef.current.clear();
      
      rendererRef.current?.dispose();
      if (mountElement && rendererRef.current?.domElement.parentNode === mountElement) { try { mountElement.removeChild(rendererRef.current.domElement); } catch(e){} }
      if (appRendererRef) appRendererRef.current = null;
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appRendererRef, handleOrbitControlsChange, handleWheelZoom, syncManager]); 
  // Removed isCameraDampingEnabled, showGrid, showGroundPlane from main useEffect deps

  // Effect to update damping when prop changes
  useEffect(() => {
    if (controlsRef.current) {
        controlsRef.current.enableDamping = isCameraDampingEnabled;
    }
  }, [isCameraDampingEnabled]);
  
  // Effect to update grid visibility
  useEffect(() => {
    if (gridHelperRef.current) {
      gridHelperRef.current.visible = showGrid;
    }
  }, [showGrid]);

  // Effect to update ground plane visibility
  useEffect(() => {
    if (groundPlaneRef.current) {
      groundPlaneRef.current.visible = showGroundPlane;
    }
  }, [showGroundPlane]);


  // Effect for Camera Updates
  useEffect(() => {
    applyCameraConfig(frame?.camera);
  }, [frame?.camera, applyCameraConfig]);

  const updateExistingCharacterOrObject = useCallback((mesh: THREE.Object3D, item: StoryCharacter | StoryObject) => {
      mesh.name = item.name;
      mesh.position.set(item.position?.x || 0, (item.position?.y || 0) + (item.yOffset || 0), item.position?.z || 0);
      const rot = item.rotation || {x:0,y:0,z:0};
      mesh.rotation.set(THREE.MathUtils.degToRad(rot.x), THREE.MathUtils.degToRad(rot.y), THREE.MathUtils.degToRad(rot.z), EULER_ORDER);
      
      if (!item.modelUrl && mesh instanceof THREE.Mesh) { 
          if ('size' in item && mesh.geometry) {
              const obj = item as StoryObject;
              const sizeFactor = obj.size * 0.2;
              let newGeomKey = '';
              if (obj.type.toLowerCase() === 'sphere') newGeomKey = `sphere_${(sizeFactor/2).toFixed(3)}_${16}_${12}`;
              else if (obj.type.toLowerCase() === 'cylinder') newGeomKey = `cylinder_${(sizeFactor/2).toFixed(3)}_${(sizeFactor/2).toFixed(3)}_${sizeFactor.toFixed(3)}_${16}`;
              else if (obj.type.toLowerCase() === 'plane') newGeomKey = `plane_${(sizeFactor*2).toFixed(3)}_${(sizeFactor*2).toFixed(3)}`;
              else newGeomKey = `box_${sizeFactor.toFixed(3)}_${sizeFactor.toFixed(3)}_${sizeFactor.toFixed(3)}`;
              
              if ((mesh.geometry as any)._poolKey !== newGeomKey) {
                  if (!geometryPoolRef.current.has(newGeomKey)) {
                      let newGeom: THREE.BufferGeometry;
                      if (obj.type.toLowerCase() === 'sphere') newGeom = new THREE.SphereGeometry(sizeFactor/2,16,12);
                      else if (obj.type.toLowerCase() === 'cylinder') newGeom = new THREE.CylinderGeometry(sizeFactor/2,sizeFactor/2,sizeFactor,16);
                      else if (obj.type.toLowerCase() === 'plane') newGeom = new THREE.PlaneGeometry(sizeFactor*2,sizeFactor*2);
                      else newGeom = new THREE.BoxGeometry(sizeFactor,sizeFactor,sizeFactor);
                      (newGeom as any)._poolKey = newGeomKey;
                      geometryPoolRef.current.set(newGeomKey, newGeom);
                  }
                  mesh.geometry = geometryPoolRef.current.get(newGeomKey)!;
              }
          }
          const matKey = `standard_${item.color.replace('#', '')}`;
          if (!(mesh.material instanceof THREE.Material) || (mesh.material as any)._poolKey !== matKey) {
              if (!materialPoolRef.current.has(matKey)) {
                  const newMat = new THREE.MeshStandardMaterial({ color: item.color });
                  (newMat as any)._poolKey = matKey;
                  materialPoolRef.current.set(matKey, newMat);
              }
              mesh.material = materialPoolRef.current.get(matKey)!;
          }
          mesh.scale.set(item.scale?.x || 1, item.scale?.y || 1, item.scale?.z || 1);
      } else if (item.modelUrl) { 
          const assetScale = (item as any).assetScale || {x:1,y:1,z:1}; 
          const userScale = item.scale || {x:1,y:1,z:1};
          mesh.scale.set(assetScale.x * userScale.x, assetScale.y * userScale.y, assetScale.z * userScale.z);
      }
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.traverse(node => { if (node instanceof THREE.Mesh) { node.castShadow = true; node.receiveShadow = true; }});
  }, []);

  const processSceneItem = useCallback((item: StoryCharacter | StoryObject, isCharacter: boolean) => {
    const scene = sceneRef.current;
    const loader = gltfLoaderRef.current;
    if (!scene || !loader) return;
    const itemMap = isCharacter ? characterMeshesRef.current : objectMeshesRef.current;
    if (item.modelUrl) {
        const onModelLoaded = (gltfScene: THREE.Group) => {
            const model = gltfScene; 
            updateExistingCharacterOrObject(model, item);
            scene.add(model);
            itemMap.set(item.id, model);
            (model as any)._currentModelUrl = item.modelUrl; 
        };
        if (modelCacheRef.current.has(item.modelUrl)) {
            const cachedModel = modelCacheRef.current.get(item.modelUrl)!.clone();
            onModelLoaded(cachedModel);
        } else {
            loader.load(item.modelUrl, (gltf) => {
                modelCacheRef.current.set(item.modelUrl, gltf.scene); 
                const clonedModel = gltf.scene.clone(); 
                onModelLoaded(clonedModel);
            }, undefined, (error) => console.error(`Error loading model ${item.modelUrl}:`, error));
        }
    } else { 
        let geometry: THREE.BufferGeometry;
        let geomKey: string;
        if (isCharacter) {
            geomKey = `capsule_${0.3}_${1}_${4}_${8}`;
            if (!geometryPoolRef.current.has(geomKey)) {
                const newGeom = new THREE.CapsuleGeometry(0.3, 1, 4, 8);
                (newGeom as any)._poolKey = geomKey;
                geometryPoolRef.current.set(geomKey, newGeom);
            }
            geometry = geometryPoolRef.current.get(geomKey)!;
        } else {
            const obj = item as StoryObject; const sizeFactor = obj.size * 0.2;
            if (obj.type.toLowerCase() === 'sphere') {
                geomKey = `sphere_${(sizeFactor/2).toFixed(3)}_${16}_${12}`;
                if (!geometryPoolRef.current.has(geomKey)) {
                    const newGeom = new THREE.SphereGeometry(sizeFactor/2,16,12);
                    (newGeom as any)._poolKey = geomKey;
                    geometryPoolRef.current.set(geomKey, newGeom);
                }
            } else if (obj.type.toLowerCase() === 'cylinder') {
                geomKey = `cylinder_${(sizeFactor/2).toFixed(3)}_${(sizeFactor/2).toFixed(3)}_${sizeFactor.toFixed(3)}_${16}`;
                 if (!geometryPoolRef.current.has(geomKey)) {
                    const newGeom = new THREE.CylinderGeometry(sizeFactor/2,sizeFactor/2,sizeFactor,16);
                    (newGeom as any)._poolKey = geomKey;
                    geometryPoolRef.current.set(geomKey, newGeom);
                }
            } else if (obj.type.toLowerCase() === 'plane') {
                 geomKey = `plane_${(sizeFactor*2).toFixed(3)}_${(sizeFactor*2).toFixed(3)}`;
                 if (!geometryPoolRef.current.has(geomKey)) {
                    const newGeom = new THREE.PlaneGeometry(sizeFactor*2,sizeFactor*2);
                    (newGeom as any)._poolKey = geomKey;
                    geometryPoolRef.current.set(geomKey, newGeom);
                }
            } else { 
                geomKey = `box_${sizeFactor.toFixed(3)}_${sizeFactor.toFixed(3)}_${sizeFactor.toFixed(3)}`;
                 if (!geometryPoolRef.current.has(geomKey)) {
                    const newGeom = new THREE.BoxGeometry(sizeFactor,sizeFactor,sizeFactor);
                    (newGeom as any)._poolKey = geomKey;
                    geometryPoolRef.current.set(geomKey, newGeom);
                }
            }
            geometry = geometryPoolRef.current.get(geomKey)!;
        }
        const matKey = `standard_${item.color.replace('#', '')}`;
        if (!materialPoolRef.current.has(matKey)) {
            const newMat = new THREE.MeshStandardMaterial({ color: item.color });
            (newMat as any)._poolKey = matKey;
            materialPoolRef.current.set(matKey, newMat);
        }
        const material = materialPoolRef.current.get(matKey)!;
        const mesh = new THREE.Mesh(geometry, material);
        updateExistingCharacterOrObject(mesh, item); 
        scene.add(mesh);
        itemMap.set(item.id, mesh);
        (mesh as any)._currentModelUrl = undefined; 
    }
  }, [updateExistingCharacterOrObject]);
  
  const updateExistingLight = useCallback((light: THREE.Light, config: LightConfig, scene: THREE.Scene) => {
    light.name = config.name;
    light.color.set(config.color);
    light.intensity = config.intensity;
    if (light instanceof THREE.PointLight || light instanceof THREE.DirectionalLight || light instanceof THREE.SpotLight) {
        light.position.set(config.position.x, config.position.y, config.position.z);
        light.castShadow = config.castShadow;
        if (config.castShadow) { 
            light.shadow.mapSize.setScalar(512); 
            light.shadow.camera.near = 0.1;    
            light.shadow.camera.far = 25;      
            light.shadow.bias = -0.0001;       
        }
    }
    if ((light instanceof THREE.DirectionalLight || light instanceof THREE.SpotLight)) {
        if (!light.target) { 
            light.target = new THREE.Object3D();
            scene.add(light.target); 
        }
        light.target.position.set(config.target.x, config.target.y, config.target.z);
        light.target.updateMatrixWorld();
    }
    if (light instanceof THREE.SpotLight) {
        light.angle = THREE.MathUtils.degToRad(config.angle ?? 45);
        light.penumbra = config.penumbra ?? 0.1;
        light.decay = config.decay ?? 1;
    }
    if (light instanceof THREE.PointLight && config.decay !== undefined) {
        light.decay = config.decay;
    }
  }, []);

  const addNewLight = useCallback((config: LightConfig, scene: THREE.Scene) => {
      let light: THREE.Light | undefined;
      switch (config.type) {
        case 'Ambient': light = new THREE.AmbientLight(); break;
        case 'Directional': const dLight = new THREE.DirectionalLight(); dLight.target = new THREE.Object3D(); scene.add(dLight.target); light = dLight; break;
        case 'Point': light = new THREE.PointLight(); break;
        case 'Spot': const sLight = new THREE.SpotLight(); sLight.target = new THREE.Object3D(); scene.add(sLight.target); light = sLight; break;
      }
      if (light) {
          updateExistingLight(light, config, scene); 
          scene.add(light);
          lightMeshesRef.current.set(config.id, light);
      }
  }, [updateExistingLight]);

  useEffect(() => {
    const scene = sceneRef.current;
    const renderer = rendererRef.current;
    if (!scene || !renderer) return;
    const prevLights = prevFrameElementsRef.current.lights || [];
    const newLights = frame?.lights || [];
    if (newLights !== prevLights) {
        const currentLightIds = new Set(lightMeshesRef.current.keys());
        const newLightIds = new Set(newLights.map(l => l.id));
        currentLightIds.forEach(id => {
            if (!newLightIds.has(id)) {
                const light = lightMeshesRef.current.get(id);
                if (light) {
                    scene.remove(light);
                    if ((light instanceof THREE.DirectionalLight || light instanceof THREE.SpotLight) && light.target.parent === scene) {
                        scene.remove(light.target); 
                    }
                    light.dispose();
                    lightMeshesRef.current.delete(id);
                }
            }
        });
        newLights.forEach(lightConfig => {
            const existingLight = lightMeshesRef.current.get(lightConfig.id);
            if (existingLight) {
                updateExistingLight(existingLight, lightConfig, scene);
            } else {
                addNewLight(lightConfig, scene);
            }
        });
        prevFrameElementsRef.current.lights = newLights;
    }
    const prevChars = prevFrameElementsRef.current.characters || [];
    const newChars = frame?.characters || [];
    if (newChars !== prevChars) {
        const currentCharacterIds = new Set(characterMeshesRef.current.keys());
        const newCharacterIds = new Set(newChars.map(c => c.id));
        currentCharacterIds.forEach(id => {
            if (!newCharacterIds.has(id)) {
                const mesh = characterMeshesRef.current.get(id);
                if (mesh) { scene.remove(mesh); disposeObject3D(mesh); }
                characterMeshesRef.current.delete(id);
            }
        });
        newChars.forEach(charData => {
            const existingMesh = characterMeshesRef.current.get(charData.id);
            if (existingMesh) {
                if (charData.modelUrl !== (existingMesh as any)._currentModelUrl) {
                    scene.remove(existingMesh); disposeObject3D(existingMesh);
                    processSceneItem(charData, true); 
                } else {
                    updateExistingCharacterOrObject(existingMesh, charData);
                }
            } else {
                processSceneItem(charData, true);
            }
        });
        prevFrameElementsRef.current.characters = newChars;
    }
    const prevObjs = prevFrameElementsRef.current.objects || [];
    const newObjs = frame?.objects || [];
    if (newObjs !== prevObjs) {
        const currentObjectIds = new Set(objectMeshesRef.current.keys());
        const newObjectIds = new Set(newObjs.map(o => o.id));
        currentObjectIds.forEach(id => {
            if (!newObjectIds.has(id)) {
                const mesh = objectMeshesRef.current.get(id);
                if (mesh) { scene.remove(mesh); disposeObject3D(mesh); }
                objectMeshesRef.current.delete(id);
            }
        });
        newObjs.forEach(objData => {
            const existingMesh = objectMeshesRef.current.get(objData.id);
            if (existingMesh) {
                 if (objData.modelUrl !== (existingMesh as any)._currentModelUrl) {
                    scene.remove(existingMesh); disposeObject3D(existingMesh);
                    processSceneItem(objData, false);
                } else {
                    updateExistingCharacterOrObject(existingMesh, objData);
                }
            } else {
                processSceneItem(objData, false);
            }
        });
        prevFrameElementsRef.current.objects = newObjs;
    }
    const hasFrameChanged = !frame && (prevFrameElementsRef.current.backgroundColor !== undefined);
    const backgroundColorChanged = frame && (frame.backgroundColor !== prevFrameElementsRef.current.backgroundColor);
    if (hasFrameChanged || backgroundColorChanged || (!frame && !prevFrameElementsRef.current.backgroundColor)) {
        if (!frame) {
            // No frame visibility handled by the grid/ground plane useEffects now
            renderer.setClearColor(0x111827, 1); 
            prevFrameElementsRef.current.backgroundColor = undefined; 
        } else {
             // No frame visibility handled by the grid/ground plane useEffects now
            renderer.setClearColor(frame.backgroundColor || 0x2D3748, 1);
            prevFrameElementsRef.current.backgroundColor = frame.backgroundColor;
        }
    }
    if (!frame) {
        prevFrameElementsRef.current = { lights: undefined, characters: undefined, objects: undefined, backgroundColor: undefined };
    }
  }, [frame, processSceneItem, updateExistingLight, addNewLight, updateExistingCharacterOrObject]);

  useEffect(() => {
    const resizeTimeout = setTimeout(() => {
      if (mountRef.current && rendererRef.current && cameraRef.current) {
        const width = mountRef.current.clientWidth;
        const height = mountRef.current.clientHeight;
        if (width > 0 && height > 0) {
          rendererRef.current.setSize(width, height);
          cameraRef.current.aspect = width / height;
          cameraRef.current.updateProjectionMatrix();
        }
      }
    }, 350); 
    return () => clearTimeout(resizeTimeout);
  }, [isTimelineSidebarOpen]);

  return (
    <div ref={mountRef} className="w-full h-full bg-gray-800 rounded-lg overflow-hidden relative select-none">
      {!frame && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-800 bg-opacity-95 z-10 p-4">
          <CubeIcon className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h2 className="text-2xl font-semibold text-gray-400 mb-2">No Frame Selected</h2>
          <p className="text-gray-500 mb-6 text-center">
            The timeline is empty or no frame is currently selected.
            <br />
            Please create a new frame or select one from the timeline.
          </p>
          <button
            onClick={onAddFrame}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-4 rounded flex items-center mx-auto"
          >
            <PlusIcon className="w-5 h-5 mr-2" /> Add First Frame
          </button>
        </div>
      )}
      {frame && <CameraPositionIndicator cameraConfig={frame.camera} />}
    </div>
  );
};

export default MainViewer;