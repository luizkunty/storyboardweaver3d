
import React from 'react';
import { Frame } from '../../types';
import FrameCard from '../storyboard/FrameCard';
import { PlayIcon, PauseIcon, ChevronLeftIcon, ChevronRightIcon, PlusIcon, CubeIcon } from '../../constants';
import Button from '../ui/Button'; 
import IconButton from '../ui/IconButton';

interface TimelineProps {
  frames: Frame[];
  currentFrameIndex: number;
  onSelectFrame: (index: number) => void;
  onAddFrame: () => void; 
  isPlaying: boolean;
  onTogglePlay: () => void;
}

const Timeline: React.FC<TimelineProps> = ({ 
  frames, 
  currentFrameIndex, 
  onSelectFrame, 
  onAddFrame,
  isPlaying,
  onTogglePlay
}) => {
  if (frames.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-4 text-center text-gray-500">
        <CubeIcon className="w-12 h-12 text-gray-600 mb-3" />
        <p className="mb-3 text-sm">The timeline is empty.</p>
        <Button onClick={onAddFrame} variant="primary" size="sm" className="flex items-center">
          <PlusIcon className="w-4 h-4 mr-1.5" /> Create New Frame
        </Button>
      </div>
    );
  }
  
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="flex items-center justify-around p-1.5 border-b border-gray-700 mb-2">
        <IconButton 
          title="Previous Frame"
          disabled={frames.length === 0 || currentFrameIndex <= 0}
          onClick={() => onSelectFrame(Math.max(0, currentFrameIndex - 1))}
          aria-label="Previous Frame"
          className="disabled:opacity-30"
        >
            <ChevronLeftIcon className="w-4 h-4" />
        </IconButton>
        <IconButton
          title={isPlaying ? "Pause Animation" : "Play Animation"}
          disabled={frames.length < 2} // Needs at least 2 frames to play
          onClick={onTogglePlay}
          aria-label={isPlaying ? "Pause Animation" : "Play Animation"}
          className={`disabled:opacity-30 ${isPlaying ? 'text-indigo-400 hover:text-indigo-300' : ''}`}
        >
          {isPlaying ? <PauseIcon className="w-5 h-5" /> : <PlayIcon className="w-5 h-5" />}
        </IconButton>
        <IconButton
          title="Next Frame"
          disabled={frames.length === 0 || currentFrameIndex >= frames.length - 1}
          onClick={() => onSelectFrame(Math.min(frames.length - 1, currentFrameIndex + 1))}
          aria-label="Next Frame"
          className="disabled:opacity-30"
        >
            <ChevronRightIcon className="w-4 h-4" />
        </IconButton>
      </div>
      
      <div className="flex-1 overflow-y-auto space-y-2 pr-1 pb-1 custom-scrollbar" role="listbox" aria-label="Storyboard Frames">
        {frames.map((frame, index) => (
          <FrameCard
            key={frame.id}
            frame={frame}
            isSelected={index === currentFrameIndex}
            onClick={() => onSelectFrame(index)}
          />
        ))}
      </div>
    </div>
  );
};

export default Timeline;
