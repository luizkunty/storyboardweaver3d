
import React from 'react';
import { ArrowDownTrayIcon, PlusIcon, MinusIcon } from '../../constants'; // Added PlusIcon, MinusIcon
import Button from '../ui/Button';

interface ControlsPanelProps {
  onDownloadPNG: () => void;
  onDownloadJPG: () => void;
  onZoomIn: () => void;    // New prop
  onZoomOut: () => void;   // New prop
}

const ControlsPanel: React.FC<ControlsPanelProps> = ({ 
  onDownloadPNG, 
  onDownloadJPG,
  onZoomIn,
  onZoomOut
}) => {
  return (
    <div className="bg-gray-800 p-3 mt-4 rounded-lg shadow">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-300">Frame Tools</h3>
        <div className="flex space-x-2">
          <Button onClick={onZoomIn} size="sm" variant="secondary" title="Zoom In">
            <PlusIcon className="w-4 h-4 mr-1" /> Zoom
          </Button>
          <Button onClick={onZoomOut} size="sm" variant="secondary" title="Zoom Out">
            <MinusIcon className="w-4 h-4 mr-1" /> Zoom
          </Button>
          <Button onClick={onDownloadPNG} size="sm" variant="secondary" title="Export as PNG">
            <ArrowDownTrayIcon className="w-4 h-4 mr-1" /> PNG
          </Button>
          <Button onClick={onDownloadJPG} size="sm" variant="secondary" title="Export as JPG">
            <ArrowDownTrayIcon className="w-4 h-4 mr-1" /> JPG
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ControlsPanel;
