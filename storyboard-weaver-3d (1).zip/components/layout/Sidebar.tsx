
import React from 'react';
import { SidebarPanelType } from '../../types';

interface SidebarItem {
  id: SidebarPanelType;
  label: string;
  icon: React.FC<{ className?: string }>;
}

interface SidebarProps {
  items: SidebarItem[];
  activePanel: SidebarPanelType | null;
  onSelectItem: (panel: SidebarPanelType) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ items, activePanel, onSelectItem }) => {
  return (
    <aside className="w-16 bg-gray-800 p-2 flex flex-col items-center space-y-3 border-r border-gray-700 z-30">
      {items.map((item) => (
        <button
          key={item.id}
          onClick={() => onSelectItem(item.id === activePanel ? null : item.id)}
          title={item.label}
          className={`p-2 rounded-lg hover:bg-indigo-600 transition-colors
            ${activePanel === item.id ? 'bg-indigo-500 text-white' : 'text-gray-400 hover:text-white'}`}
        >
          <item.icon className="w-6 h-6" />
        </button>
      ))}
    </aside>
  );
};

export default Sidebar;
