
import React from 'react';
import { APP_TITLE } from '../../constants'; // Assuming APP_TITLE might be used or for consistency

interface HeaderProps {
  title: string;
}

const Header: React.FC<HeaderProps> = ({ title }) => {
  return (
    <header className="bg-gray-800 text-white p-3 shadow-md flex items-center z-30 h-16 flex-shrink-0">
      <img 
        src="./logo.png" 
        alt="Storyboard Weaver 3D Logo" 
        className="h-10 w-auto mr-3" // Adjusted for better aspect ratio
      />
      <h1 className="text-xl font-semibold">{title}</h1>
    </header>
  );
};

export default Header;
