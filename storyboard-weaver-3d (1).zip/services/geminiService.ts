
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const apiKey = process.env.API_KEY;

if (!apiKey) {
  console.warn("API_KEY for Gemini is not set. AI features will be disabled.");
}

const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const generateSceneIdeas = async (userPrompt: string, numScenes: number = 3): Promise<string> => {
  if (!ai) {
    return Promise.reject(new Error("Gemini API client is not initialized. API_KEY might be missing."));
  }

  const fullPrompt = `
    User prompt for a storyboard: "${userPrompt}"

    Based on this, generate a textual description for a sequence of ${numScenes} storyboard scenes.
    For EACH scene, provide the following information in this EXACT structure:

    Scene [Scene Number]: [Brief Scene Title/Focus, max 5 words]
    Description: [Detailed description of the setting, environment, key characters involved, their general actions, expressions, or dialogue snippets. Mention any key objects and their states.]
    Camera Suggestions: [Suggest camera angle, shot type (e.g., Wide shot, Close-up, Eye-level, Low Angle, High Angle), or basic camera parameters if applicable (e.g., Zoom in, slight pan right). Keep this concise.]
    Object Suggestions: [Suggest 0-2 simple placeholder objects that should be present in this scene. For each, provide:
      - type: (e.g., 'cube', 'sphere', 'cylinder', 'plane')
      - name: (e.g., 'Control Panel', 'the Moon')
      - initialPosition: (X,Y,Z CSV format, e.g., "0,1.5,0")
      - initialRotation: (Pitch,Yaw,Roll degrees CSV format, e.g., "0,45,0")
      - initialScale: (X,Y,Z CSV format, e.g., "1,1,2")
      Format: "TYPE named NAME; position: X,Y,Z; rotation: P,Y,R; scale: X,Y,Z".
      Separate multiple objects with a newline.
      Example for one object: "cube named Console; position: 0,0.5,-2; rotation: 0,0,0; scale: 1,1,1"
      Example for multiple objects (on separate lines):
      cube named Table; position: 0,0,-1; rotation: 0,0,0; scale: 2,0.1,1
      sphere named Lamp; position: 0,1,-1; rotation: 0,0,0; scale: 0.5,0.5,0.5
    ]
    External Image Prompt: [A detailed, descriptive text prompt suitable for an external AI image generation tool (like Midjourney, DALL-E, Stable Diffusion) to create a visual representation of THIS SPECIFIC SCENE. This prompt should be rich in visual details, style, mood, lighting, character appearance, and composition based on the scene description, camera suggestions, and object suggestions.]
    ---

    Ensure each scene block is separated by "---".
    Keep the total response well-structured.

    Example for one scene's object suggestions (if any):
    Object Suggestions:
    cube named Datapad; position: 0.2,1.2,-0.5; rotation: 10,0,0; scale: 0.3,0.4,0.05
    cylinder named Antenna Array; position: 0,5,-10; rotation: 0,0,0; scale: 0.2,3,0.2
    ---
  `;
  
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17", 
      contents: fullPrompt,
    });
    
    const text = response.text;
    if (typeof text !== 'string') {
      throw new Error("Invalid response format from Gemini API.");
    }
    return text;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        if (error.message.includes('API_KEY_INVALID') || error.message.includes('PERMISSION_DENIED')) {
             return Promise.reject(new Error(`Gemini API Key is invalid or has insufficient permissions. Please check your API key.`));
        }
        return Promise.reject(new Error(`Gemini API error: ${error.message}`));
    }
    return Promise.reject(new Error("An unknown error occurred with the Gemini API."));
  }
};
