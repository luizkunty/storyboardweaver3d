import { CameraConfig, EditableCameraConfig } from '../types';

export class CameraSyncManager {
  private static instance: CameraSyncManager;
  private updateCounter = 0;
  private readonly PRECISION = 3; // Decimal places for formatting string output
  private readonly NUMERIC_EPSILON = 0.0001; // Tolerance for general float comparisons (used internally if needed)
  
  // Thresholds for shouldUpdateCamera
  private readonly POSITION_THRESHOLD = 0.001; // e.g., 1mm
  private readonly ROTATION_THRESHOLD = 0.01;  // e.g., 0.01 degrees
  private readonly FOV_THRESHOLD = 0.1;       // e.g., 0.1 degrees
  private readonly ZOOM_THRESHOLD = 0.001;    // e.g., 0.001x

  private constructor() {}

  public static getInstance(): CameraSyncManager {
    if (!CameraSyncManager.instance) {
      CameraSyncManager.instance = new CameraSyncManager();
    }
    return CameraSyncManager.instance;
  }

  public generateUpdateId(): string {
    return `update_${Date.now()}_${++this.updateCounter}_${Math.random().toString(16).slice(2,6)}`;
  }

  public toEditableConfig(camera: CameraConfig): EditableCameraConfig {
    return {
      position: {
        x: camera.position.x.toFixed(this.PRECISION),
        y: camera.position.y.toFixed(this.PRECISION),
        z: camera.position.z.toFixed(this.PRECISION),
      },
      rotation: {
        x: camera.rotation.x.toFixed(this.PRECISION),
        y: camera.rotation.y.toFixed(this.PRECISION),
        z: camera.rotation.z.toFixed(this.PRECISION),
      },
      fov: camera.fov.toFixed(1),
      zoom: camera.zoom.toFixed(2),
      timestamp: camera.timestamp,
      source: camera.source,
      updateId: camera.updateId,
    };
  }

  public toNumericConfig(
    editableCamera: EditableCameraConfig,
    currentNumericBase?: CameraConfig
  ): CameraConfig {
    const base = currentNumericBase || {
        position: { x: 0, y: 1.6, z: 5},
        rotation: { x: 0, y: 0, z: 0},
        fov: 50,
        zoom: 1
    };

    return {
      position: {
        x: parseFloat(editableCamera.position.x) || base.position.x,
        y: parseFloat(editableCamera.position.y) || base.position.y,
        z: parseFloat(editableCamera.position.z) || base.position.z,
      },
      rotation: {
        x: parseFloat(editableCamera.rotation.x) || base.rotation.x,
        y: parseFloat(editableCamera.rotation.y) || base.rotation.y,
        z: parseFloat(editableCamera.rotation.z) || base.rotation.z,
      },
      fov: parseFloat(editableCamera.fov) || base.fov,
      zoom: parseFloat(editableCamera.zoom) || base.zoom,
      timestamp: editableCamera.timestamp,
      source: editableCamera.source as CameraConfig['source'],
      updateId: editableCamera.updateId,
    };
  }

  public areEqual(cam1: CameraConfig, cam2: CameraConfig, epsilon: number = this.NUMERIC_EPSILON): boolean {
    if (!cam1 || !cam2) return cam1 === cam2;

    const check = (val1: number, val2: number) => Math.abs(val1 - val2) < epsilon;

    return (
      check(cam1.position.x, cam2.position.x) &&
      check(cam1.position.y, cam2.position.y) &&
      check(cam1.position.z, cam2.position.z) &&
      check(cam1.rotation.x, cam2.rotation.x) &&
      check(cam1.rotation.y, cam2.rotation.y) &&
      check(cam1.rotation.z, cam2.rotation.z) &&
      check(cam1.fov, cam2.fov) &&
      check(cam1.zoom, cam2.zoom)
    );
  }

  public shouldAcceptUpdate(
    incomingCamera: CameraConfig,
    currentLocalEditableCamera: EditableCameraConfig,
    lastSentUpdateId: string | null,
    lastExternalTimestamp: number
  ): boolean {
    if (!currentLocalEditableCamera.updateId) {
      return true;
    }
    if (incomingCamera.updateId && incomingCamera.updateId === lastSentUpdateId) {
      return false;
    }
    if (
      incomingCamera.source !== 'ui' &&
      incomingCamera.timestamp &&
      incomingCamera.timestamp > lastExternalTimestamp
    ) {
      return true;
    }
    if (incomingCamera.source === 'ui' && incomingCamera.updateId !== currentLocalEditableCamera.updateId) {
      const currentLocalNumeric = this.toNumericConfig(currentLocalEditableCamera, incomingCamera);
      return !this.areEqual(incomingCamera, currentLocalNumeric);
    }
    return false;
  }

  /**
   * Checks if a new camera configuration is significantly different from an old one,
   * based on defined thresholds. Used to prevent state updates for minor changes.
   */
  public shouldUpdateCamera(oldConfig: CameraConfig | undefined, newConfig: CameraConfig): boolean {
    if (!oldConfig) return true; // Always update if there's no old config

    const checkDiff = (val1: number, val2: number, threshold: number) => Math.abs(val1 - val2) > threshold;

    if (
      checkDiff(oldConfig.position.x, newConfig.position.x, this.POSITION_THRESHOLD) ||
      checkDiff(oldConfig.position.y, newConfig.position.y, this.POSITION_THRESHOLD) ||
      checkDiff(oldConfig.position.z, newConfig.position.z, this.POSITION_THRESHOLD) ||
      checkDiff(oldConfig.rotation.x, newConfig.rotation.x, this.ROTATION_THRESHOLD) ||
      checkDiff(oldConfig.rotation.y, newConfig.rotation.y, this.ROTATION_THRESHOLD) ||
      checkDiff(oldConfig.rotation.z, newConfig.rotation.z, this.ROTATION_THRESHOLD) ||
      checkDiff(oldConfig.fov, newConfig.fov, this.FOV_THRESHOLD) ||
      checkDiff(oldConfig.zoom, newConfig.zoom, this.ZOOM_THRESHOLD)
    ) {
      return true; // At least one value changed significantly
    }
    
    // Also consider if source/updateId changed, as this might indicate a deliberate different update
    // even if numeric values are similar. This is more for state integrity.
    if (oldConfig.source !== newConfig.source || oldConfig.updateId !== newConfig.updateId) {
        return true;
    }

    return false; // No significant numeric change, and source/ID are same
  }
}
